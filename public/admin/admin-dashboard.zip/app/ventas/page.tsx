import { DashboardLayout } from "@/components/dashboard-layout"
import { VentasPage } from "@/components/ventas-page"

export default function Ventas() {
  return (
    <DashboardLayout>
      <VentasPage />
    </DashboardLayout>
  )
}
