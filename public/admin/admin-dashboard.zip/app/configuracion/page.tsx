import { DashboardLayout } from "@/components/dashboard-layout"
import { ConfiguracionPage } from "@/components/configuracion-page"

export default function Configuracion() {
  return (
    <DashboardLayout>
      <ConfiguracionPage />
    </DashboardLayout>
  )
}
