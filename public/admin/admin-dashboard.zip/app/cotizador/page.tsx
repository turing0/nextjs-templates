import { DashboardLayout } from "@/components/dashboard-layout"
import { CotizadorPage } from "@/components/cotizador-page"

export default function Cotizador() {
  return (
    <DashboardLayout>
      <CotizadorPage />
    </DashboardLayout>
  )
}
