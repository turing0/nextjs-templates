import { DashboardLayout } from "@/components/dashboard-layout"
import { ClientesPage } from "@/components/clientes-page"

export default function Clientes() {
  return (
    <DashboardLayout>
      <ClientesPage />
    </DashboardLayout>
  )
}
