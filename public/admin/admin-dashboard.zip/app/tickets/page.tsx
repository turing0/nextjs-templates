import { DashboardLayout } from "@/components/dashboard-layout"
import { TicketsPage } from "@/components/tickets-page"

export default function Tickets() {
  return (
    <DashboardLayout>
      <TicketsPage />
    </DashboardLayout>
  )
}
