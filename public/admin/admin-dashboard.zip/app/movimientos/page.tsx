import { DashboardLayout } from "@/components/dashboard-layout"
import { MovimientosPage } from "@/components/movimientos-page"

export default function Movimientos() {
  return (
    <DashboardLayout>
      <MovimientosPage />
    </DashboardLayout>
  )
}
