import { CalendarioPage } from "@/components/calendario-page"

export default function Calendario() {
  return <CalendarioPage />
}
