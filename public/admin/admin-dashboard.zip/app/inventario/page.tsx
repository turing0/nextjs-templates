import { DashboardLayout } from "@/components/dashboard-layout"
import { InventarioPage } from "@/components/inventario-page"

export default function Inventario() {
  return (
    <DashboardLayout>
      <InventarioPage />
    </DashboardLayout>
  )
}
