import { DashboardLayout } from "@/components/dashboard-layout"
import { ReportesPage } from "@/components/reportes-page"

export default function Reportes() {
  return (
    <DashboardLayout>
      <ReportesPage />
    </DashboardLayout>
  )
}
