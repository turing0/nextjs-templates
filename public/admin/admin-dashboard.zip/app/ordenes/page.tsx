import { DashboardLayout } from "@/components/dashboard-layout"
import { OrdenesTrabajoPage } from "@/components/ordenes-trabajo-page"

export default function OrdenesTrabajoRoute() {
  return (
    <DashboardLayout>
      <OrdenesTrabajoPage />
    </DashboardLayout>
  )
}
