import { DashboardLayout } from "@/components/dashboard-layout"
import { UsuariosPage } from "@/components/usuarios-page"

export default function Usuarios() {
  return (
    <DashboardLayout>
      <UsuariosPage />
    </DashboardLayout>
  )
}
