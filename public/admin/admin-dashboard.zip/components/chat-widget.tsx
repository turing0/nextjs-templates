"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useAppContext } from "@/contexts/app-context"
import { Bot, Send, X, MessageSquare, AlertCircle, Package, ClipboardList, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Message {
  id: number
  content: string
  sender: "user" | "bot"
  timestamp: Date
  suggestions?: string[]
  isTyping?: boolean
  category?: "info" | "warning" | "success" | "error"
}

export function ChatWidget() {
  const { products, tickets, sales, workOrders, maintenanceEvents } = useAppContext()
  const [isOpen, setIsOpen] = useState(false)
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>(() => {
    // Intentar recuperar mensajes del localStorage
    try {
      const savedMessages = localStorage.getItem("chat:messages")
      if (savedMessages) {
        // Convertir los timestamps de string a objetos Date
        const parsedMessages = JSON.parse(savedMessages)
        return parsedMessages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
        }))
      } else {
        return [
          {
            id: 1,
            content: "¡Hola! Soy tu asistente virtual. ¿En qué puedo ayudarte hoy?",
            sender: "bot",
            timestamp: new Date(),
            suggestions: ["Consultar inventario", "Crear ticket", "Generar cotización", "Ver ventas"],
          },
        ]
      }
    } catch (error) {
      console.error("Error al cargar mensajes del chat:", error)
      return [
        {
          id: 1,
          content: "¡Hola! Soy tu asistente virtual. ¿En qué puedo ayudarte hoy?",
          sender: "bot",
          timestamp: new Date(),
          suggestions: ["Consultar inventario", "Crear ticket", "Generar cotización", "Ver ventas"],
        },
      ]
    }
  })
  const [unreadCount, setUnreadCount] = useState(1)
  const [isTyping, setIsTyping] = useState(false)
  const [conversationContext, setConversationContext] = useState<string[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Guardar mensajes en localStorage cuando cambien
  useEffect(() => {
    try {
      localStorage.setItem("chat:messages", JSON.stringify(messages))
    } catch (error) {
      console.error("Error al guardar mensajes del chat:", error)
    }
  }, [messages])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, isTyping])

  // Focus input when chat is opened
  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus()
      setUnreadCount(0)
    }
  }, [isOpen])

  // Simulate proactive messages based on system state
  useEffect(() => {
    if (!isOpen) {
      // Verificar productos con stock crítico
      const criticalProducts = products.filter((p) => p.status === "critical")
      if (criticalProducts.length > 0 && Math.random() > 0.7) {
        const proactiveMessage: Message = {
          id: Date.now(),
          content: `Alerta: Tienes ${criticalProducts.length} productos con stock crítico que requieren atención.`,
          sender: "bot",
          timestamp: new Date(),
          category: "warning",
          suggestions: ["Ver productos críticos", "Generar orden de compra", "Ignorar por ahora"],
        }
        setMessages((prev) => [...prev, proactiveMessage])
        setUnreadCount((prev) => prev + 1)
        return
      }

      // Verificar tickets pendientes
      const pendingTickets = tickets.filter((t) => t.status === "pendiente")
      if (pendingTickets.length > 0 && Math.random() > 0.8) {
        const proactiveMessage: Message = {
          id: Date.now(),
          content: `Recordatorio: Tienes ${pendingTickets.length} tickets pendientes por atender.`,
          sender: "bot",
          timestamp: new Date(),
          category: "info",
          suggestions: ["Ver tickets pendientes", "Asignar tickets", "Recordar más tarde"],
        }
        setMessages((prev) => [...prev, proactiveMessage])
        setUnreadCount((prev) => prev + 1)
        return
      }

      // Verificar mantenimientos próximos
      const upcomingMaintenance = maintenanceEvents.filter((e) => {
        const eventDate = new Date(e.date)
        const today = new Date()
        const diffTime = eventDate.getTime() - today.getTime()
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
        return diffDays <= 3 && diffDays >= 0 && e.status === "pendiente"
      })

      if (upcomingMaintenance.length > 0 && Math.random() > 0.7) {
        const proactiveMessage: Message = {
          id: Date.now(),
          content: `Recordatorio: Tienes ${upcomingMaintenance.length} mantenimientos programados para los próximos 3 días.`,
          sender: "bot",
          timestamp: new Date(),
          category: "info",
          suggestions: ["Ver calendario", "Detalles de mantenimientos", "Recordar más tarde"],
        }
        setMessages((prev) => [...prev, proactiveMessage])
        setUnreadCount((prev) => prev + 1)
        return
      }
    }
  }, [isOpen, products, tickets, maintenanceEvents])

  const toggleChat = () => {
    setIsOpen(!isOpen)
    if (!isOpen) {
      setUnreadCount(0)
    }
  }

  const handleSend = () => {
    if (input.trim() === "") return

    // Add user message
    const userMessage: Message = {
      id: Date.now(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])

    // Actualizar contexto de la conversación
    setConversationContext((prev) => [...prev, input.toLowerCase()])

    setInput("")
    setIsTyping(true)

    // Simulate bot response
    setTimeout(
      () => {
        generateBotResponse(input)
      },
      500 + Math.random() * 1000,
    ) // Tiempo variable para parecer más natural
  }

  const handleSuggestionClick = (suggestion: string) => {
    // Add user message based on suggestion
    const userMessage: Message = {
      id: Date.now(),
      content: suggestion,
      sender: "user",
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])

    // Actualizar contexto de la conversación
    setConversationContext((prev) => [...prev, suggestion.toLowerCase()])

    setIsTyping(true)

    // Simulate bot response
    setTimeout(
      () => {
        generateBotResponse(suggestion)
      },
      500 + Math.random() * 1000,
    )
  }

  // Función mejorada para generar respuestas más inteligentes
  const generateBotResponse = (userInput: string) => {
    const input = userInput.toLowerCase().trim()
    let response = ""
    let suggestions: string[] = []
    let category: Message["category"] = "info"

    try {
      // Usar el contexto de la conversación para generar respuestas más relevantes
      const context = [...conversationContext]

      // Detectar intención del usuario
      const isAskingAboutInventory =
        input.includes("inventario") || input.includes("stock") || input.includes("producto")
      const isAskingAboutTickets = input.includes("ticket") || input.includes("soporte") || input.includes("problema")
      const isAskingAboutSales = input.includes("venta") || input.includes("factura") || input.includes("orden")
      const isAskingAboutMaintenance =
        input.includes("mantenimiento") || input.includes("calendario") || input.includes("agenda")
      const isGreeting = input.includes("hola") || input.includes("buenos días") || input.includes("buenas tardes")
      const isThanking = input.includes("gracias") || input.includes("genial") || input.includes("excelente")
      const isAskingForHelp = input.includes("ayuda") || input.includes("cómo") || input.includes("como")

      // Respuestas basadas en la intención detectada
      if (isGreeting) {
        response = "¡Hola! Estoy aquí para ayudarte con la gestión del sistema. ¿En qué puedo asistirte hoy?"
        suggestions = [
          "Consultar inventario",
          "Ver tickets pendientes",
          "Crear orden de trabajo",
          "Calendario de mantenimiento",
        ]
      } else if (isAskingAboutInventory) {
        // Proporcionar información real sobre el inventario
        const totalProducts = products.length || 0
        const lowStockProducts = products.filter((p) => p.status === "low").length || 0
        const criticalStockProducts = products.filter((p) => p.status === "critical").length || 0

        if (input.includes("crítico") || input.includes("critico") || input.includes("bajo")) {
          response = `Actualmente tienes ${criticalStockProducts} productos en estado crítico y ${lowStockProducts} con stock bajo. ¿Quieres ver el detalle o generar una orden de compra?`
          suggestions = ["Ver productos críticos", "Generar orden de compra", "Ir a inventario"]
          category = criticalStockProducts > 0 ? "warning" : "info"
        } else {
          response = `El inventario cuenta con ${totalProducts} productos en total. ${lowStockProducts + criticalStockProducts} requieren atención por stock bajo.`
          suggestions = ["Ver detalles", "Filtrar por categoría", "Agregar producto"]
        }
      } else if (isAskingAboutTickets) {
        // Proporcionar información real sobre tickets
        const totalTickets = tickets.length || 0
        const pendingTickets = tickets.filter((t) => t.status === "pendiente").length || 0
        const inProgressTickets = tickets.filter((t) => t.status === "en_progreso").length || 0

        response = `El sistema tiene ${totalTickets} tickets en total. Hay ${pendingTickets} pendientes y ${inProgressTickets} en progreso.`
        suggestions = ["Tickets pendientes", "Tickets por técnico", "Crear ticket"]
      } else if (isAskingAboutSales || isAskingAboutMaintenance || isThanking || isAskingForHelp) {
        // Respuestas para otras intenciones
        response = "Estoy aquí para ayudarte. ¿Qué información específica necesitas?"
        suggestions = ["Inventario", "Tickets", "Ventas", "Mantenimientos"]
      } else {
        // Respuesta genérica
        response = "Estoy aquí para ayudarte con la gestión del sistema. ¿En qué puedo asistirte?"
        suggestions = ["Inventario", "Tickets", "Ventas", "Órdenes de trabajo", "Mantenimientos"]
      }

      // Añadir la respuesta del bot
      setIsTyping(false)
      const botMessage: Message = {
        id: Date.now(),
        content: response,
        sender: "bot",
        timestamp: new Date(),
        suggestions: suggestions,
        category: category,
      }

      setMessages((prev) => [...prev, botMessage])
    } catch (error) {
      console.error("Error al generar respuesta:", error)
      // Respuesta de fallback en caso de error
      setIsTyping(false)
      const errorMessage: Message = {
        id: Date.now(),
        content: "Lo siento, ha ocurrido un error al procesar tu solicitud. ¿Puedo ayudarte con algo más?",
        sender: "bot",
        timestamp: new Date(),
        suggestions: ["Inventario", "Tickets", "Ventas", "Mantenimientos"],
        category: "error",
      }
      setMessages((prev) => [...prev, errorMessage])
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSend()
    }
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end">
      {/* Chat button with notification badge */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={toggleChat}
              className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-all hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              aria-label={isOpen ? "Cerrar chat" : "Abrir chat"}
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <>
                  <MessageSquare className="h-6 w-6" />
                  {unreadCount > 0 && (
                    <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-xs font-bold text-destructive-foreground animate-pulse">
                      {unreadCount}
                    </span>
                  )}
                </>
              )}
            </button>
          </TooltipTrigger>
          <TooltipContent side="left">{isOpen ? "Cerrar asistente" : "Abrir asistente virtual"}</TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {/* Chat window */}
      <div
        className={`mt-4 flex w-80 flex-col overflow-hidden rounded-lg bg-card shadow-xl transition-all duration-300 ease-in-out sm:w-96 ${
          isOpen ? "h-[500px] opacity-100" : "h-0 opacity-0"
        }`}
      >
        {/* Chat header */}
        <div className="flex items-center justify-between border-b bg-primary p-4 text-primary-foreground">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder-bot.jpg" alt="Bot" />
              <AvatarFallback className="bg-primary-foreground text-primary">
                <Bot className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-sm font-medium">Asistente Virtual</h3>
              <p className="text-xs opacity-80">Siempre disponible</p>
            </div>
          </div>
          <button
            onClick={toggleChat}
            className="rounded-full p-1 hover:bg-primary-foreground/20 focus:outline-none focus:ring-2 focus:ring-primary-foreground/50"
            aria-label="Cerrar chat"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Chat messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
              {message.sender === "bot" && (
                <Avatar className="mr-2 h-8 w-8 flex-shrink-0 self-end">
                  <AvatarImage src="/placeholder-bot.jpg" alt="Bot" />
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : message.category === "warning"
                      ? "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300"
                      : message.category === "error"
                        ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                        : message.category === "success"
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                          : "bg-muted text-foreground"
                }`}
              >
                {message.category === "warning" && (
                  <div className="flex items-center gap-1 mb-1 text-amber-800 dark:text-amber-300">
                    <AlertCircle className="h-4 w-4" />
                    <span className="text-xs font-medium">Alerta</span>
                  </div>
                )}
                {message.category === "info" && message.content.includes("inventario") && (
                  <div className="flex items-center gap-1 mb-1 text-blue-800 dark:text-blue-300">
                    <Package className="h-4 w-4" />
                    <span className="text-xs font-medium">Inventario</span>
                  </div>
                )}
                {message.category === "info" && message.content.includes("ticket") && (
                  <div className="flex items-center gap-1 mb-1 text-blue-800 dark:text-blue-300">
                    <ClipboardList className="h-4 w-4" />
                    <span className="text-xs font-medium">Tickets</span>
                  </div>
                )}
                {message.category === "info" && message.content.includes("mantenimiento") && (
                  <div className="flex items-center gap-1 mb-1 text-blue-800 dark:text-blue-300">
                    <Calendar className="h-4 w-4" />
                    <span className="text-xs font-medium">Mantenimiento</span>
                  </div>
                )}
                <p className="whitespace-pre-wrap">{message.content}</p>
                {message.suggestions && message.suggestions.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {message.suggestions.map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => handleSuggestionClick(suggestion)}
                        className={`rounded-full px-3 py-1 text-xs transition-colors ${
                          message.sender === "user"
                            ? "bg-primary-foreground text-primary hover:bg-primary-foreground/90"
                            : message.category === "warning"
                              ? "bg-white text-amber-800 hover:bg-amber-50 dark:bg-amber-800 dark:text-amber-100 dark:hover:bg-amber-700"
                              : message.category === "error"
                                ? "bg-white text-red-800 hover:bg-red-50 dark:bg-red-800 dark:text-red-100 dark:hover:bg-red-700"
                                : message.category === "success"
                                  ? "bg-white text-green-800 hover:bg-green-50 dark:bg-green-800 dark:text-green-100 dark:hover:bg-green-700"
                                  : "bg-background text-foreground hover:bg-accent"
                        }`}
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                )}
                <span className="mt-1 block text-right text-xs opacity-70">
                  {typeof message.timestamp === "object" && message.timestamp instanceof Date
                    ? message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                    : new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
              {message.sender === "user" && (
                <Avatar className="ml-2 h-8 w-8 flex-shrink-0 self-end">
                  <AvatarImage src="/placeholder-user.jpg" alt="Usuario" />
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <Avatar className="mr-2 h-8 w-8 flex-shrink-0 self-end">
                <AvatarImage src="/placeholder-bot.jpg" alt="Bot" />
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <Bot className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="max-w-[80%] rounded-lg bg-muted p-3 text-foreground">
                <div className="flex space-x-1">
                  <div className="h-2 w-2 animate-bounce rounded-full bg-foreground/50"></div>
                  <div
                    className="h-2 w-2 animate-bounce rounded-full bg-foreground/50"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                  <div
                    className="h-2 w-2 animate-bounce rounded-full bg-foreground/50"
                    style={{ animationDelay: "0.4s" }}
                  ></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat input */}
        <div className="border-t p-4">
          <div className="flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Escribe tu mensaje..."
              className="flex-1 rounded-l-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              ref={inputRef}
            />
            <Button
              onClick={handleSend}
              disabled={input.trim() === ""}
              className="rounded-l-none rounded-r-lg"
              size="icon"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
