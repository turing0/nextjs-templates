"use client"

import { useState } from "react"
import { Moon, Save, Sun } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useTheme } from "next-themes"
import { useToast } from "@/hooks/use-toast"

export function ConfiguracionPage() {
  const { theme, setTheme } = useTheme()
  const [activeTab, setActiveTab] = useState("general")
  const [notifications, setNotifications] = useState(true)
  const [autoSave, setAutoSave] = useState(true)
  const [language, setLanguage] = useState("es-CL")
  const [dateFormat, setDateFormat] = useState("dd/MM/yyyy")
  const [lowStockAlert, setLowStockAlert] = useState(true)
  const [lowStockThreshold, setLowStockThreshold] = useState("5")
  const { toast } = useToast()

  const saveSettings = () => {
    toast({
      title: "Configuración guardada",
      description: "La configuración ha sido guardada correctamente.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Configuración</h2>
      </div>

      <Tabs defaultValue="general" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="apariencia">Apariencia</TabsTrigger>
          <TabsTrigger value="notificaciones">Notificaciones</TabsTrigger>
        </TabsList>

        <div className="mt-6 space-y-6">
          <TabsContent value="general" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Configuración General</CardTitle>
                <CardDescription>Ajuste las configuraciones generales del sistema.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="language">Idioma</Label>
                      <p className="text-sm text-muted-foreground">Seleccione el idioma del sistema.</p>
                    </div>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Seleccionar idioma" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="es-CL">Español (Chile)</SelectItem>
                        <SelectItem value="es-ES">Español (España)</SelectItem>
                        <SelectItem value="en-US">English (US)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="date-format">Formato de fecha</Label>
                      <p className="text-sm text-muted-foreground">Seleccione el formato de fecha preferido.</p>
                    </div>
                    <Select value={dateFormat} onValueChange={setDateFormat}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Seleccionar formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dd/MM/yyyy">DD/MM/AAAA</SelectItem>
                        <SelectItem value="MM/dd/yyyy">MM/DD/AAAA</SelectItem>
                        <SelectItem value="yyyy-MM-dd">AAAA-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="auto-save">Guardado automático</Label>
                      <p className="text-sm text-muted-foreground">
                        Guardar automáticamente los cambios realizados en formularios.
                      </p>
                    </div>
                    <Switch id="auto-save" checked={autoSave} onCheckedChange={setAutoSave} />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar Configuración
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="apariencia" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Apariencia</CardTitle>
                <CardDescription>Personalice la apariencia del sistema.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Tema</Label>
                      <p className="text-sm text-muted-foreground">Seleccione el tema del sistema.</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant={theme === "light" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheme("light")}
                        className="h-8 gap-1"
                      >
                        <Sun className="h-4 w-4" />
                        Claro
                      </Button>
                      <Button
                        variant={theme === "dark" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheme("dark")}
                        className="h-8 gap-1"
                      >
                        <Moon className="h-4 w-4" />
                        Oscuro
                      </Button>
                      <Button
                        variant={theme === "system" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheme("system")}
                        className="h-8"
                      >
                        Sistema
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Densidad de la interfaz</Label>
                      <p className="text-sm text-muted-foreground">
                        Ajuste la densidad de los elementos en la interfaz.
                      </p>
                    </div>
                    <Select defaultValue="normal">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Seleccionar densidad" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="compact">Compacta</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="comfortable">Cómoda</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Animaciones</Label>
                      <p className="text-sm text-muted-foreground">Habilitar animaciones en la interfaz.</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar Configuración
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notificaciones" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Notificaciones</CardTitle>
                <CardDescription>Configure las notificaciones del sistema.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="notifications">Notificaciones del sistema</Label>
                      <p className="text-sm text-muted-foreground">Recibir notificaciones sobre eventos del sistema.</p>
                    </div>
                    <Switch id="notifications" checked={notifications} onCheckedChange={setNotifications} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="low-stock-alert">Alertas de stock bajo</Label>
                      <p className="text-sm text-muted-foreground">
                        Recibir notificaciones cuando el stock de un producto esté bajo.
                      </p>
                    </div>
                    <Switch id="low-stock-alert" checked={lowStockAlert} onCheckedChange={setLowStockAlert} />
                  </div>

                  {lowStockAlert && (
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="low-stock-threshold">Umbral de stock bajo</Label>
                        <p className="text-sm text-muted-foreground">
                          Cantidad mínima para considerar un producto con stock bajo.
                        </p>
                      </div>
                      <Select value={lowStockThreshold} onValueChange={setLowStockThreshold}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Seleccionar umbral" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 unidades</SelectItem>
                          <SelectItem value="5">5 unidades</SelectItem>
                          <SelectItem value="10">10 unidades</SelectItem>
                          <SelectItem value="15">15 unidades</SelectItem>
                          <SelectItem value="20">20 unidades</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notificaciones por email</Label>
                      <p className="text-sm text-muted-foreground">
                        Recibir notificaciones importantes por correo electrónico.
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Recordatorios de seguimiento</Label>
                      <p className="text-sm text-muted-foreground">
                        Recibir recordatorios para seguimientos de clientes programados.
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar Configuración
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}
