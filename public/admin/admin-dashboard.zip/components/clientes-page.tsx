"use client"

import { useState, useEffect } from "react"
import { Calendar, Download, Edit, Filter, Plus, RefreshCw, Search, Trash2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

interface Client {
  id: number
  name: string
  company: string
  email: string
  phone: string
  address: string
  status: "no_contactado" | "contactado" | "seguimiento" | "cotizacion_solicitada" | "cotizacion_enviada" | "cerrado"
  lastContact: string | null
  nextContact: string | null
  notes: string[]
}

export function ClientesPage() {
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("clientes")
  const [newClient, setNewClient] = useState<Omit<Client, "id" | "notes" | "lastContact" | "nextContact">>({
    name: "",
    company: "",
    email: "",
    phone: "",
    address: "",
    status: "no_contactado",
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedClient, setSelectedClient] = useState<Client | null>(null)
  const [newNote, setNewNote] = useState("")
  const [newNextContact, setNewNextContact] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockClients: Client[] = [
        {
          id: 1,
          name: "Juan Pérez",
          company: "Empresa ABC Ltda.",
          email: "juan.perez@empresaabc.cl",
          phone: "+56 9 1234 5678",
          address: "Av. Providencia 1234, Santiago",
          status: "seguimiento",
          lastContact: "2025-04-10",
          nextContact: "2025-04-20",
          notes: ["Cliente interesado en renovar equipos de oficina.", "Solicita cotización para 20 equipos."],
        },
        {
          id: 2,
          name: "María González",
          company: "Comercial XYZ S.A.",
          email: "maria.gonzalez@comercialxyz.cl",
          phone: "+56 9 8765 4321",
          address: "Los Leones 567, Providencia",
          status: "cotizacion_solicitada",
          lastContact: "2025-04-12",
          nextContact: "2025-04-18",
          notes: ["Primera reunión realizada.", "Cliente solicitó cotización para 15 equipos."],
        },
        {
          id: 3,
          name: "Carlos Rodríguez",
          company: "Distribuidora Sur",
          email: "carlos.rodriguez@distribuidorasur.cl",
          phone: "+56 9 2345 6789",
          address: "Av. Las Condes 4321, Las Condes",
          status: "cerrado",
          lastContact: "2025-04-05",
          nextContact: null,
          notes: ["Cliente adquirió servicios de soporte anual.", "Contrato firmado el 05/04/2025."],
        },
        {
          id: 4,
          name: "Ana Martínez",
          company: "Tecnología Avanzada SpA",
          email: "ana.martinez@tecnologiaavanzada.cl",
          phone: "+56 9 3456 7890",
          address: "Nueva Costanera 789, Vitacura",
          status: "no_contactado",
          lastContact: null,
          nextContact: null,
          notes: ["Contacto obtenido en feria tecnológica.", "Pendiente primer acercamiento."],
        },
        {
          id: 5,
          name: "Pedro Sánchez",
          company: "Constructora Norte",
          email: "pedro.sanchez@constructoranorte.cl",
          phone: "+56 9 4567 8901",
          address: "Apoquindo 5678, Las Condes",
          status: "cotizacion_enviada",
          lastContact: "2025-04-08",
          nextContact: "2025-04-15",
          notes: ["Se envió cotización para sistema de seguridad.", "Pendiente de aprobación por parte del cliente."],
        },
      ]
      setClients(mockClients)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleAddClient = () => {
    const id = Math.max(0, ...clients.map((c) => c.id)) + 1

    const newClientComplete: Client = {
      ...newClient,
      id,
      lastContact: null,
      nextContact: null,
      notes: [],
    }

    setClients([newClientComplete, ...clients])
    setNewClient({
      name: "",
      company: "",
      email: "",
      phone: "",
      address: "",
      status: "no_contactado",
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Cliente agregado",
      description: `Se ha agregado el cliente "${newClient.name}" correctamente.`,
    })
  }

  const handleUpdateClientStatus = (id: number, status: Client["status"]) => {
    setClients(
      clients.map((client) => {
        if (client.id === id) {
          return {
            ...client,
            status,
            lastContact: status !== "no_contactado" ? new Date().toISOString().split("T")[0] : client.lastContact,
          }
        }
        return client
      }),
    )

    toast({
      title: "Estado actualizado",
      description: `El estado del cliente ha sido actualizado a "${getStatusLabel(status)}".`,
    })
  }

  const handleAddNote = () => {
    if (!selectedClient || !newNote.trim()) return

    const updatedClient = {
      ...selectedClient,
      notes: [...selectedClient.notes, newNote],
      lastContact: new Date().toISOString().split("T")[0],
    }

    setClients(clients.map((client) => (client.id === selectedClient.id ? updatedClient : client)))
    setSelectedClient(updatedClient)
    setNewNote("")

    toast({
      title: "Nota agregada",
      description: "Se ha agregado una nueva nota al cliente.",
    })
  }

  const handleSetNextContact = () => {
    if (!selectedClient || !newNextContact) return

    const updatedClient = {
      ...selectedClient,
      nextContact: newNextContact,
    }

    setClients(clients.map((client) => (client.id === selectedClient.id ? updatedClient : client)))
    setSelectedClient(updatedClient)
    setNewNextContact("")

    toast({
      title: "Seguimiento programado",
      description: `Se ha programado el próximo seguimiento para el ${formatDate(newNextContact)}.`,
    })
  }

  const filteredClients = clients.filter((client) => {
    const matchesSearch =
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || client.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando clientes",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Clientes actualizados",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos de clientes se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  const getStatusLabel = (status: Client["status"]) => {
    switch (status) {
      case "no_contactado":
        return "No Contactado"
      case "contactado":
        return "Contactado"
      case "seguimiento":
        return "Seguimiento"
      case "cotizacion_solicitada":
        return "Cotización Solicitada"
      case "cotizacion_enviada":
        return "Cotización Enviada"
      case "cerrado":
        return "Cerrado"
      default:
        return status
    }
  }

  const getStatusColor = (status: Client["status"]) => {
    switch (status) {
      case "no_contactado":
        return "bg-gray-500"
      case "contactado":
        return "bg-blue-500"
      case "seguimiento":
        return "bg-amber-500"
      case "cotizacion_solicitada":
        return "bg-purple-500"
      case "cotizacion_enviada":
        return "bg-indigo-500"
      case "cerrado":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "No programado"
    const date = new Date(dateString)
    return date.toLocaleDateString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Clientes y Seguimiento</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Agregar Cliente
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Cliente</DialogTitle>
                <DialogDescription>Complete los detalles del nuevo cliente.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="name" className="text-right">
                    Nombre
                  </label>
                  <Input
                    id="name"
                    value={newClient.name}
                    onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="company" className="text-right">
                    Empresa
                  </label>
                  <Input
                    id="company"
                    value={newClient.company}
                    onChange={(e) => setNewClient({ ...newClient, company: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="email" className="text-right">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={newClient.email}
                    onChange={(e) => setNewClient({ ...newClient, email: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="phone" className="text-right">
                    Teléfono
                  </label>
                  <Input
                    id="phone"
                    value={newClient.phone}
                    onChange={(e) => setNewClient({ ...newClient, phone: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="address" className="text-right">
                    Dirección
                  </label>
                  <Input
                    id="address"
                    value={newClient.address}
                    onChange={(e) => setNewClient({ ...newClient, address: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="status" className="text-right">
                    Estado
                  </label>
                  <Select
                    value={newClient.status}
                    onValueChange={(value: Client["status"]) => setNewClient({ ...newClient, status: value })}
                  >
                    <SelectTrigger id="status" className="col-span-3">
                      <SelectValue placeholder="Seleccionar estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="no_contactado">No Contactado</SelectItem>
                      <SelectItem value="contactado">Contactado</SelectItem>
                      <SelectItem value="seguimiento">Seguimiento</SelectItem>
                      <SelectItem value="cotizacion_solicitada">Cotización Solicitada</SelectItem>
                      <SelectItem value="cotizacion_enviada">Cotización Enviada</SelectItem>
                      <SelectItem value="cerrado">Cerrado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddClient} disabled={!newClient.name || !newClient.company}>
                  Guardar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="clientes" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="clientes">Clientes</TabsTrigger>
          <TabsTrigger value="seguimientos">Seguimientos</TabsTrigger>
        </TabsList>
        <TabsContent value="clientes" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Clientes</CardTitle>
              <CardDescription>Gestione sus clientes y su información de contacto.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex flex-col gap-4 md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nombre, empresa o email..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        Estado
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuLabel>Filtrar por estado</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setStatusFilter("all")}>Todos</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("no_contactado")}>
                        No Contactado
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("contactado")}>Contactado</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("seguimiento")}>Seguimiento</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("cotizacion_solicitada")}>
                        Cotización Solicitada
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("cotizacion_enviada")}>
                        Cotización Enviada
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("cerrado")}>Cerrado</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead>Contacto</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Último Contacto</TableHead>
                      <TableHead>Próximo Contacto</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-6 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filteredClients.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          No se encontraron clientes.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredClients.map((client) => (
                        <TableRow key={client.id}>
                          <TableCell className="font-medium">{client.name}</TableCell>
                          <TableCell>{client.company}</TableCell>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="text-xs">{client.email}</span>
                              <span className="text-xs text-muted-foreground">{client.phone}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(client.status)}>{getStatusLabel(client.status)}</Badge>
                          </TableCell>
                          <TableCell>{client.lastContact ? formatDate(client.lastContact) : "Nunca"}</TableCell>
                          <TableCell>{formatDate(client.nextContact)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="ghost" size="icon" onClick={() => setSelectedClient(client)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-h-[90vh] overflow-y-auto">
                                  <DialogHeader>
                                    <DialogTitle>Gestionar Cliente</DialogTitle>
                                    <DialogDescription>
                                      Actualice la información y seguimiento del cliente.
                                    </DialogDescription>
                                  </DialogHeader>
                                  {selectedClient && (
                                    <div className="grid gap-4 py-4">
                                      <div className="flex flex-col gap-2">
                                        <h3 className="text-lg font-medium">{selectedClient.name}</h3>
                                        <p className="text-sm text-muted-foreground">{selectedClient.company}</p>
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <label htmlFor="update-status" className="text-right">
                                          Estado
                                        </label>
                                        <Select
                                          value={selectedClient.status}
                                          onValueChange={(value: Client["status"]) =>
                                            setSelectedClient({ ...selectedClient, status: value })
                                          }
                                        >
                                          <SelectTrigger id="update-status" className="col-span-3">
                                            <SelectValue placeholder="Seleccionar estado" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="no_contactado">No Contactado</SelectItem>
                                            <SelectItem value="contactado">Contactado</SelectItem>
                                            <SelectItem value="seguimiento">Seguimiento</SelectItem>
                                            <SelectItem value="cotizacion_solicitada">Cotización Solicitada</SelectItem>
                                            <SelectItem value="cotizacion_enviada">Cotización Enviada</SelectItem>
                                            <SelectItem value="cerrado">Cerrado</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <label htmlFor="next-contact" className="text-right">
                                          Próximo Contacto
                                        </label>
                                        <div className="col-span-3 flex items-center gap-2">
                                          <Calendar className="h-4 w-4 text-muted-foreground" />
                                          <Input
                                            id="next-contact"
                                            type="date"
                                            value={newNextContact}
                                            onChange={(e) => setNewNextContact(e.target.value)}
                                          />
                                          <Button onClick={handleSetNextContact} disabled={!newNextContact}>
                                            Programar
                                          </Button>
                                        </div>
                                      </div>
                                      <div className="grid grid-cols-4 items-start gap-4">
                                        <label htmlFor="new-note" className="text-right pt-2">
                                          Nueva Nota
                                        </label>
                                        <div className="col-span-3 space-y-2">
                                          <Textarea
                                            id="new-note"
                                            value={newNote}
                                            onChange={(e) => setNewNote(e.target.value)}
                                            rows={2}
                                          />
                                          <Button onClick={handleAddNote} disabled={!newNote.trim()}>
                                            Agregar Nota
                                          </Button>
                                        </div>
                                      </div>
                                      <div className="mt-4 border-t pt-4">
                                        <h4 className="mb-2 font-medium">Historial de Notas</h4>
                                        {selectedClient.notes.length === 0 ? (
                                          <p className="text-sm text-muted-foreground">No hay notas registradas.</p>
                                        ) : (
                                          <div className="space-y-2">
                                            {selectedClient.notes.map((note, index) => (
                                              <div key={index} className="rounded-md border p-3">
                                                <p className="text-sm">{note}</p>
                                              </div>
                                            ))}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setSelectedClient(null)}>
                                      Cerrar
                                    </Button>
                                    <Button
                                      onClick={() => {
                                        if (selectedClient) {
                                          handleUpdateClientStatus(selectedClient.id, selectedClient.status)
                                          setSelectedClient(null)
                                        }
                                      }}
                                    >
                                      Guardar Cambios
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="seguimientos" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Seguimientos Programados</CardTitle>
              <CardDescription>Visualice y gestione los próximos seguimientos a clientes.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead>Fecha de Seguimiento</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading
                      ? Array.from({ length: 3 }).map((_, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                            </TableCell>
                            <TableCell>
                              <div className="h-6 w-24 animate-pulse rounded bg-muted"></div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                                <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      : clients
                          .filter((client) => client.nextContact !== null)
                          .sort((a, b) => {
                            if (!a.nextContact) return 1
                            if (!b.nextContact) return -1
                            return new Date(a.nextContact).getTime() - new Date(b.nextContact).getTime()
                          })
                          .map((client) => (
                            <TableRow key={client.id}>
                              <TableCell className="font-medium">{client.name}</TableCell>
                              <TableCell>{client.company}</TableCell>
                              <TableCell>{formatDate(client.nextContact)}</TableCell>
                              <TableCell>
                                <Badge className={getStatusColor(client.status)}>{getStatusLabel(client.status)}</Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="ghost" size="icon" onClick={() => setSelectedClient(client)}>
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent>
                                      <DialogHeader>
                                        <DialogTitle>Registrar Seguimiento</DialogTitle>
                                        <DialogDescription>
                                          Registre el resultado del seguimiento y programe el próximo contacto.
                                        </DialogDescription>
                                      </DialogHeader>
                                      {selectedClient && (
                                        <div className="grid gap-4 py-4">
                                          <div className="flex flex-col gap-2">
                                            <h3 className="text-lg font-medium">{selectedClient.name}</h3>
                                            <p className="text-sm text-muted-foreground">{selectedClient.company}</p>
                                          </div>
                                          <div className="grid grid-cols-4 items-start gap-4">
                                            <label htmlFor="follow-up-note" className="text-right pt-2">
                                              Resultado
                                            </label>
                                            <Textarea
                                              id="follow-up-note"
                                              value={newNote}
                                              onChange={(e) => setNewNote(e.target.value)}
                                              className="col-span-3"
                                              rows={3}
                                            />
                                          </div>
                                          <div className="grid grid-cols-4 items-center gap-4">
                                            <label htmlFor="next-follow-up" className="text-right">
                                              Próximo Contacto
                                            </label>
                                            <div className="col-span-3 flex items-center gap-2">
                                              <Calendar className="h-4 w-4 text-muted-foreground" />
                                              <Input
                                                id="next-follow-up"
                                                type="date"
                                                value={newNextContact}
                                                onChange={(e) => setNewNextContact(e.target.value)}
                                              />
                                            </div>
                                          </div>
                                          <div className="grid grid-cols-4 items-center gap-4">
                                            <label htmlFor="follow-up-status" className="text-right">
                                              Actualizar Estado
                                            </label>
                                            <Select
                                              value={selectedClient.status}
                                              onValueChange={(value: Client["status"]) =>
                                                setSelectedClient({ ...selectedClient, status: value })
                                              }
                                            >
                                              <SelectTrigger id="follow-up-status" className="col-span-3">
                                                <SelectValue placeholder="Seleccionar estado" />
                                              </SelectTrigger>
                                              <SelectContent>
                                                <SelectItem value="no_contactado">No Contactado</SelectItem>
                                                <SelectItem value="contactado">Contactado</SelectItem>
                                                <SelectItem value="seguimiento">Seguimiento</SelectItem>
                                                <SelectItem value="cotizacion_solicitada">
                                                  Cotización Solicitada
                                                </SelectItem>
                                                <SelectItem value="cotizacion_enviada">Cotización Enviada</SelectItem>
                                                <SelectItem value="cerrado">Cerrado</SelectItem>
                                              </SelectContent>
                                            </Select>
                                          </div>
                                        </div>
                                      )}
                                      <DialogFooter>
                                        <Button variant="outline" onClick={() => setSelectedClient(null)}>
                                          Cancelar
                                        </Button>
                                        <Button
                                          onClick={() => {
                                            if (selectedClient && newNote.trim()) {
                                              handleAddNote()
                                              if (newNextContact) {
                                                handleSetNextContact()
                                              }
                                              handleUpdateClientStatus(selectedClient.id, selectedClient.status)
                                              setSelectedClient(null)
                                            }
                                          }}
                                          disabled={!newNote.trim()}
                                        >
                                          Guardar Seguimiento
                                        </Button>
                                      </DialogFooter>
                                    </DialogContent>
                                  </Dialog>
                                  <Button variant="ghost" size="icon">
                                    <Calendar className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
