"use client"

import { useState, useEffect } from "react"
import {
  ArrowDown,
  ArrowUp,
  Box,
  ClipboardList,
  DollarSign,
  Package,
  Plus,
  RefreshCw,
  ShoppingCart,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { InventoryChart } from "@/components/inventory-chart"
import { useToast } from "@/hooks/use-toast"

export function DashboardMain() {
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("dia")
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando datos",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Datos actualizados",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center gap-2">
          <Button onClick={refreshData} disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar datos
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="dashboard-card hover-scale animate-slide-up" style={{ animationDelay: "0ms" }}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Productos</CardTitle>
            <Package className="h-4 w-4 text-primary animate-pulse" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,248</div>
            <p className="text-xs text-muted-foreground">+24 productos nuevos hoy</p>
          </CardContent>
        </Card>
        <Card className="dashboard-card hover-scale animate-slide-up" style={{ animationDelay: "100ms" }}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Movimientos Hoy</CardTitle>
            <Box className="h-4 w-4 text-primary animate-pulse" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className="text-2xl font-bold">+86</div>
              <Badge variant="outline" className="bg-green-50 text-green-700 dark:bg-green-900 dark:text-green-300">
                <ArrowUp className="mr-1 h-3 w-3" />
                12%
              </Badge>
            </div>
            <div className="mt-1 flex items-center gap-2">
              <div className="text-2xl font-bold">-42</div>
              <Badge variant="outline" className="bg-red-50 text-red-700 dark:bg-red-900 dark:text-red-300">
                <ArrowDown className="mr-1 h-3 w-3" />
                8%
              </Badge>
            </div>
          </CardContent>
        </Card>
        <Card className="dashboard-card animate-slide-up" style={{ animationDelay: "200ms" }}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Tickets Activos</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">8 pendientes, 16 en progreso</p>
          </CardContent>
        </Card>
        <Card className="dashboard-card animate-slide-up" style={{ animationDelay: "300ms" }}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Valor Inventario</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$124.568.900</div>
            <p className="text-xs text-muted-foreground">+2,4% desde el mes pasado</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        <Card className="dashboard-card md:col-span-5 animate-slide-up" style={{ animationDelay: "400ms" }}>
          <CardHeader>
            <CardTitle>Movimientos de Inventario</CardTitle>
            <CardDescription>Visualización de entradas y salidas de productos</CardDescription>
            <Tabs defaultValue="dia" className="mt-2" onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="dia">Día</TabsTrigger>
                <TabsTrigger value="semana">Semana</TabsTrigger>
                <TabsTrigger value="mes">Mes</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          <CardContent>
            <InventoryChart period={activeTab} />
          </CardContent>
        </Card>
        <Card className="dashboard-card md:col-span-2 animate-slide-up" style={{ animationDelay: "500ms" }}>
          <CardHeader>
            <CardTitle>Alertas Recientes</CardTitle>
            <CardDescription>Notificaciones importantes del sistema</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950 dark:border-amber-800 animate-slide-in hover-scale">
              <AlertTitle className="text-amber-800 dark:text-amber-300 flex items-center gap-2">
                <Box className="h-4 w-4 animate-pulse" />
                Stock Bajo
              </AlertTitle>
              <AlertDescription className="text-amber-700 dark:text-amber-400">
                5 productos con stock crítico
              </AlertDescription>
            </Alert>
            <Alert
              className="border-blue-500 bg-blue-50 dark:bg-blue-950 dark:border-blue-800 animate-slide-in hover-scale"
              style={{ animationDelay: "100ms" }}
            >
              <AlertTitle className="text-blue-800 dark:text-blue-300 flex items-center gap-2">
                <ClipboardList className="h-4 w-4 animate-pulse" />
                Tickets Pendientes
              </AlertTitle>
              <AlertDescription className="text-blue-700 dark:text-blue-400">
                8 tickets requieren atención
              </AlertDescription>
            </Alert>
            <Alert
              className="border-green-500 bg-green-50 dark:bg-green-950 dark:border-green-800 animate-slide-in hover-scale"
              style={{ animationDelay: "200ms" }}
            >
              <AlertTitle className="text-green-800 dark:text-green-300 flex items-center gap-2">
                <ShoppingCart className="h-4 w-4 animate-pulse" />
                Ventas Completadas
              </AlertTitle>
              <AlertDescription className="text-green-700 dark:text-green-400">
                12 ventas completadas hoy
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      <Card className="dashboard-card animate-slide-up" style={{ animationDelay: "600ms" }}>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Órdenes Recientes</CardTitle>
            <CardDescription>Últimas órdenes de trabajo registradas</CardDescription>
          </div>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Nueva Orden
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Orden #</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead className="text-right">Monto</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">ORD-1234</TableCell>
                <TableCell>Empresa ABC Ltda.</TableCell>
                <TableCell>14/04/2025</TableCell>
                <TableCell>
                  <Badge className="bg-amber-500">En Proceso</Badge>
                </TableCell>
                <TableCell className="text-right">$1.250.000</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">ORD-1233</TableCell>
                <TableCell>Comercial XYZ S.A.</TableCell>
                <TableCell>14/04/2025</TableCell>
                <TableCell>
                  <Badge className="bg-green-500">Completada</Badge>
                </TableCell>
                <TableCell className="text-right">$850.000</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">ORD-1232</TableCell>
                <TableCell>Distribuidora Sur</TableCell>
                <TableCell>13/04/2025</TableCell>
                <TableCell>
                  <Badge className="bg-blue-500">Enviada</Badge>
                </TableCell>
                <TableCell className="text-right">$2.450.000</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">ORD-1231</TableCell>
                <TableCell>Tecnología Avanzada SpA</TableCell>
                <TableCell>13/04/2025</TableCell>
                <TableCell>
                  <Badge className="bg-green-500">Completada</Badge>
                </TableCell>
                <TableCell className="text-right">$3.150.000</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">ORD-1230</TableCell>
                <TableCell>Constructora Norte</TableCell>
                <TableCell>12/04/2025</TableCell>
                <TableCell>
                  <Badge className="bg-red-500">Cancelada</Badge>
                </TableCell>
                <TableCell className="text-right">$750.000</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
