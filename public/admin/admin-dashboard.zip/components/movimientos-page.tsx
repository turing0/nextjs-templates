"use client"

import { useState, useEffect } from "react"
import { ArrowDown, ArrowUp, Calendar, Download, Filter, Plus, RefreshCw, Search } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { InventoryChart } from "@/components/inventory-chart"
import { useToast } from "@/hooks/use-toast"

interface Movement {
  id: number
  date: string
  type: "entrada" | "salida"
  productName: string
  sku: string
  quantity: number
  user: string
  notes: string
}

export function MovimientosPage() {
  const [movements, setMovements] = useState<Movement[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("lista")
  const [newMovement, setNewMovement] = useState<Omit<Movement, "id">>({
    date: new Date().toISOString().split("T")[0],
    type: "entrada",
    productName: "",
    sku: "",
    quantity: 1,
    user: "Admin",
    notes: "",
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockMovements: Movement[] = [
        {
          id: 1,
          date: "2025-04-14",
          type: "entrada",
          productName: 'Monitor LG 24"',
          sku: "MON-LG-24",
          quantity: 5,
          user: "Juan Pérez",
          notes: "Reposición de stock",
        },
        {
          id: 2,
          date: "2025-04-14",
          type: "salida",
          productName: "Teclado Mecánico RGB",
          sku: "TEC-MEC-01",
          quantity: 2,
          user: "María González",
          notes: "Venta #1234",
        },
        {
          id: 3,
          date: "2025-04-13",
          type: "entrada",
          productName: "Mouse Inalámbrico",
          sku: "MOU-IN-02",
          quantity: 10,
          user: "Juan Pérez",
          notes: "Compra a proveedor",
        },
        {
          id: 4,
          date: "2025-04-13",
          type: "salida",
          productName: "Disco SSD 500GB",
          sku: "SSD-500-01",
          quantity: 3,
          user: "Carlos Rodríguez",
          notes: "Venta #1235",
        },
        {
          id: 5,
          date: "2025-04-12",
          type: "entrada",
          productName: "Memoria RAM 16GB",
          sku: "RAM-16-01",
          quantity: 8,
          user: "Juan Pérez",
          notes: "Reposición de stock",
        },
        {
          id: 6,
          date: "2025-04-12",
          type: "salida",
          productName: "Licencia Windows 11",
          sku: "WIN-11-PRO",
          quantity: 2,
          user: "María González",
          notes: "Venta #1236",
        },
        {
          id: 7,
          date: "2025-04-11",
          type: "entrada",
          productName: "Cable HDMI 2m",
          sku: "CAB-HDMI-2",
          quantity: 15,
          user: "Carlos Rodríguez",
          notes: "Compra a proveedor",
        },
        {
          id: 8,
          date: "2025-04-11",
          type: "salida",
          productName: "Adaptador USB-C",
          sku: "ADP-USBC-01",
          quantity: 4,
          user: "Juan Pérez",
          notes: "Venta #1237",
        },
        {
          id: 9,
          date: "2025-04-10",
          type: "entrada",
          productName: "Webcam HD",
          sku: "WEB-HD-01",
          quantity: 6,
          user: "María González",
          notes: "Reposición de stock",
        },
        {
          id: 10,
          date: "2025-04-10",
          type: "salida",
          productName: 'Monitor LG 24"',
          sku: "MON-LG-24",
          quantity: 1,
          user: "Carlos Rodríguez",
          notes: "Venta #1238",
        },
      ]
      setMovements(mockMovements)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleAddMovement = () => {
    const id = Math.max(0, ...movements.map((m) => m.id)) + 1

    setMovements([{ ...newMovement, id }, ...movements])
    setNewMovement({
      date: new Date().toISOString().split("T")[0],
      type: "entrada",
      productName: "",
      sku: "",
      quantity: 1,
      user: "Admin",
      notes: "",
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Movimiento registrado",
      description: `Se ha registrado un ${newMovement.type} de ${newMovement.quantity} unidades de ${newMovement.productName}.`,
    })
  }

  const filteredMovements = movements.filter((movement) => {
    const matchesSearch =
      movement.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.notes.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = typeFilter === "all" || movement.type === typeFilter

    return matchesSearch && matchesType
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando movimientos",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Movimientos actualizados",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos de movimientos se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Movimientos</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Registrar Movimiento
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Registrar Nuevo Movimiento</DialogTitle>
                <DialogDescription>Complete los detalles del movimiento de inventario.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="date" className="text-right">
                    Fecha
                  </label>
                  <div className="col-span-3 flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <Input
                      id="date"
                      type="date"
                      value={newMovement.date}
                      onChange={(e) => setNewMovement({ ...newMovement, date: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="type" className="text-right">
                    Tipo
                  </label>
                  <Select
                    value={newMovement.type}
                    onValueChange={(value: "entrada" | "salida") => setNewMovement({ ...newMovement, type: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="entrada">Entrada</SelectItem>
                      <SelectItem value="salida">Salida</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="productName" className="text-right">
                    Producto
                  </label>
                  <Input
                    id="productName"
                    value={newMovement.productName}
                    onChange={(e) => setNewMovement({ ...newMovement, productName: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="sku" className="text-right">
                    SKU
                  </label>
                  <Input
                    id="sku"
                    value={newMovement.sku}
                    onChange={(e) => setNewMovement({ ...newMovement, sku: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="quantity" className="text-right">
                    Cantidad
                  </label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    value={newMovement.quantity}
                    onChange={(e) => setNewMovement({ ...newMovement, quantity: Number.parseInt(e.target.value) || 1 })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="notes" className="text-right">
                    Notas
                  </label>
                  <Input
                    id="notes"
                    value={newMovement.notes}
                    onChange={(e) => setNewMovement({ ...newMovement, notes: e.target.value })}
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleAddMovement}
                  disabled={!newMovement.productName || !newMovement.sku || newMovement.quantity < 1}
                >
                  Guardar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="lista" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="lista">Lista de Movimientos</TabsTrigger>
          <TabsTrigger value="grafico">Gráfico</TabsTrigger>
        </TabsList>
        <TabsContent value="lista" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Registro de Movimientos</CardTitle>
              <CardDescription>Historial de entradas y salidas de productos del inventario.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex flex-col gap-4 md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por producto, SKU o notas..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        Tipo
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuLabel>Filtrar por tipo</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setTypeFilter("all")}>Todos</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setTypeFilter("entrada")}>Entradas</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setTypeFilter("salida")}>Salidas</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Producto</TableHead>
                      <TableHead>SKU</TableHead>
                      <TableHead className="text-center">Cantidad</TableHead>
                      <TableHead>Usuario</TableHead>
                      <TableHead>Notas</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-16 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-20 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="mx-auto h-4 w-8 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filteredMovements.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          No se encontraron movimientos.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredMovements.map((movement) => (
                        <TableRow key={movement.id}>
                          <TableCell>{formatDate(movement.date)}</TableCell>
                          <TableCell>
                            <Badge
                              className={`${
                                movement.type === "entrada"
                                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                  : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                              }`}
                            >
                              {movement.type === "entrada" ? (
                                <ArrowUp className="mr-1 h-3 w-3" />
                              ) : (
                                <ArrowDown className="mr-1 h-3 w-3" />
                              )}
                              {movement.type === "entrada" ? "Entrada" : "Salida"}
                            </Badge>
                          </TableCell>
                          <TableCell>{movement.productName}</TableCell>
                          <TableCell>{movement.sku}</TableCell>
                          <TableCell className="text-center">{movement.quantity}</TableCell>
                          <TableCell>{movement.user}</TableCell>
                          <TableCell>{movement.notes}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="grafico" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Gráfico de Movimientos</CardTitle>
              <CardDescription>Visualización de entradas y salidas de productos</CardDescription>
              <Tabs defaultValue="dia" className="mt-2">
                <TabsList>
                  <TabsTrigger value="dia">Día</TabsTrigger>
                  <TabsTrigger value="semana">Semana</TabsTrigger>
                  <TabsTrigger value="mes">Mes</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <InventoryChart period="dia" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function formatDate(dateString: string) {
  const date = new Date(dateString)
  return date.toLocaleDateString("es-CL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })
}
