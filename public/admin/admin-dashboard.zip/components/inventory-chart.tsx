"use client"

import { useEffect, useState } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { useTheme } from "next-themes"

interface InventoryChartProps {
  period: string
}

export function InventoryChart({ period }: InventoryChartProps) {
  const { theme } = useTheme()
  const [chartData, setChartData] = useState<any[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    // Generate data based on the selected period
    if (period === "dia") {
      setChartData([
        { name: "8:00", entradas: 12, salidas: 8 },
        { name: "10:00", entradas: 19, salidas: 15 },
        { name: "12:00", entradas: 8, salidas: 12 },
        { name: "14:00", entradas: 15, salidas: 5 },
        { name: "16:00", entradas: 22, salidas: 18 },
        { name: "18:00", entradas: 10, salidas: 14 },
      ])
    } else if (period === "semana") {
      setChartData([
        { name: "Lunes", entradas: 45, salidas: 32 },
        { name: "Martes", entradas: 38, salidas: 42 },
        { name: "Miércoles", entradas: 52, salidas: 35 },
        { name: "Jueves", entradas: 40, salidas: 38 },
        { name: "Viernes", entradas: 65, salidas: 55 },
        { name: "Sábado", entradas: 25, salidas: 15 },
        { name: "Domingo", entradas: 10, salidas: 5 },
      ])
    } else if (period === "mes") {
      setChartData([
        { name: "Semana 1", entradas: 120, salidas: 95 },
        { name: "Semana 2", entradas: 145, salidas: 132 },
        { name: "Semana 3", entradas: 165, salidas: 140 },
        { name: "Semana 4", entradas: 190, salidas: 175 },
      ])
    }
  }, [period])

  if (!mounted) return null

  const textColor = theme === "dark" ? "#e2e8f0" : "#334155"
  const gridColor = theme === "dark" ? "#334155" : "#e2e8f0"

  return (
    <div className="h-80 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={chartData}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
          <XAxis dataKey="name" stroke={textColor} />
          <YAxis stroke={textColor} />
          <Tooltip
            contentStyle={{
              backgroundColor: theme === "dark" ? "#1e293b" : "#ffffff",
              color: textColor,
              border: `1px solid ${gridColor}`,
            }}
          />
          <Legend />
          <Line type="monotone" dataKey="entradas" stroke="#3b82f6" activeDot={{ r: 8 }} strokeWidth={2} />
          <Line type="monotone" dataKey="salidas" stroke="#ef4444" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
