"use client"

import type React from "react"

import { useState } from "react"
import { Calendar, Download, Filter, Printer, RefreshCw } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"

export function ReportesPage() {
  const [activeTab, setActiveTab] = useState("inventario")
  const [loading, setLoading] = useState(false)
  const [reportPeriod, setReportPeriod] = useState("mes")
  const [reportFormat, setReportFormat] = useState("pdf")
  const [dateRange, setDateRange] = useState({
    from: new Date(new Date().setDate(1)).toISOString().split("T")[0], // First day of current month
    to: new Date().toISOString().split("T")[0], // Today
  })
  const { toast } = useToast()

  const generateReport = () => {
    setLoading(true)
    toast({
      title: "Generando reporte",
      description: `Generando reporte de ${getReportTypeLabel()} en formato ${reportFormat.toUpperCase()}...`,
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Reporte generado",
        description: `El reporte ha sido generado correctamente.`,
      })
    }, 1500)
  }

  const getReportTypeLabel = () => {
    switch (activeTab) {
      case "inventario":
        return "inventario"
      case "ventas":
        return "ventas"
      case "movimientos":
        return "movimientos"
      case "tickets":
        return "tickets de servicio"
      case "usuarios":
        return "actividad de usuarios"
      default:
        return activeTab
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Reportes</h2>
      </div>

      <Tabs defaultValue="inventario" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="inventario">Inventario</TabsTrigger>
          <TabsTrigger value="ventas">Ventas</TabsTrigger>
          <TabsTrigger value="movimientos">Movimientos</TabsTrigger>
          <TabsTrigger value="tickets">Tickets</TabsTrigger>
          <TabsTrigger value="usuarios">Usuarios</TabsTrigger>
        </TabsList>

        <div className="mt-6 flex flex-col gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración del Reporte</CardTitle>
              <CardDescription>Configure los parámetros para generar el reporte.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="period">Período</Label>
                    <Select value={reportPeriod} onValueChange={setReportPeriod}>
                      <SelectTrigger id="period">
                        <SelectValue placeholder="Seleccionar período" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dia">Día actual</SelectItem>
                        <SelectItem value="semana">Semana actual</SelectItem>
                        <SelectItem value="mes">Mes actual</SelectItem>
                        <SelectItem value="trimestre">Trimestre actual</SelectItem>
                        <SelectItem value="anio">Año actual</SelectItem>
                        <SelectItem value="personalizado">Personalizado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {reportPeriod === "personalizado" && (
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="date-from">Desde</Label>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <Input
                            id="date-from"
                            type="date"
                            value={dateRange.from}
                            onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="date-to">Hasta</Label>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <Input
                            id="date-to"
                            type="date"
                            value={dateRange.to}
                            onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="format">Formato</Label>
                    <Select value={reportFormat} onValueChange={setReportFormat}>
                      <SelectTrigger id="format">
                        <SelectValue placeholder="Seleccionar formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="csv">CSV</SelectItem>
                        <SelectItem value="excel">Excel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Opciones adicionales</Label>
                    <div className="rounded-md border p-4">
                      <div className="space-y-4">
                        {activeTab === "inventario" && (
                          <>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-low-stock" />
                              <label
                                htmlFor="include-low-stock"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir solo productos con stock bajo
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-categories" />
                              <label
                                htmlFor="include-categories"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Agrupar por categorías
                              </label>
                            </div>
                          </>
                        )}

                        {activeTab === "ventas" && (
                          <>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-details" />
                              <label
                                htmlFor="include-details"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir detalles de productos
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-charts" />
                              <label
                                htmlFor="include-charts"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir gráficos
                              </label>
                            </div>
                          </>
                        )}

                        {activeTab === "movimientos" && (
                          <>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-entries" />
                              <label
                                htmlFor="include-entries"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir entradas
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-exits" />
                              <label
                                htmlFor="include-exits"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir salidas
                              </label>
                            </div>
                          </>
                        )}

                        {activeTab === "tickets" && (
                          <>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-resolved" />
                              <label
                                htmlFor="include-resolved"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir tickets resueltos
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-pending" />
                              <label
                                htmlFor="include-pending"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir tickets pendientes
                              </label>
                            </div>
                          </>
                        )}

                        {activeTab === "usuarios" && (
                          <>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-logins" />
                              <label
                                htmlFor="include-logins"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir historial de accesos
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-actions" />
                              <label
                                htmlFor="include-actions"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Incluir acciones realizadas
                              </label>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-2">
                <Button variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Vista previa
                </Button>
                <Button variant="outline">
                  <Printer className="mr-2 h-4 w-4" />
                  Imprimir
                </Button>
                <Button onClick={generateReport} disabled={loading}>
                  {loading ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Generando...
                    </>
                  ) : (
                    <>
                      <Download className="mr-2 h-4 w-4" />
                      Generar Reporte
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <TabsContent value="inventario" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Reporte de Inventario</CardTitle>
                <CardDescription>
                  Genere reportes detallados del estado actual del inventario, productos con stock bajo y valorización.
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <p>Configure los parámetros y genere el reporte</p>
                  <p className="text-sm">Los reportes se mostrarán aquí</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ventas" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Reporte de Ventas</CardTitle>
                <CardDescription>
                  Genere reportes de ventas por período, cliente o producto, incluyendo gráficos y análisis.
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <p>Configure los parámetros y genere el reporte</p>
                  <p className="text-sm">Los reportes se mostrarán aquí</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="movimientos" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Reporte de Movimientos</CardTitle>
                <CardDescription>
                  Genere reportes de entradas y salidas de productos, transferencias y ajustes de inventario.
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <p>Configure los parámetros y genere el reporte</p>
                  <p className="text-sm">Los reportes se mostrarán aquí</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tickets" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Reporte de Tickets</CardTitle>
                <CardDescription>
                  Genere reportes de tickets de servicio técnico, tiempos de resolución y satisfacción del cliente.
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <p>Configure los parámetros y genere el reporte</p>
                  <p className="text-sm">Los reportes se mostrarán aquí</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="usuarios" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Reporte de Actividad de Usuarios</CardTitle>
                <CardDescription>
                  Genere reportes de actividad de usuarios, accesos al sistema y acciones realizadas.
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <p>Configure los parámetros y genere el reporte</p>
                  <p className="text-sm">Los reportes se mostrarán aquí</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

function Checkbox(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input type="checkbox" className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary" {...props} />
  )
}
