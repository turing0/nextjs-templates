"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Download, Edit, Filter, Plus, RefreshCw, Search, Trash2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

interface SaleItem {
  id: number
  productName: string
  quantity: number
  unitPrice: number
  subtotal: number
}

interface Sale {
  id: number
  orderNumber: string
  client: string
  date: string
  status: "cotizada" | "en_curso" | "enviada" | "cerrada"
  items: SaleItem[]
  total: number
  notes: string
}

export function VentasPage() {
  const [sales, setSales] = useState<Sale[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("ventas")
  const [newSale, setNewSale] = useState<Omit<Sale, "id" | "orderNumber" | "items" | "total">>({
    client: "",
    date: new Date().toISOString().split("T")[0],
    status: "cotizada",
    notes: "",
  })
  const [saleItems, setSaleItems] = useState<Omit<SaleItem, "id" | "subtotal">[]>([])
  const [currentItem, setCurrentItem] = useState<Omit<SaleItem, "id" | "subtotal">>({
    productName: "",
    quantity: 1,
    unitPrice: 0,
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockSales: Sale[] = [
        {
          id: 1,
          orderNumber: "ORD-1234",
          client: "Empresa ABC Ltda.",
          date: "2025-04-14",
          status: "en_curso",
          items: [
            { id: 1, productName: 'Monitor LG 24"', quantity: 2, unitPrice: 150000, subtotal: 300000 },
            { id: 2, productName: "Teclado Mecánico RGB", quantity: 5, unitPrice: 45000, subtotal: 225000 },
            { id: 3, productName: "Mouse Inalámbrico", quantity: 5, unitPrice: 25000, subtotal: 125000 },
          ],
          total: 650000,
          notes: "Entrega programada para el 20/04/2025",
        },
        {
          id: 2,
          orderNumber: "ORD-1233",
          client: "Comercial XYZ S.A.",
          date: "2025-04-14",
          status: "cerrada",
          items: [
            { id: 1, productName: "Disco SSD 500GB", quantity: 10, unitPrice: 65000, subtotal: 650000 },
            { id: 2, productName: "Memoria RAM 16GB", quantity: 5, unitPrice: 55000, subtotal: 275000 },
          ],
          total: 925000,
          notes: "Entrega realizada el 14/04/2025",
        },
        {
          id: 3,
          orderNumber: "ORD-1232",
          client: "Distribuidora Sur",
          date: "2025-04-13",
          status: "enviada",
          items: [
            { id: 1, productName: "Licencia Windows 11", quantity: 15, unitPrice: 180000, subtotal: 2700000 },
            { id: 2, productName: "Licencia Office 365", quantity: 15, unitPrice: 120000, subtotal: 1800000 },
          ],
          total: 4500000,
          notes: "Envío realizado el 13/04/2025",
        },
        {
          id: 4,
          orderNumber: "ORD-1231",
          client: "Tecnología Avanzada SpA",
          date: "2025-04-13",
          status: "cerrada",
          items: [
            { id: 1, productName: 'Monitor LG 24"', quantity: 20, unitPrice: 150000, subtotal: 3000000 },
            { id: 2, productName: "Teclado Mecánico RGB", quantity: 20, unitPrice: 45000, subtotal: 900000 },
            { id: 3, productName: "Mouse Inalámbrico", quantity: 20, unitPrice: 25000, subtotal: 500000 },
          ],
          total: 4400000,
          notes: "Entrega realizada el 13/04/2025",
        },
        {
          id: 5,
          orderNumber: "ORD-1230",
          client: "Constructora Norte",
          date: "2025-04-12",
          status: "cotizada",
          items: [
            { id: 1, productName: "Cable HDMI 2m", quantity: 50, unitPrice: 8000, subtotal: 400000 },
            { id: 2, productName: "Adaptador USB-C", quantity: 30, unitPrice: 15000, subtotal: 450000 },
          ],
          total: 850000,
          notes: "Pendiente de aprobación",
        },
      ]
      setSales(mockSales)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleAddItem = () => {
    if (!currentItem.productName || currentItem.quantity <= 0 || currentItem.unitPrice <= 0) return

    setSaleItems([...saleItems, currentItem])
    setCurrentItem({
      productName: "",
      quantity: 1,
      unitPrice: 0,
    })
  }

  const handleRemoveItem = (index: number) => {
    setSaleItems(saleItems.filter((_, i) => i !== index))
  }

  const calculateTotal = () => {
    return saleItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
  }

  const handleAddSale = () => {
    if (!newSale.client || saleItems.length === 0) {
      toast({
        title: "Error al crear venta",
        description: "Por favor complete todos los campos y agregue al menos un producto.",
        variant: "destructive",
      })
      return
    }

    const id = Math.max(0, ...sales.map((s) => s.id)) + 1
    const orderNumber = `ORD-${1234 + id}`
    const total = calculateTotal()

    const items: SaleItem[] = saleItems.map((item, index) => ({
      id: index + 1,
      ...item,
      subtotal: item.quantity * item.unitPrice,
    }))

    const sale: Sale = {
      id,
      orderNumber,
      ...newSale,
      items,
      total,
    }

    setSales([sale, ...sales])
    setNewSale({
      client: "",
      date: new Date().toISOString().split("T")[0],
      status: "cotizada",
      notes: "",
    })
    setSaleItems([])
    setIsAddDialogOpen(false)

    toast({
      title: "Venta creada",
      description: `Se ha creado la orden ${orderNumber} para ${newSale.client}.`,
    })
  }

  const handleUpdateSaleStatus = (id: number, status: Sale["status"]) => {
    setSales(
      sales.map((sale) => {
        if (sale.id === id) {
          return {
            ...sale,
            status,
          }
        }
        return sale
      }),
    )

    toast({
      title: "Estado actualizado",
      description: `El estado de la orden ha sido actualizado a "${getStatusLabel(status)}".`,
    })
  }

  const filteredSales = sales.filter((sale) => {
    const matchesSearch =
      sale.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.client.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || sale.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando ventas",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Ventas actualizadas",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos de ventas se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  const getStatusLabel = (status: Sale["status"]) => {
    switch (status) {
      case "cotizada":
        return "Cotizada"
      case "en_curso":
        return "En Curso"
      case "enviada":
        return "Enviada"
      case "cerrada":
        return "Cerrada"
      default:
        return status
    }
  }

  const getStatusColor = (status: Sale["status"]) => {
    switch (status) {
      case "cotizada":
        return "bg-amber-500"
      case "en_curso":
        return "bg-blue-500"
      case "enviada":
        return "bg-purple-500"
      case "cerrada":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Ventas y Órdenes</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nueva Venta
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crear Nueva Venta</DialogTitle>
                <DialogDescription>Complete los detalles de la nueva venta u orden de trabajo.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="client" className="text-right">
                    Cliente
                  </label>
                  <Input
                    id="client"
                    value={newSale.client}
                    onChange={(e) => setNewSale({ ...newSale, client: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="date" className="text-right">
                    Fecha
                  </label>
                  <Input
                    id="date"
                    type="date"
                    value={newSale.date}
                    onChange={(e) => setNewSale({ ...newSale, date: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="status" className="text-right">
                    Estado
                  </label>
                  <Select
                    value={newSale.status}
                    onValueChange={(value: Sale["status"]) => setNewSale({ ...newSale, status: value })}
                  >
                    <SelectTrigger id="status" className="col-span-3">
                      <SelectValue placeholder="Seleccionar estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cotizada">Cotizada</SelectItem>
                      <SelectItem value="en_curso">En Curso</SelectItem>
                      <SelectItem value="enviada">Enviada</SelectItem>
                      <SelectItem value="cerrada">Cerrada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <label htmlFor="notes" className="text-right pt-2">
                    Notas
                  </label>
                  <Textarea
                    id="notes"
                    value={newSale.notes}
                    onChange={(e) => setNewSale({ ...newSale, notes: e.target.value })}
                    className="col-span-3"
                    rows={2}
                  />
                </div>

                <div className="mt-4 border-t pt-4">
                  <h4 className="mb-4 font-medium">Productos</h4>
                  <div className="grid grid-cols-12 gap-2">
                    <div className="col-span-5">
                      <Input
                        placeholder="Nombre del producto"
                        value={currentItem.productName}
                        onChange={(e) => setCurrentItem({ ...currentItem, productName: e.target.value })}
                      />
                    </div>
                    <div className="col-span-2">
                      <Input
                        type="number"
                        placeholder="Cantidad"
                        min="1"
                        value={currentItem.quantity}
                        onChange={(e) =>
                          setCurrentItem({ ...currentItem, quantity: Number.parseInt(e.target.value) || 1 })
                        }
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="number"
                        placeholder="Precio unitario"
                        min="0"
                        value={currentItem.unitPrice}
                        onChange={(e) =>
                          setCurrentItem({ ...currentItem, unitPrice: Number.parseInt(e.target.value) || 0 })
                        }
                      />
                    </div>
                    <div className="col-span-2">
                      <Button
                        onClick={handleAddItem}
                        disabled={!currentItem.productName || currentItem.quantity <= 0 || currentItem.unitPrice <= 0}
                        className="w-full"
                      >
                        Agregar
                      </Button>
                    </div>
                  </div>

                  <div className="mt-4 rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Producto</TableHead>
                          <TableHead className="text-center">Cantidad</TableHead>
                          <TableHead className="text-right">Precio Unitario</TableHead>
                          <TableHead className="text-right">Subtotal</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {saleItems.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="h-24 text-center">
                              No hay productos agregados.
                            </TableCell>
                          </TableRow>
                        ) : (
                          saleItems.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell>{item.productName}</TableCell>
                              <TableCell className="text-center">{item.quantity}</TableCell>
                              <TableCell className="text-right">${item.unitPrice.toLocaleString("es-CL")}</TableCell>
                              <TableCell className="text-right">
                                ${(item.quantity * item.unitPrice).toLocaleString("es-CL")}
                              </TableCell>
                              <TableCell>
                                <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(index)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                        <TableRow>
                          <TableCell colSpan={3} className="text-right font-bold">
                            Total
                          </TableCell>
                          <TableCell className="text-right font-bold">
                            ${calculateTotal().toLocaleString("es-CL")}
                          </TableCell>
                          <TableCell></TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddSale} disabled={!newSale.client || saleItems.length === 0}>
                  Crear Venta
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="ventas" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="ventas">Ventas</TabsTrigger>
          <TabsTrigger value="estadisticas">Estadísticas</TabsTrigger>
        </TabsList>
        <TabsContent value="ventas" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Ventas y Órdenes de Trabajo</CardTitle>
              <CardDescription>Gestione las ventas y órdenes de trabajo.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex flex-col gap-4 md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por número de orden o cliente..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        Estado
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuLabel>Filtrar por estado</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setStatusFilter("all")}>Todos</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("cotizada")}>Cotizada</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("en_curso")}>En Curso</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("enviada")}>Enviada</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatusFilter("cerrada")}>Cerrada</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Orden #</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-20 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-6 w-20 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filteredSales.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="h-24 text-center">
                          No se encontraron ventas.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredSales.map((sale) => (
                        <TableRow key={sale.id}>
                          <TableCell className="font-medium">{sale.orderNumber}</TableCell>
                          <TableCell>{sale.client}</TableCell>
                          <TableCell>{formatDate(sale.date)}</TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(sale.status)}>{getStatusLabel(sale.status)}</Badge>
                          </TableCell>
                          <TableCell className="text-right">${sale.total.toLocaleString("es-CL")}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="ghost" size="icon" onClick={() => setSelectedSale(sale)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Actualizar Estado</DialogTitle>
                                    <DialogDescription>
                                      Actualice el estado de la orden {sale.orderNumber}.
                                    </DialogDescription>
                                  </DialogHeader>
                                  {selectedSale && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <label htmlFor="update-status" className="text-right">
                                          Estado
                                        </label>
                                        <Select
                                          value={selectedSale.status}
                                          onValueChange={(value: Sale["status"]) =>
                                            setSelectedSale({ ...selectedSale, status: value })
                                          }
                                        >
                                          <SelectTrigger id="update-status" className="col-span-3">
                                            <SelectValue placeholder="Seleccionar estado" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="cotizada">Cotizada</SelectItem>
                                            <SelectItem value="en_curso">En Curso</SelectItem>
                                            <SelectItem value="enviada">Enviada</SelectItem>
                                            <SelectItem value="cerrada">Cerrada</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setSelectedSale(null)}>
                                      Cancelar
                                    </Button>
                                    <Button
                                      onClick={() => {
                                        if (selectedSale) {
                                          handleUpdateSaleStatus(selectedSale.id, selectedSale.status)
                                          setSelectedSale(null)
                                        }
                                      }}
                                    >
                                      Guardar
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>Ver detalles</DropdownMenuItem>
                                  <DropdownMenuItem>Imprimir</DropdownMenuItem>
                                  <DropdownMenuItem>Enviar por email</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600">Eliminar</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="estadisticas" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Estadísticas de Ventas</CardTitle>
              <CardDescription>Visualización de datos de ventas por período.</CardDescription>
            </CardHeader>
            <CardContent className="h-96 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <p>Módulo de estadísticas en desarrollo</p>
                <p className="text-sm">Próximamente disponible</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function MoreVertical(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="1" />
      <circle cx="12" cy="5" r="1" />
      <circle cx="12" cy="19" r="1" />
    </svg>
  )
}
