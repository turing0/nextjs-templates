"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { AlertCircle, Download, Filter, Plus, RefreshCw, Search, Trash2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

// Modificar la interfaz Product para incluir el campo de ubicación
interface Product {
  id: number
  name: string
  sku: string
  category: string
  stock: number
  price: number
  status: "normal" | "low" | "critical"
  location: string // Nuevo campo para ubicación
}

export function InventarioPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [stockFilter, setStockFilter] = useState("all")
  const [showLowStockAlert, setShowLowStockAlert] = useState(true)
  // Actualizar el estado newProduct para incluir ubicación
  const [newProduct, setNewProduct] = useState<Omit<Product, "id" | "status">>({
    name: "",
    sku: "",
    category: "accesorios",
    stock: 0,
    price: 0,
    location: "",
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const { toast } = useToast()

  // Actualizar los productos de ejemplo para incluir ubicación
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockProducts: Product[] = [
        {
          id: 1,
          name: 'Monitor LG 24"',
          sku: "MON-LG-24",
          category: "accesorios",
          stock: 2,
          price: 150000,
          status: "critical",
          location: "Bodega A - Estante 3",
        },
        {
          id: 2,
          name: "Teclado Mecánico RGB",
          sku: "TEC-MEC-01",
          category: "accesorios",
          stock: 15,
          price: 45000,
          status: "normal",
          location: "Bodega A - Estante 2",
        },
        {
          id: 3,
          name: "Mouse Inalámbrico",
          sku: "MOU-IN-02",
          category: "accesorios",
          stock: 8,
          price: 25000,
          status: "low",
          location: "Bodega A - Estante 2",
        },
        {
          id: 4,
          name: "Disco SSD 500GB",
          sku: "SSD-500-01",
          category: "accesorios",
          stock: 20,
          price: 65000,
          status: "normal",
          location: "Bodega B - Estante 1",
        },
        {
          id: 5,
          name: "Memoria RAM 16GB",
          sku: "RAM-16-01",
          category: "accesorios",
          stock: 5,
          price: 55000,
          status: "low",
          location: "Bodega B - Estante 1",
        },
        {
          id: 6,
          name: "Calefactor Eléctrico 2000W",
          sku: "CAL-EL-2000",
          category: "calefactor",
          stock: 30,
          price: 180000,
          status: "normal",
          location: "Bodega C - Estante 4",
        },
        {
          id: 7,
          name: "Generador Diésel 5KW",
          sku: "GEN-DIE-5KW",
          category: "generador",
          stock: 25,
          price: 1200000,
          status: "normal",
          location: "Bodega D - Sección 2",
        },
        {
          id: 8,
          name: "Cable HDMI 2m",
          sku: "CAB-HDMI-2",
          category: "accesorios",
          stock: 3,
          price: 8000,
          status: "critical",
          location: "Bodega A - Estante 1",
        },
        {
          id: 9,
          name: "Adaptador USB-C",
          sku: "ADP-USBC-01",
          category: "accesorios",
          stock: 12,
          price: 15000,
          status: "normal",
          location: "Bodega A - Estante 1",
        },
        {
          id: 10,
          name: "Webcam HD",
          sku: "WEB-HD-01",
          category: "accesorios",
          stock: 7,
          price: 35000,
          status: "low",
          location: "Bodega B - Estante 3",
        },
      ]
      setProducts(mockProducts)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Actualizar la función handleAddProduct para incluir ubicación
  const handleAddProduct = () => {
    const id = Math.max(0, ...products.map((p) => p.id)) + 1
    const status = newProduct.stock <= 3 ? "critical" : newProduct.stock <= 8 ? "low" : "normal"

    setProducts([...products, { ...newProduct, id, status }])
    setNewProduct({
      name: "",
      sku: "",
      category: "accesorios",
      stock: 0,
      price: 0,
      location: "",
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Producto agregado",
      description: `El producto "${newProduct.name}" ha sido agregado correctamente.`,
    })
  }

  const handleDeleteProduct = (id: number) => {
    const productToDelete = products.find((p) => p.id === id)
    setProducts(products.filter((p) => p.id !== id))

    toast({
      title: "Producto eliminado",
      description: `El producto "${productToDelete?.name}" ha sido eliminado correctamente.`,
      variant: "destructive",
    })
  }

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || product.category === categoryFilter
    const matchesStock =
      stockFilter === "all" ||
      (stockFilter === "low" && product.status === "low") ||
      (stockFilter === "critical" && product.status === "critical") ||
      (stockFilter === "normal" && product.status === "normal")

    return matchesSearch && matchesCategory && matchesStock
  })

  const lowStockCount = products.filter((p) => p.status === "low" || p.status === "critical").length

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando inventario",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Inventario actualizado",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos del inventario se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Inventario</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Agregar Producto
              </Button>
            </DialogTrigger>
            {/* Actualizar el diálogo de agregar producto para incluir ubicación y las nuevas categorías */}
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Producto</DialogTitle>
                <DialogDescription>
                  Complete los detalles del nuevo producto para agregarlo al inventario.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="name" className="text-right">
                    Nombre
                  </label>
                  <Input
                    id="name"
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="sku" className="text-right">
                    SKU
                  </label>
                  <Input
                    id="sku"
                    value={newProduct.sku}
                    onChange={(e) => setNewProduct({ ...newProduct, sku: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="category" className="text-right">
                    Categoría
                  </label>
                  <Select
                    value={newProduct.category}
                    onValueChange={(value) => setNewProduct({ ...newProduct, category: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="calefactor">Calefactor</SelectItem>
                      <SelectItem value="generador">Generador</SelectItem>
                      <SelectItem value="accesorios">Accesorios</SelectItem>
                      <SelectItem value="otros">Otros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="location" className="text-right">
                    Ubicación
                  </label>
                  <Input
                    id="location"
                    value={newProduct.location}
                    onChange={(e) => setNewProduct({ ...newProduct, location: e.target.value })}
                    className="col-span-3"
                    placeholder="Ej: Bodega A - Estante 3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="stock" className="text-right">
                    Stock
                  </label>
                  <Input
                    id="stock"
                    type="number"
                    value={newProduct.stock}
                    onChange={(e) => setNewProduct({ ...newProduct, stock: Number.parseInt(e.target.value) || 0 })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="price" className="text-right">
                    Precio (CLP)
                  </label>
                  <Input
                    id="price"
                    type="number"
                    value={newProduct.price}
                    onChange={(e) => setNewProduct({ ...newProduct, price: Number.parseInt(e.target.value) || 0 })}
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddProduct} disabled={!newProduct.name || !newProduct.sku}>
                  Guardar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {showLowStockAlert && lowStockCount > 0 && (
        <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950 dark:border-amber-800 animate-slide-in">
          <AlertCircle className="h-4 w-4 text-amber-800 dark:text-amber-300" />
          <AlertTitle className="text-amber-800 dark:text-amber-300">Alerta de Stock Bajo</AlertTitle>
          <AlertDescription className="text-amber-700 dark:text-amber-400">
            Hay {lowStockCount} productos con stock bajo o crítico que requieren reposición.
          </AlertDescription>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 text-amber-800 dark:text-amber-300"
            onClick={() => setShowLowStockAlert(false)}
          >
            <XIcon className="h-4 w-4" />
          </Button>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Lista de Productos</CardTitle>
          <CardDescription>Gestione su inventario de productos, stock y precios.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-col gap-4 md:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre o SKU..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              {/* Actualizar el filtro de categorías */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Categoría
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Filtrar por categoría</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setCategoryFilter("all")}>Todas</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setCategoryFilter("calefactor")}>Calefactor</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setCategoryFilter("generador")}>Generador</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setCategoryFilter("accesorios")}>Accesorios</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setCategoryFilter("otros")}>Otros</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Stock
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Filtrar por stock</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setStockFilter("all")}>Todos</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStockFilter("normal")}>Normal</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStockFilter("low")}>Bajo</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStockFilter("critical")}>Crítico</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <div className="rounded-md border">
            {/* Actualizar la tabla para mostrar la ubicación y las nuevas categorías */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">SKU</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Categoría</TableHead>
                  <TableHead>Ubicación</TableHead>
                  <TableHead className="text-center">Stock</TableHead>
                  <TableHead className="text-right">Precio (CLP)</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="h-4 w-16 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="mx-auto h-4 w-12 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="ml-auto h-4 w-20 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="ml-auto h-8 w-20 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : filteredProducts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      No se encontraron productos.
                    </TableCell>
                  </TableRow>
                ) : (
                  // Actualizar el renderizado de los productos para incluir ubicación
                  filteredProducts.map((product) => (
                    <TableRow key={product.id}>
                      <TableCell className="font-medium">{product.sku}</TableCell>
                      <TableCell>{product.name}</TableCell>
                      <TableCell className="capitalize">{product.category}</TableCell>
                      <TableCell>{product.location}</TableCell>
                      <TableCell className="text-center">
                        <Badge
                          className={`${
                            product.status === "critical"
                              ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                              : product.status === "low"
                                ? "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300"
                                : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                          }`}
                        >
                          {product.stock}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">${product.price.toLocaleString("es-CL")}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon">
                            <PencilIcon className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteProduct(product.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function XIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  )
}

function PencilIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
      <path d="m15 5 4 4" />
    </svg>
  )
}
