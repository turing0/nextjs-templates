"use client"

import type React from "react"

import { useEffect } from "react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import {
  BarChart3,
  Box,
  ClipboardList,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Moon,
  Settings,
  Sun,
  Truck,
  Users,
  X,
  Bell,
  Calculator,
  Calendar,
  FileText,
  CheckCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { ChatWidget } from "@/components/chat-widget"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useAppContext } from "@/contexts/app-context"

interface DashboardLayoutProps {
  children: React.ReactNode
}

// Actualizar los elementos del menú para incluir las nuevas rutas
const menuItems = [
  {
    path: "/",
    label: "Dashboard",
    icon: <LayoutDashboard className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/inventario",
    label: "Inventario",
    icon: <Box className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/movimientos",
    label: "Movimientos",
    icon: <Truck className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/tickets",
    label: "Tickets",
    icon: <ClipboardList className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/ventas",
    label: "Ventas",
    icon: <CreditCard className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/ordenes",
    label: "OT",
    icon: <FileText className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/calendario",
    label: "Calendario",
    icon: <Calendar className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/clientes",
    label: "Clientes",
    icon: <Users className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/cotizador",
    label: "Cotizador",
    icon: <Calculator className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/usuarios",
    label: "Usuarios",
    icon: <Users className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/reportes",
    label: "Reportes",
    icon: <BarChart3 className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
  {
    path: "/configuracion",
    label: "Configuración",
    icon: <Settings className="h-5 w-5 transition-all duration-200 group-hover:animate-pulse" />,
  },
]

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { notifications, setNotifications, theme, setTheme } = useAppContext()
  const pathname = usePathname()

  useEffect(() => {
    // Guardar la preferencia de tema en localStorage
    localStorage.setItem("theme", theme)
  }, [theme])

  // Configurar el sistema de persistencia de datos
  useEffect(() => {
    // Función para mostrar el indicador de guardado
    const showSaveIndicator = () => {
      const indicator = document.getElementById("save-indicator")
      if (indicator) {
        indicator.style.display = "flex"
        setTimeout(() => {
          indicator.style.display = "none"
        }, 2000)
      }
    }

    // Interceptar los cambios en localStorage
    const originalSetItem = localStorage.setItem
    localStorage.setItem = function (key, value) {
      // Llamar a la función original
      originalSetItem.apply(this, arguments)

      // Mostrar el indicador de guardado
      showSaveIndicator()

      // Disparar un evento personalizado
      const event = new Event("localStorageChange")
      window.dispatchEvent(event)
    }

    // Limpiar al desmontar
    return () => {
      localStorage.setItem = originalSetItem
    }
  }, [])

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-card shadow-lg dark:bg-card">
        <div className="flex h-full flex-col">
          <div className="flex h-16 items-center border-b px-4">
            <div className="flex items-center gap-2 font-semibold">
              <LayoutDashboard className="h-5 w-5 text-primary" />
              <span className="text-lg">AdminSystem</span>
            </div>
          </div>
          <nav className="flex-1 space-y-1 overflow-y-auto p-4 z-50">
            <ul className="space-y-1">
              {menuItems.map((item) => (
                <li key={item.path}>
                  <Link
                    href={item.path}
                    className={`group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-all duration-200 hover:bg-accent hover:text-accent-foreground ${
                      pathname === item.path
                        ? "bg-primary text-primary-foreground"
                        : "text-foreground/70 hover:text-foreground"
                    }`}
                  >
                    <span className="transition-all duration-300 ease-in-out group-hover:scale-110">{item.icon}</span>
                    <span className="ml-3 transition-all duration-200 ease-in-out group-hover:translate-x-1">
                      {item.label}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div className="border-t p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/placeholder-user.jpg" alt="Usuario" />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">Admin</p>
                  <p className="text-xs text-muted-foreground">admin@empresa.cl</p>
                </div>
              </div>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="hover:bg-accent hover:text-accent-foreground">
                      <LogOut className="h-5 w-5 transition-all duration-200 hover:scale-110" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Cerrar sesión</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="ml-64 flex flex-1 flex-col overflow-hidden">
        <header className="flex h-16 items-center justify-between border-b bg-card px-4 shadow-sm">
          <h1 className="text-xl font-semibold">
            {menuItems.find((item) => item.path === pathname)?.label || "Dashboard"}
          </h1>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                    className="rounded-full"
                  >
                    {theme === "dark" ? (
                      <Sun className="h-5 w-5 transition-all duration-200 hover:animate-spin" />
                    ) : (
                      <Moon className="h-5 w-5 transition-all duration-200 hover:animate-spin" />
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{theme === "dark" ? "Modo claro" : "Modo oscuro"}</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <DropdownMenu>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="relative rounded-full">
                        {notifications > 0 && (
                          <Badge className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive p-0 text-destructive-foreground">
                            {notifications}
                          </Badge>
                        )}
                        <Bell className="h-5 w-5 transition-all duration-200 hover:animate-pulse" />
                      </Button>
                    </DropdownMenuTrigger>
                  </TooltipTrigger>
                  <TooltipContent>Notificaciones</TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">Notificaciones</p>
                    <p className="text-xs text-muted-foreground">Tienes {notifications} notificaciones sin leer.</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="max-h-80 overflow-y-auto">
                  <div className="flex flex-col gap-2 p-2">
                    <div className="rounded-lg border p-3 transition-colors hover:bg-accent">
                      <div className="flex justify-between">
                        <div className="flex items-start gap-2">
                          <div className="rounded-full bg-amber-500/20 p-2 text-amber-500">
                            <Box className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Stock bajo</p>
                            <p className="text-xs text-muted-foreground">Hace 10 min</p>
                            <p className="mt-1 text-sm">El producto "Monitor LG 24" tiene stock bajo (2 unidades)</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="rounded-lg border p-3 transition-colors hover:bg-accent">
                      <div className="flex justify-between">
                        <div className="flex items-start gap-2">
                          <div className="rounded-full bg-blue-500/20 p-2 text-blue-500">
                            <ClipboardList className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Nuevo ticket</p>
                            <p className="text-xs text-muted-foreground">Hace 30 min</p>
                            <p className="mt-1 text-sm">Se ha creado un nuevo ticket de servicio técnico #1234</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="rounded-lg border p-3 transition-colors hover:bg-accent">
                      <div className="flex justify-between">
                        <div className="flex items-start gap-2">
                          <div className="rounded-full bg-green-500/20 p-2 text-green-500">
                            <CreditCard className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Venta completada</p>
                            <p className="text-xs text-muted-foreground">Hace 1 hora</p>
                            <p className="mt-1 text-sm">La orden #5678 ha sido completada por $450.000 CLP</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <div className="p-2">
                  <Button variant="outline" className="w-full" onClick={() => setNotifications(0)}>
                    Marcar todas como leídas
                  </Button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="rounded-full">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder-user.jpg" alt="Usuario" />
                          <AvatarFallback>AD</AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                  </TooltipTrigger>
                  <TooltipContent>Mi cuenta</TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Perfil</DropdownMenuItem>
                <DropdownMenuItem>Configuración</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Cerrar sesión</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="animate-fade-in">{children}</div>

          {/* Sistema de persistencia de datos */}
          <div className="fixed bottom-4 right-4 z-50">
            <div
              className="bg-green-100 text-green-800 px-4 py-2 rounded-md shadow-md text-sm flex items-center"
              id="save-indicator"
              style={{ display: "none" }}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Cambios guardados
            </div>
          </div>
        </main>
      </div>

      {/* Chat widget - ahora siempre visible */}
      <ChatWidget />
    </div>
  )
}
