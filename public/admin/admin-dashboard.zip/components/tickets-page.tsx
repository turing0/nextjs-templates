"use client"

import { useState, useEffect } from "react"
import { Download, Filter, Plus, RefreshCw, Search, Trash2, Users, X } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Actualizar la interfaz Ticket para mejorar la funcionalidad
interface Ticket {
  id: number
  title: string
  description: string
  client: string
  category: "preventivo" | "correctivo" | "instalacion"
  status: "pendiente" | "en_progreso" | "resuelto" | "cancelado"
  assignedTo: string
  createdAt: string
  updatedAt: string
  priority: "baja" | "media" | "alta"
  notes: string[]
}

export function TicketsPage() {
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("lista")
  const [newTicket, setNewTicket] = useState<Omit<Ticket, "id" | "createdAt" | "updatedAt" | "notes">>({
    title: "",
    description: "",
    client: "",
    category: "correctivo",
    status: "pendiente",
    assignedTo: "",
    priority: "media",
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null)
  const [newNote, setNewNote] = useState("")
  const { toast } = useToast()

  // Agregar un estado para la lista de técnicos disponibles
  const [technicians, setTechnicians] = useState<string[]>([
    "Juan Pérez",
    "María González",
    "Carlos Rodríguez",
    "Ana Martínez",
    "Pedro Sánchez",
  ])

  // Agregar un estado para el nuevo técnico
  const [newTechnician, setNewTechnician] = useState("")

  // Agregar función para añadir un nuevo técnico
  const handleAddTechnician = () => {
    if (newTechnician.trim() === "") return
    setTechnicians([...technicians, newTechnician.trim()])
    setNewTechnician("")

    toast({
      title: "Técnico agregado",
      description: `Se ha agregado "${newTechnician}" a la lista de técnicos.`,
    })
  }

  // Agregar función para eliminar un técnico
  const handleDeleteTechnician = (technicianToDelete: string) => {
    setTechnicians(technicians.filter((tech) => tech !== technicianToDelete))

    toast({
      title: "Técnico eliminado",
      description: `Se ha eliminado "${technicianToDelete}" de la lista de técnicos.`,
      variant: "destructive",
    })
  }

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockTickets: Ticket[] = [
        {
          id: 1,
          title: "Falla en monitor principal",
          description: "El monitor principal de la recepción presenta intermitencia en la imagen.",
          client: "Empresa ABC Ltda.",
          category: "correctivo",
          status: "en_progreso",
          assignedTo: "Juan Pérez",
          createdAt: "2025-04-12T10:30:00",
          updatedAt: "2025-04-13T14:15:00",
          priority: "alta",
          notes: [
            "Se realizó diagnóstico inicial, posible problema en la fuente de alimentación.",
            "Se solicitaron repuestos para reparación.",
          ],
        },
        {
          id: 2,
          title: "Instalación de equipos nuevos",
          description: "Instalación de 5 equipos nuevos en el departamento de contabilidad.",
          client: "Comercial XYZ S.A.",
          category: "instalacion",
          status: "pendiente",
          assignedTo: "María González",
          createdAt: "2025-04-13T09:45:00",
          updatedAt: "2025-04-13T09:45:00",
          priority: "media",
          notes: ["Programado para el 15/04/2025."],
        },
        {
          id: 3,
          title: "Mantenimiento preventivo servidores",
          description: "Mantenimiento preventivo de los servidores principales.",
          client: "Distribuidora Sur",
          category: "preventivo",
          status: "pendiente",
          assignedTo: "Carlos Rodríguez",
          createdAt: "2025-04-11T16:20:00",
          updatedAt: "2025-04-11T16:20:00",
          priority: "baja",
          notes: ["Programado para el fin de semana."],
        },
        {
          id: 4,
          title: "Problema de conectividad en red",
          description: "Varios equipos presentan problemas de conectividad intermitente.",
          client: "Tecnología Avanzada SpA",
          category: "correctivo",
          status: "resuelto",
          assignedTo: "Juan Pérez",
          createdAt: "2025-04-10T11:30:00",
          updatedAt: "2025-04-12T15:45:00",
          priority: "alta",
          notes: [
            "Se identificó un problema en el switch principal.",
            "Se reemplazó el switch y se normalizó la conectividad.",
          ],
        },
        {
          id: 5,
          title: "Actualización de software",
          description: "Actualización de software de gestión en todos los equipos.",
          client: "Constructora Norte",
          category: "preventivo",
          status: "en_progreso",
          assignedTo: "María González",
          createdAt: "2025-04-09T14:15:00",
          updatedAt: "2025-04-11T10:30:00",
          priority: "media",
          notes: ["Se ha completado la actualización en el 50% de los equipos.", "Se espera finalizar en 2 días."],
        },
      ]
      setTickets(mockTickets)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Actualizar la función handleAddTicket para que funcione correctamente
  const handleAddTicket = () => {
    if (!newTicket.title || !newTicket.client || !newTicket.assignedTo) {
      toast({
        title: "Error al crear ticket",
        description: "Por favor complete todos los campos obligatorios.",
        variant: "destructive",
      })
      return
    }

    const id = Math.max(0, ...tickets.map((t) => t.id)) + 1
    const now = new Date().toISOString()

    const newTicketComplete: Ticket = {
      ...newTicket,
      id,
      createdAt: now,
      updatedAt: now,
      notes: [],
    }

    setTickets([newTicketComplete, ...tickets])
    setNewTicket({
      title: "",
      description: "",
      client: "",
      category: "correctivo",
      status: "pendiente",
      assignedTo: "",
      priority: "media",
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Ticket creado",
      description: `Se ha creado el ticket "${newTicket.title}" correctamente.`,
    })
  }

  // Mejorar la visualización de detalles del ticket
  const handleViewTicket = (ticket: Ticket) => {
    setSelectedTicket(ticket)
  }

  // Actualizar la función para cambiar el estado del ticket
  const handleUpdateTicketStatus = (id: number, status: Ticket["status"]) => {
    const updatedTickets = tickets.map((ticket) => {
      if (ticket.id === id) {
        const updatedTicket = {
          ...ticket,
          status,
          updatedAt: new Date().toISOString(),
        }

        // Si estamos viendo este ticket, actualizar también el ticket seleccionado
        if (selectedTicket && selectedTicket.id === id) {
          setSelectedTicket(updatedTicket)
        }

        return updatedTicket
      }
      return ticket
    })

    setTickets(updatedTickets)

    toast({
      title: "Estado actualizado",
      description: `El estado del ticket ha sido actualizado a "${getStatusLabel(status)}".`,
    })
  }

  // Mejorar la función para agregar notas
  const handleAddNote = () => {
    if (!selectedTicket || !newNote.trim()) return

    const updatedTicket = {
      ...selectedTicket,
      notes: [...selectedTicket.notes, newNote.trim()],
      updatedAt: new Date().toISOString(),
    }

    setTickets(tickets.map((ticket) => (ticket.id === selectedTicket.id ? updatedTicket : ticket)))
    setSelectedTicket(updatedTicket)
    setNewNote("")

    toast({
      title: "Nota agregada",
      description: "Se ha agregado una nueva nota al ticket.",
    })
  }

  // Agregar una función para eliminar notas
  const handleDeleteNote = (ticketId: number, noteIndex: number) => {
    const ticket = tickets.find((t) => t.id === ticketId)
    if (!ticket) return

    const updatedNotes = [...ticket.notes]
    updatedNotes.splice(noteIndex, 1)

    const updatedTicket = {
      ...ticket,
      notes: updatedNotes,
      updatedAt: new Date().toISOString(),
    }

    setTickets(tickets.map((t) => (t.id === ticketId ? updatedTicket : t)))

    if (selectedTicket && selectedTicket.id === ticketId) {
      setSelectedTicket(updatedTicket)
    }

    toast({
      title: "Nota eliminada",
      description: "Se ha eliminado la nota del ticket.",
      variant: "destructive",
    })
  }

  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch =
      ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.client.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || ticket.category === categoryFilter
    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter

    return matchesSearch && matchesCategory && matchesStatus
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando tickets",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Tickets actualizados",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos de tickets se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  const getCategoryLabel = (category: Ticket["category"]) => {
    switch (category) {
      case "preventivo":
        return "Preventivo"
      case "correctivo":
        return "Correctivo"
      case "instalacion":
        return "Instalación"
      default:
        return category
    }
  }

  const getStatusLabel = (status: Ticket["status"]) => {
    switch (status) {
      case "pendiente":
        return "Pendiente"
      case "en_progreso":
        return "En Progreso"
      case "resuelto":
        return "Resuelto"
      case "cancelado":
        return "Cancelado"
      default:
        return status
    }
  }

  const getPriorityLabel = (priority: Ticket["priority"]) => {
    switch (priority) {
      case "baja":
        return "Baja"
      case "media":
        return "Media"
      case "alta":
        return "Alta"
      default:
        return priority
    }
  }

  const getStatusColor = (status: Ticket["status"]) => {
    switch (status) {
      case "pendiente":
        return "bg-amber-500"
      case "en_progreso":
        return "bg-blue-500"
      case "resuelto":
        return "bg-green-500"
      case "cancelado":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getPriorityColor = (priority: Ticket["priority"]) => {
    switch (priority) {
      case "baja":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "media":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300"
      case "alta":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const formatDateTime = (dateTimeString: string) => {
    const date = new Date(dateTimeString)
    return date.toLocaleString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Tickets de Servicio Técnico</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Crear Ticket
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crear Nuevo Ticket</DialogTitle>
                <DialogDescription>Complete los detalles del nuevo ticket de servicio técnico.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="title" className="text-right">
                    Título
                  </label>
                  <Input
                    id="title"
                    value={newTicket.title}
                    onChange={(e) => setNewTicket({ ...newTicket, title: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <label htmlFor="description" className="text-right pt-2">
                    Descripción
                  </label>
                  <Textarea
                    id="description"
                    value={newTicket.description}
                    onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="client" className="text-right">
                    Cliente
                  </label>
                  <Input
                    id="client"
                    value={newTicket.client}
                    onChange={(e) => setNewTicket({ ...newTicket, client: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="category" className="text-right">
                    Categoría
                  </label>
                  <Select
                    value={newTicket.category}
                    onValueChange={(value: Ticket["category"]) => setNewTicket({ ...newTicket, category: value })}
                  >
                    <SelectTrigger id="category" className="col-span-3">
                      <SelectValue placeholder="Seleccionar categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="preventivo">Preventivo</SelectItem>
                      <SelectItem value="correctivo">Correctivo</SelectItem>
                      <SelectItem value="instalacion">Instalación</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="priority" className="text-right">
                    Prioridad
                  </label>
                  <Select
                    value={newTicket.priority}
                    onValueChange={(value: Ticket["priority"]) => setNewTicket({ ...newTicket, priority: value })}
                  >
                    <SelectTrigger id="priority" className="col-span-3">
                      <SelectValue placeholder="Seleccionar prioridad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baja">Baja</SelectItem>
                      <SelectItem value="media">Media</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {/* Actualizar el diálogo de creación de tickets para usar la lista de técnicos */}
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="assignedTo" className="text-right">
                    Asignado a
                  </label>
                  <div className="col-span-3">
                    <Select
                      value={newTicket.assignedTo}
                      onValueChange={(value) => setNewTicket({ ...newTicket, assignedTo: value })}
                    >
                      <SelectTrigger id="assignedTo">
                        <SelectValue placeholder="Seleccionar responsable" />
                      </SelectTrigger>
                      <SelectContent>
                        {technicians.map((tech) => (
                          <SelectItem key={tech} value={tech}>
                            {tech}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="mt-2 flex items-center gap-2">
                      <Input
                        placeholder="Agregar nuevo técnico"
                        value={newTechnician}
                        onChange={(e) => setNewTechnician(e.target.value)}
                        className="flex-1"
                      />
                      <Button size="sm" onClick={handleAddTechnician} disabled={newTechnician.trim() === ""}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddTicket} disabled={!newTicket.title || !newTicket.client}>
                  Crear Ticket
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          {/* Agregar un diálogo para gestionar técnicos */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="ml-auto">
                <Users className="mr-2 h-4 w-4" />
                Gestionar Técnicos
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Gestionar Técnicos</DialogTitle>
                <DialogDescription>
                  Agregue, edite o elimine técnicos disponibles para asignar tickets.
                </DialogDescription>
              </DialogHeader>
              <div className="mt-4 space-y-4">
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Nombre del técnico"
                    value={newTechnician}
                    onChange={(e) => setNewTechnician(e.target.value)}
                  />
                  <Button onClick={handleAddTechnician} disabled={newTechnician.trim() === ""}>
                    <Plus className="mr-2 h-4 w-4" />
                    Agregar
                  </Button>
                </div>
                <div className="max-h-[300px] overflow-y-auto rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nombre</TableHead>
                        <TableHead className="w-[100px] text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {technicians.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={2} className="h-24 text-center">
                            No hay técnicos registrados.
                          </TableCell>
                        </TableRow>
                      ) : (
                        technicians.map((tech) => (
                          <TableRow key={tech}>
                            <TableCell>{tech}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteTechnician(tech)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="lista" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="lista">Lista de Tickets</TabsTrigger>
          <TabsTrigger value="kanban">Vista Kanban</TabsTrigger>
        </TabsList>
        <TabsContent value="lista" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Tickets de Servicio Técnico</CardTitle>
              <CardDescription>Gestione los tickets de servicio técnico y su estado.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex flex-col gap-4 md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por título, descripción o cliente..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        Categoría
                      </Button>
                    </DropdownMenuTrigger>
                  </DropdownMenu>
                </div>
              </div>
              {/* Mejorar la visualización de detalles del ticket */}
              {selectedTicket && (
                <Card className="mt-4">
                  <CardHeader className="flex flex-row items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <span>Ticket #{selectedTicket.id}</span>
                        <Badge className={getPriorityColor(selectedTicket.priority)}>
                          {getPriorityLabel(selectedTicket.priority)}
                        </Badge>
                      </CardTitle>
                      <CardDescription>
                        Creado el {formatDateTime(selectedTicket.createdAt)} • Última actualización:{" "}
                        {formatDateTime(selectedTicket.updatedAt)}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={selectedTicket.status}
                        onValueChange={(value: Ticket["status"]) => handleUpdateTicketStatus(selectedTicket.id, value)}
                      >
                        <SelectTrigger className="w-[150px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pendiente">Pendiente</SelectItem>
                          <SelectItem value="en_progreso">En Progreso</SelectItem>
                          <SelectItem value="resuelto">Resuelto</SelectItem>
                          <SelectItem value="cancelado">Cancelado</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="icon" onClick={() => setSelectedTicket(null)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <h3 className="mb-2 text-sm font-medium">Detalles</h3>
                        <div className="rounded-lg border p-4">
                          <div className="mb-2">
                            <span className="text-sm text-muted-foreground">Título:</span>
                            <p className="font-medium">{selectedTicket.title}</p>
                          </div>
                          <div className="mb-2">
                            <span className="text-sm text-muted-foreground">Cliente:</span>
                            <p className="font-medium">{selectedTicket.client}</p>
                          </div>
                          <div className="mb-2">
                            <span className="text-sm text-muted-foreground">Categoría:</span>
                            <p className="font-medium">{getCategoryLabel(selectedTicket.category)}</p>
                          </div>
                          <div>
                            <span className="text-sm text-muted-foreground">Asignado a:</span>
                            <p className="font-medium">{selectedTicket.assignedTo}</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h3 className="mb-2 text-sm font-medium">Descripción</h3>
                        <div className="rounded-lg border p-4">
                          <p className="whitespace-pre-wrap text-sm">
                            {selectedTicket.description || "Sin descripción."}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="mb-2 flex items-center justify-between">
                        <h3 className="text-sm font-medium">Notas y Seguimiento</h3>
                        <Badge variant="outline" className={`${getStatusColor(selectedTicket.status)} text-white`}>
                          {getStatusLabel(selectedTicket.status)}
                        </Badge>
                      </div>
                      <div className="rounded-lg border p-4">
                        <div className="mb-4 max-h-[200px] space-y-2 overflow-y-auto">
                          {selectedTicket.notes.length === 0 ? (
                            <p className="text-center text-sm text-muted-foreground">No hay notas registradas.</p>
                          ) : (
                            selectedTicket.notes.map((note, index) => (
                              <div key={index} className="flex items-start justify-between rounded-md border p-2">
                                <p className="text-sm">{note}</p>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => handleDeleteNote(selectedTicket.id, index)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Textarea
                            placeholder="Agregar una nota..."
                            value={newNote}
                            onChange={(e) => setNewNote(e.target.value)}
                            className="min-h-[80px] resize-none"
                          />
                          <Button onClick={handleAddNote} disabled={!newNote.trim()} className="self-end">
                            Agregar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="kanban">En construcción...</TabsContent>
      </Tabs>
    </div>
  )
}
