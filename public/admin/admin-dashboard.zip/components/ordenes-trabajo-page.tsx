"use client"

import type React from "react"

import { useState } from "react"
import { Download, Plus, RefreshCw, Search, Trash2, FileText } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useAppContext, type WorkOrder, type WorkOrderItem } from "@/contexts/app-context"

export function OrdenesTrabajoPage() {
  const { workOrders, setWorkOrders, users } = useAppContext()
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("lista")
  const [newWorkOrder, setNewWorkOrder] = useState<Omit<WorkOrder, "id" | "orderNumber" | "items" | "total" | "notes">>(
    {
      client: "",
      date: new Date().toISOString().split("T")[0],
      status: "pendiente",
      type: "instalacion",
      assignedTo: "",
      description: "",
    },
  )
  const [workOrderItems, setWorkOrderItems] = useState<Omit<WorkOrderItem, "id" | "subtotal">[]>([])
  const [currentItem, setCurrentItem] = useState<Omit<WorkOrderItem, "id" | "subtotal">>({
    description: "",
    quantity: 1,
    unitPrice: 0,
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<WorkOrder | null>(null)
  const [newNote, setNewNote] = useState("")
  const { toast } = useToast()

  const handleAddItem = () => {
    if (!currentItem.description || currentItem.quantity <= 0 || currentItem.unitPrice <= 0) return

    setWorkOrderItems([...workOrderItems, currentItem])
    setCurrentItem({
      description: "",
      quantity: 1,
      unitPrice: 0,
    })
  }

  const handleRemoveItem = (index: number) => {
    setWorkOrderItems(workOrderItems.filter((_, i) => i !== index))
  }

  const calculateTotal = () => {
    return workOrderItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
  }

  const handleAddWorkOrder = () => {
    if (!newWorkOrder.client || !newWorkOrder.assignedTo || workOrderItems.length === 0) {
      toast({
        title: "Error al crear orden de trabajo",
        description: "Por favor complete todos los campos y agregue al menos un ítem.",
        variant: "destructive",
      })
      return
    }

    const id = Math.max(0, ...workOrders.map((s) => s.id)) + 1
    const orderNumber = `OT-${1000 + id}`
    const total = calculateTotal()

    const items: WorkOrderItem[] = workOrderItems.map((item, index) => ({
      id: index + 1,
      ...item,
      subtotal: item.quantity * item.unitPrice,
    }))

    const workOrder: WorkOrder = {
      id,
      orderNumber,
      ...newWorkOrder,
      items,
      total,
      notes: [],
    }

    setWorkOrders([workOrder, ...workOrders])
    setNewWorkOrder({
      client: "",
      date: new Date().toISOString().split("T")[0],
      status: "pendiente",
      type: "instalacion",
      assignedTo: "",
      description: "",
    })
    setWorkOrderItems([])
    setIsAddDialogOpen(false)

    toast({
      title: "Orden de trabajo creada",
      description: `Se ha creado la orden ${orderNumber} para ${newWorkOrder.client}.`,
    })
  }

  const handleUpdateWorkOrderStatus = (id: number, status: WorkOrder["status"]) => {
    setWorkOrders(
      workOrders.map((workOrder) => {
        if (workOrder.id === id) {
          return {
            ...workOrder,
            status,
          }
        }
        return workOrder
      }),
    )

    toast({
      title: "Estado actualizado",
      description: `El estado de la orden ha sido actualizado a "${getStatusLabel(status)}".`,
    })
  }

  const handleViewWorkOrder = (workOrder: WorkOrder) => {
    setSelectedWorkOrder(workOrder)
  }

  const handleAddNote = () => {
    if (!selectedWorkOrder || !newNote.trim()) return

    const updatedWorkOrder = {
      ...selectedWorkOrder,
      notes: [...selectedWorkOrder.notes, newNote.trim()],
    }

    setWorkOrders(workOrders.map((wo) => (wo.id === selectedWorkOrder.id ? updatedWorkOrder : wo)))
    setSelectedWorkOrder(updatedWorkOrder)
    setNewNote("")

    toast({
      title: "Nota agregada",
      description: "Se ha agregado una nueva nota a la orden de trabajo.",
    })
  }

  const handleDeleteNote = (workOrderId: number, noteIndex: number) => {
    const workOrder = workOrders.find((wo) => wo.id === workOrderId)
    if (!workOrder) return

    const updatedNotes = [...workOrder.notes]
    updatedNotes.splice(noteIndex, 1)

    const updatedWorkOrder = {
      ...workOrder,
      notes: updatedNotes,
    }

    setWorkOrders(workOrders.map((wo) => (wo.id === workOrderId ? updatedWorkOrder : wo)))

    if (selectedWorkOrder && selectedWorkOrder.id === workOrderId) {
      setSelectedWorkOrder(updatedWorkOrder)
    }

    toast({
      title: "Nota eliminada",
      description: "Se ha eliminado la nota de la orden de trabajo.",
      variant: "destructive",
    })
  }

  const filteredWorkOrders = workOrders.filter((workOrder) => {
    const matchesSearch =
      workOrder.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      workOrder.client.toLowerCase().includes(searchTerm.toLowerCase()) ||
      workOrder.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || workOrder.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando órdenes",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Órdenes actualizadas",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos de órdenes se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  const getTypeLabel = (type: WorkOrder["type"]) => {
    switch (type) {
      case "instalacion":
        return "Instalación"
      case "reparacion":
        return "Reparación"
      case "mantenimiento":
        return "Mantenimiento"
      default:
        return type
    }
  }

  const getStatusLabel = (status: WorkOrder["status"]) => {
    switch (status) {
      case "pendiente":
        return "Pendiente"
      case "en_curso":
        return "En Curso"
      case "completada":
        return "Completada"
      case "cancelada":
        return "Cancelada"
      default:
        return status
    }
  }

  const getStatusColor = (status: WorkOrder["status"]) => {
    switch (status) {
      case "pendiente":
        return "bg-amber-500"
      case "en_curso":
        return "bg-blue-500"
      case "completada":
        return "bg-green-500"
      case "cancelada":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Órdenes de Trabajo</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nueva Orden
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crear Nueva Orden de Trabajo</DialogTitle>
                <DialogDescription>Complete los detalles de la nueva orden de trabajo.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="client" className="text-right">
                    Cliente
                  </label>
                  <Input
                    id="client"
                    value={newWorkOrder.client}
                    onChange={(e) => setNewWorkOrder({ ...newWorkOrder, client: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="date" className="text-right">
                    Fecha
                  </label>
                  <Input
                    id="date"
                    type="date"
                    value={newWorkOrder.date}
                    onChange={(e) => setNewWorkOrder({ ...newWorkOrder, date: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="type" className="text-right">
                    Tipo
                  </label>
                  <Select
                    value={newWorkOrder.type}
                    onValueChange={(value: WorkOrder["type"]) => setNewWorkOrder({ ...newWorkOrder, type: value })}
                  >
                    <SelectTrigger id="type" className="col-span-3">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="instalacion">Instalación</SelectItem>
                      <SelectItem value="reparacion">Reparación</SelectItem>
                      <SelectItem value="mantenimiento">Mantenimiento</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="assignedTo" className="text-right">
                    Asignado a
                  </label>
                  <Select
                    value={newWorkOrder.assignedTo}
                    onValueChange={(value) => setNewWorkOrder({ ...newWorkOrder, assignedTo: value })}
                  >
                    <SelectTrigger id="assignedTo" className="col-span-3">
                      <SelectValue placeholder="Seleccionar técnico" />
                    </SelectTrigger>
                    <SelectContent>
                      {users
                        .filter((u) => u.role === "tecnico" || u.role === "admin")
                        .map((user) => (
                          <SelectItem key={user.id} value={user.name}>
                            {user.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <label htmlFor="description" className="text-right pt-2">
                    Descripción
                  </label>
                  <Textarea
                    id="description"
                    value={newWorkOrder.description}
                    onChange={(e) => setNewWorkOrder({ ...newWorkOrder, description: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>

                <div className="mt-4 border-t pt-4">
                  <h4 className="mb-4 font-medium">Ítems de la Orden</h4>
                  <div className="grid grid-cols-12 gap-2">
                    <div className="col-span-5">
                      <Input
                        placeholder="Descripción del ítem"
                        value={currentItem.description}
                        onChange={(e) => setCurrentItem({ ...currentItem, description: e.target.value })}
                      />
                    </div>
                    <div className="col-span-2">
                      <Input
                        type="number"
                        placeholder="Cantidad"
                        min="1"
                        value={currentItem.quantity}
                        onChange={(e) =>
                          setCurrentItem({ ...currentItem, quantity: Number.parseInt(e.target.value) || 1 })
                        }
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="number"
                        placeholder="Precio unitario"
                        min="0"
                        value={currentItem.unitPrice}
                        onChange={(e) =>
                          setCurrentItem({ ...currentItem, unitPrice: Number.parseInt(e.target.value) || 0 })
                        }
                      />
                    </div>
                    <div className="col-span-2">
                      <Button
                        onClick={handleAddItem}
                        disabled={!currentItem.description || currentItem.quantity <= 0 || currentItem.unitPrice <= 0}
                        className="w-full"
                      >
                        Agregar
                      </Button>
                    </div>
                  </div>

                  <div className="mt-4 rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Descripción</TableHead>
                          <TableHead className="text-center">Cantidad</TableHead>
                          <TableHead className="text-right">Precio Unitario</TableHead>
                          <TableHead className="text-right">Subtotal</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {workOrderItems.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="h-24 text-center">
                              No hay ítems agregados.
                            </TableCell>
                          </TableRow>
                        ) : (
                          workOrderItems.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell>{item.description}</TableCell>
                              <TableCell className="text-center">{item.quantity}</TableCell>
                              <TableCell className="text-right">${item.unitPrice.toLocaleString("es-CL")}</TableCell>
                              <TableCell className="text-right">
                                ${(item.quantity * item.unitPrice).toLocaleString("es-CL")}
                              </TableCell>
                              <TableCell>
                                <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(index)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                        <TableRow>
                          <TableCell colSpan={3} className="text-right font-bold">
                            Total
                          </TableCell>
                          <TableCell className="text-right font-bold">
                            ${calculateTotal().toLocaleString("es-CL")}
                          </TableCell>
                          <TableCell></TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleAddWorkOrder}
                  disabled={!newWorkOrder.client || !newWorkOrder.assignedTo || workOrderItems.length === 0}
                >
                  Crear Orden
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="lista" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="lista">Lista de Órdenes</TabsTrigger>
          <TabsTrigger value="estadisticas">Estadísticas</TabsTrigger>
        </TabsList>
        <TabsContent value="lista" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Órdenes de Trabajo</CardTitle>
              <CardDescription>Gestione las órdenes de trabajo y su estado.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex flex-col gap-4 md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por número, cliente o descripción..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Filtrar por estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los estados</SelectItem>
                      <SelectItem value="pendiente">Pendiente</SelectItem>
                      <SelectItem value="en_curso">En Curso</SelectItem>
                      <SelectItem value="completada">Completada</SelectItem>
                      <SelectItem value="cancelada">Cancelada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Detalles de la orden seleccionada */}
              {selectedWorkOrder && (
                <Card className="mt-4 mb-6">
                  <CardHeader className="flex flex-row items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="h-5 w-5" />
                        Orden #{selectedWorkOrder.orderNumber}
                      </CardTitle>
                      <CardDescription>Creada el {formatDate(selectedWorkOrder.date)}</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={selectedWorkOrder.status}
                        onValueChange={(value: WorkOrder["status"]) =>
                          handleUpdateWorkOrderStatus(selectedWorkOrder.id, value)
                        }
                      >
                        <SelectTrigger className="w-[150px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pendiente">Pendiente</SelectItem>
                          <SelectItem value="en_curso">En Curso</SelectItem>
                          <SelectItem value="completada">Completada</SelectItem>
                          <SelectItem value="cancelada">Cancelada</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="icon" onClick={() => setSelectedWorkOrder(null)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <h3 className="mb-2 text-sm font-medium">Detalles</h3>
                        <div className="rounded-lg border p-4">
                          <div className="mb-2">
                            <span className="text-sm text-muted-foreground">Cliente:</span>
                            <p className="font-medium">{selectedWorkOrder.client}</p>
                          </div>
                          <div className="mb-2">
                            <span className="text-sm text-muted-foreground">Tipo:</span>
                            <p className="font-medium">{getTypeLabel(selectedWorkOrder.type)}</p>
                          </div>
                          <div className="mb-2">
                            <span className="text-sm text-muted-foreground">Asignado a:</span>
                            <p className="font-medium">{selectedWorkOrder.assignedTo}</p>
                          </div>
                          <div>
                            <span className="text-sm text-muted-foreground">Estado:</span>
                            <Badge className={`ml-2 ${getStatusColor(selectedWorkOrder.status)}`}>
                              {getStatusLabel(selectedWorkOrder.status)}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h3 className="mb-2 text-sm font-medium">Descripción</h3>
                        <div className="rounded-lg border p-4">
                          <p className="whitespace-pre-wrap text-sm">
                            {selectedWorkOrder.description || "Sin descripción."}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="mb-2 text-sm font-medium">Ítems</h3>
                      <div className="rounded-lg border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Descripción</TableHead>
                              <TableHead className="text-center">Cantidad</TableHead>
                              <TableHead className="text-right">Precio Unitario</TableHead>
                              <TableHead className="text-right">Subtotal</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedWorkOrder.items.map((item) => (
                              <TableRow key={item.id}>
                                <TableCell>{item.description}</TableCell>
                                <TableCell className="text-center">{item.quantity}</TableCell>
                                <TableCell className="text-right">${item.unitPrice.toLocaleString("es-CL")}</TableCell>
                                <TableCell className="text-right">${item.subtotal.toLocaleString("es-CL")}</TableCell>
                              </TableRow>
                            ))}
                            <TableRow>
                              <TableCell colSpan={3} className="text-right font-bold">
                                Total
                              </TableCell>
                              <TableCell className="text-right font-bold">
                                ${selectedWorkOrder.total.toLocaleString("es-CL")}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>

                    <div>
                      <h3 className="mb-2 text-sm font-medium">Notas y Seguimiento</h3>
                      <div className="rounded-lg border p-4">
                        <div className="mb-4 max-h-[200px] space-y-2 overflow-y-auto">
                          {selectedWorkOrder.notes.length === 0 ? (
                            <p className="text-center text-sm text-muted-foreground">No hay notas registradas.</p>
                          ) : (
                            selectedWorkOrder.notes.map((note, index) => (
                              <div key={index} className="flex items-start justify-between rounded-md border p-2">
                                <p className="text-sm">{note}</p>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => handleDeleteNote(selectedWorkOrder.id, index)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Textarea
                            placeholder="Agregar una nota..."
                            value={newNote}
                            onChange={(e) => setNewNote(e.target.value)}
                            className="min-h-[80px] resize-none"
                          />
                          <Button onClick={handleAddNote} disabled={!newNote.trim()} className="self-end">
                            Agregar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Orden #</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Asignado a</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-20 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-6 w-20 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filteredWorkOrders.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="h-24 text-center">
                          No se encontraron órdenes de trabajo.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredWorkOrders.map((workOrder) => (
                        <TableRow key={workOrder.id}>
                          <TableCell className="font-medium">{workOrder.orderNumber}</TableCell>
                          <TableCell>{workOrder.client}</TableCell>
                          <TableCell>{formatDate(workOrder.date)}</TableCell>
                          <TableCell>{getTypeLabel(workOrder.type)}</TableCell>
                          <TableCell>{workOrder.assignedTo}</TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(workOrder.status)}>
                              {getStatusLabel(workOrder.status)}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">${workOrder.total.toLocaleString("es-CL")}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleViewWorkOrder(workOrder)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => handleViewWorkOrder(workOrder)}>
                                    Ver detalles
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>Imprimir</DropdownMenuItem>
                                  <DropdownMenuItem>Enviar por email</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600">Eliminar</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="estadisticas" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Estadísticas de Órdenes de Trabajo</CardTitle>
              <CardDescription>Visualización de datos de órdenes por período y tipo.</CardDescription>
            </CardHeader>
            <CardContent className="h-96 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <p>Módulo de estadísticas en desarrollo</p>
                <p className="text-sm">Próximamente disponible</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function X(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  )
}

function Eye(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function MoreVertical(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="1" />
      <circle cx="12" cy="5" r="1" />
      <circle cx="12" cy="19" r="1" />
    </svg>
  )
}
