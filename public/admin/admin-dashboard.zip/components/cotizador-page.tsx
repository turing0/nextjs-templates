"use client"

import { useState, useEffect } from "react"
import { Download, Edit, Plus, Save, Trash2, Truck, Plane } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"

interface CityRate {
  id: number
  city: string
  groundRate: number
  airRate: number
}

interface Product {
  id: number
  name: string
  cost: number
  margin: number
  price: number
}

// Actualizar la interfaz QuoteItem para incluir los nuevos campos
// Buscar la interfaz y reemplazarla:

// Actualizar la interfaz QuoteItem para incluir toma de puntos
interface QuoteItem {
  id: number
  product: Product
  quantity: number
  subtotal: number
  includeSurvey?: boolean // Indica si incluye toma de puntos
  surveyRateId?: string | null // ID de la tarifa seleccionada
  surveyRateName?: string // Nombre de la tarifa seleccionada
  surveyRatePrice?: number // Precio adicional por la toma de puntos
}

interface Quote {
  id: number
  client: string
  date: string
  city: string
  transportType: "ground" | "air"
  items: QuoteItem[]
  transportCost: number
  total: number
}

// Agregar un nuevo tipo para las tarifas con/sin toma de puntos
interface ServiceRate {
  id: number
  name: string
  description: string
  priceWithSurvey: number
  priceWithoutSurvey: number
  category: "instalacion" | "mantenimiento" | "reparacion" | "consultoria"
}

export function CotizadorPage() {
  const [cityRates, setCityRates] = useState<CityRate[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [quotes, setQuotes] = useState<Quote[]>([])
  const [activeTab, setActiveTab] = useState("cotizador")
  const [loading, setLoading] = useState(true)
  const [editingCityRate, setEditingCityRate] = useState<CityRate | null>(null)
  const [newCityRate, setNewCityRate] = useState<Omit<CityRate, "id">>({
    city: "",
    groundRate: 0,
    airRate: 0,
  })
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [newProduct, setNewProduct] = useState<Omit<Product, "id" | "price">>({
    name: "",
    cost: 0,
    margin: 30,
  })
  const [currentQuote, setCurrentQuote] = useState<Omit<Quote, "id" | "items" | "transportCost" | "total">>({
    client: "",
    date: new Date().toISOString().split("T")[0],
    city: "",
    transportType: "ground",
  })
  const [quoteItems, setQuoteItems] = useState<QuoteItem[]>([])
  const [selectedProduct, setSelectedProduct] = useState<string>("")
  const [productQuantity, setProductQuantity] = useState<number>(1)
  const { toast } = useToast()

  // Agregar el estado para las tarifas de servicio
  const [serviceRates, setServiceRates] = useState<ServiceRate[]>([])
  const [newServiceRate, setNewServiceRate] = useState<Omit<ServiceRate, "id">>({
    name: "",
    description: "",
    priceWithSurvey: 0,
    priceWithoutSurvey: 0,
    category: "instalacion",
  })
  const [isAddServiceRateOpen, setIsAddServiceRateOpen] = useState(false)
  const [editingServiceRate, setEditingServiceRate] = useState<ServiceRate | null>(null)

  // Actualizar el estado para incluir toma de puntos
  const [includeSurvey, setIncludeSurvey] = useState<boolean>(false)
  const [selectedSurveyRate, setSelectedSurveyRate] = useState<string | null>(null)

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockCityRates: CityRate[] = [
        { id: 1, city: "Santiago", groundRate: 15000, airRate: 45000 },
        { id: 2, city: "Valparaíso", groundRate: 25000, airRate: 55000 },
        { id: 3, city: "Concepción", groundRate: 35000, airRate: 65000 },
        { id: 4, city: "Antofagasta", groundRate: 45000, airRate: 75000 },
        { id: 5, city: "Puerto Montt", groundRate: 40000, airRate: 70000 },
      ]

      const mockProducts: Product[] = [
        { id: 1, name: 'Monitor LG 24"', cost: 120000, margin: 25, price: 150000 },
        { id: 2, name: "Teclado Mecánico RGB", cost: 35000, margin: 30, price: 45500 },
        { id: 3, name: "Mouse Inalámbrico", cost: 18000, margin: 35, price: 24300 },
        { id: 4, name: "Disco SSD 500GB", cost: 50000, margin: 30, price: 65000 },
        { id: 5, name: "Memoria RAM 16GB", cost: 42000, margin: 28, price: 53760 },
      ]

      const mockQuotes: Quote[] = [
        {
          id: 1,
          client: "Empresa ABC Ltda.",
          date: "2025-04-10",
          city: "Santiago",
          transportType: "ground",
          items: [
            { id: 1, product: mockProducts[0], quantity: 2, subtotal: 300000 },
            { id: 2, product: mockProducts[3], quantity: 3, subtotal: 195000 },
          ],
          transportCost: 15000,
          total: 510000,
        },
        {
          id: 2,
          client: "Comercial XYZ S.A.",
          date: "2025-04-12",
          city: "Concepción",
          transportType: "air",
          items: [
            { id: 1, product: mockProducts[1], quantity: 5, subtotal: 227500 },
            { id: 2, product: mockProducts[2], quantity: 10, subtotal: 243000 },
          ],
          transportCost: 65000,
          total: 535500,
        },
      ]

      setCityRates(mockCityRates)
      setProducts(mockProducts)
      setQuotes(mockQuotes)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Agregar el efecto para cargar las tarifas de ejemplo
  useEffect(() => {
    // Simular carga de datos
    const timer = setTimeout(() => {
      const mockServiceRates: ServiceRate[] = [
        {
          id: 1,
          name: "Instalación básica",
          description: "Instalación básica de equipos informáticos",
          priceWithSurvey: 85000,
          priceWithoutSurvey: 65000,
          category: "instalacion",
        },
        {
          id: 2,
          name: "Instalación avanzada",
          description: "Instalación y configuración de equipos en red",
          priceWithSurvey: 120000,
          priceWithoutSurvey: 95000,
          category: "instalacion",
        },
        {
          id: 3,
          name: "Mantenimiento preventivo",
          description: "Limpieza y actualización de equipos",
          priceWithSurvey: 65000,
          priceWithoutSurvey: 45000,
          category: "mantenimiento",
        },
        {
          id: 4,
          name: "Reparación de hardware",
          description: "Diagnóstico y reparación de componentes",
          priceWithSurvey: 95000,
          priceWithoutSurvey: 75000,
          category: "reparacion",
        },
        {
          id: 5,
          name: "Consultoría TI",
          description: "Asesoría en implementación de sistemas",
          priceWithSurvey: 150000,
          priceWithoutSurvey: 120000,
          category: "consultoria",
        },
      ]
      setServiceRates(mockServiceRates)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const calculateProductPrice = (cost: number, margin: number) => {
    return cost * (1 + margin / 100)
  }

  const handleAddCityRate = () => {
    const id = Math.max(0, ...cityRates.map((c) => c.id)) + 1
    setCityRates([...cityRates, { ...newCityRate, id }])
    setNewCityRate({
      city: "",
      groundRate: 0,
      airRate: 0,
    })

    toast({
      title: "Tarifa agregada",
      description: `Se ha agregado la tarifa para ${newCityRate.city}.`,
    })
  }

  const handleUpdateCityRate = () => {
    if (!editingCityRate) return

    setCityRates(cityRates.map((c) => (c.id === editingCityRate.id ? editingCityRate : c)))
    setEditingCityRate(null)

    toast({
      title: "Tarifa actualizada",
      description: `Se ha actualizado la tarifa para ${editingCityRate.city}.`,
    })
  }

  const handleDeleteCityRate = (id: number) => {
    const cityToDelete = cityRates.find((c) => c.id === id)
    setCityRates(cityRates.filter((c) => c.id !== id))

    toast({
      title: "Tarifa eliminada",
      description: `Se ha eliminado la tarifa para ${cityToDelete?.city}.`,
      variant: "destructive",
    })
  }

  const handleAddProduct = () => {
    const id = Math.max(0, ...products.map((p) => p.id)) + 1
    const price = calculateProductPrice(newProduct.cost, newProduct.margin)
    setProducts([...products, { ...newProduct, id, price }])
    setNewProduct({
      name: "",
      cost: 0,
      margin: 30,
    })

    toast({
      title: "Producto agregado",
      description: `Se ha agregado el producto ${newProduct.name}.`,
    })
  }

  const handleUpdateProduct = () => {
    if (!editingProduct) return

    const updatedProduct = {
      ...editingProduct,
      price: calculateProductPrice(editingProduct.cost, editingProduct.margin),
    }

    setProducts(products.map((p) => (p.id === editingProduct.id ? updatedProduct : p)))
    setEditingProduct(null)

    toast({
      title: "Producto actualizado",
      description: `Se ha actualizado el producto ${updatedProduct.name}.`,
    })
  }

  const handleDeleteProduct = (id: number) => {
    const productToDelete = products.find((p) => p.id === id)
    setProducts(products.filter((p) => p.id !== id))

    toast({
      title: "Producto eliminado",
      description: `Se ha eliminado el producto ${productToDelete?.name}.`,
      variant: "destructive",
    })
  }

  // Actualizar la función handleAddQuoteItem para incluir toma de puntos
  // Actualizar la función handleAddQuoteItem para incluir toma de puntos y la tarifa seleccionada
  const handleAddQuoteItem = () => {
    if (!selectedProduct) return

    const product = products.find((p) => p.id.toString() === selectedProduct)
    if (!product) return

    const id = quoteItems.length > 0 ? Math.max(...quoteItems.map((item) => item.id)) + 1 : 1
    const subtotal = product.price * productQuantity

    // Obtener la tarifa seleccionada si existe
    const surveyRate = selectedSurveyRate
      ? serviceRates.find((rate) => rate.id.toString() === selectedSurveyRate)
      : null

    setQuoteItems([
      ...quoteItems,
      {
        id,
        product,
        quantity: productQuantity,
        subtotal,
        includeSurvey,
        surveyRateId: selectedSurveyRate,
        surveyRateName: surveyRate?.name || "",
        surveyRatePrice: surveyRate ? surveyRate.priceWithSurvey - surveyRate.priceWithoutSurvey : 0,
      },
    ])

    setSelectedProduct("")
    setProductQuantity(1)
    setIncludeSurvey(false)
    setSelectedSurveyRate(null)
  }

  const handleRemoveQuoteItem = (id: number) => {
    setQuoteItems(quoteItems.filter((item) => item.id !== id))
  }

  const handleSaveQuote = () => {
    if (!currentQuote.client || !currentQuote.city || quoteItems.length === 0) {
      toast({
        title: "Error al guardar",
        description: "Por favor complete todos los campos y agregue al menos un producto.",
        variant: "destructive",
      })
      return
    }

    const selectedCityRate = cityRates.find((c) => c.city === currentQuote.city)
    if (!selectedCityRate) return

    const transportCost =
      currentQuote.transportType === "ground" ? selectedCityRate.groundRate : selectedCityRate.airRate

    const itemsTotal = quoteItems.reduce((sum, item) => sum + item.subtotal, 0)
    const total = itemsTotal + transportCost

    const id = quotes.length > 0 ? Math.max(...quotes.map((q) => q.id)) + 1 : 1

    const newQuote: Quote = {
      id,
      client: currentQuote.client,
      date: currentQuote.date,
      city: currentQuote.city,
      transportType: currentQuote.transportType,
      items: [...quoteItems],
      transportCost,
      total,
    }

    setQuotes([newQuote, ...quotes])

    // Reset form
    setCurrentQuote({
      client: "",
      date: new Date().toISOString().split("T")[0],
      city: "",
      transportType: "ground",
    })
    setQuoteItems([])

    toast({
      title: "Cotización guardada",
      description: `Se ha guardado la cotización para ${newQuote.client} por $${newQuote.total.toLocaleString("es-CL")}.`,
    })
  }

  const exportQuote = () => {
    toast({
      title: "Exportando cotización",
      description: "La cotización se está exportando a PDF...",
    })

    setTimeout(() => {
      toast({
        title: "Cotización exportada",
        description: "El archivo PDF ha sido generado correctamente.",
      })
    }, 1000)
  }

  // Actualizar la función calculateQuoteTotal para incluir costos adicionales por toma de puntos
  // Actualizar la función calculateQuoteTotal para usar las tarifas específicas seleccionadas
  const calculateQuoteTotal = () => {
    // Calcular el subtotal de los productos
    const itemsTotal = quoteItems.reduce((sum, item) => sum + item.subtotal, 0)

    // Calcular el costo adicional por toma de puntos usando las tarifas seleccionadas
    const surveyTotal = quoteItems.reduce((sum, item) => {
      if (item.includeSurvey) {
        if (item.surveyRatePrice) {
          // Si tiene un precio específico de tarifa, usarlo
          return sum + item.surveyRatePrice * item.quantity
        } else {
          // Si no tiene tarifa específica, usar el 15% por defecto
          return sum + item.subtotal * 0.15
        }
      }
      return sum
    }, 0)

    // Calcular el costo de transporte
    let transportCost = 0
    if (currentQuote.city) {
      const selectedCityRate = cityRates.find((c) => c.city === currentQuote.city)
      if (selectedCityRate) {
        transportCost = currentQuote.transportType === "ground" ? selectedCityRate.groundRate : selectedCityRate.airRate
      }
    }

    // Retornar el total
    return itemsTotal + surveyTotal + transportCost
  }

  const getTransportCost = () => {
    if (!currentQuote.city) return 0

    const selectedCityRate = cityRates.find((c) => c.city === currentQuote.city)
    if (!selectedCityRate) return 0

    return currentQuote.transportType === "ground" ? selectedCityRate.groundRate : selectedCityRate.airRate
  }

  // Agregar la función para manejar la adición de nuevas tarifas
  const handleAddServiceRate = () => {
    const id = Math.max(0, ...serviceRates.map((s) => s.id), 0) + 1

    setServiceRates([...serviceRates, { ...newServiceRate, id }])
    setNewServiceRate({
      name: "",
      description: "",
      priceWithSurvey: 0,
      priceWithoutSurvey: 0,
      category: "instalacion",
    })
    setIsAddServiceRateOpen(false)

    toast({
      title: "Tarifa agregada",
      description: `Se ha agregado la tarifa "${newServiceRate.name}" correctamente.`,
    })
  }

  // Agregar la función para actualizar una tarifa
  const handleUpdateServiceRate = () => {
    if (!editingServiceRate) return

    setServiceRates(serviceRates.map((rate) => (rate.id === editingServiceRate.id ? editingServiceRate : rate)))
    setEditingServiceRate(null)

    toast({
      title: "Tarifa actualizada",
      description: `Se ha actualizado la tarifa "${editingServiceRate.name}" correctamente.`,
    })
  }

  // Agregar la función para eliminar una tarifa
  const handleDeleteServiceRate = (id: number) => {
    const rateToDelete = serviceRates.find((r) => r.id === id)
    setServiceRates(serviceRates.filter((r) => r.id !== id))

    toast({
      title: "Tarifa eliminada",
      description: `Se ha eliminado la tarifa "${rateToDelete?.name}" correctamente.`,
      variant: "destructive",
    })
  }

  // Agregar la función para obtener el color según la categoría
  const getCategoryColor = (category: ServiceRate["category"]) => {
    switch (category) {
      case "instalacion":
        return "bg-blue-500"
      case "mantenimiento":
        return "bg-green-500"
      case "reparacion":
        return "bg-amber-500"
      case "consultoria":
        return "bg-purple-500"
      default:
        return "bg-gray-500"
    }
  }

  // Agregar la función para obtener la etiqueta de la categoría
  const getCategoryLabel = (category: ServiceRate["category"]) => {
    switch (category) {
      case "instalacion":
        return "Instalación"
      case "mantenimiento":
        return "Mantenimiento"
      case "reparacion":
        return "Reparación"
      case "consultoria":
        return "Consultoría"
      default:
        return category
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Cotizador</h2>
      </div>

      <Tabs defaultValue="cotizador" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="cotizador">Cotizador</TabsTrigger>
          <TabsTrigger value="productos">Productos</TabsTrigger>
          <TabsTrigger value="tarifas">Tarifas de Transporte</TabsTrigger>
          <TabsTrigger value="tarifasPuntos">Tarifas de Toma de Puntos</TabsTrigger>
        </TabsList>

        {/* Cotizador Tab */}
        <TabsContent value="cotizador" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Nueva Cotización</CardTitle>
              <CardDescription>Cree una nueva cotización para un cliente.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="client">Cliente</Label>
                  <Input
                    id="client"
                    placeholder="Nombre del cliente"
                    value={currentQuote.client}
                    onChange={(e) => setCurrentQuote({ ...currentQuote, client: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Fecha</Label>
                  <Input
                    id="date"
                    type="date"
                    value={currentQuote.date}
                    onChange={(e) => setCurrentQuote({ ...currentQuote, date: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city">Ciudad de Destino</Label>
                  <Select
                    value={currentQuote.city}
                    onValueChange={(value) => setCurrentQuote({ ...currentQuote, city: value })}
                  >
                    <SelectTrigger id="city">
                      <SelectValue placeholder="Seleccionar ciudad" />
                    </SelectTrigger>
                    <SelectContent>
                      {cityRates.map((city) => (
                        <SelectItem key={city.id} value={city.city}>
                          {city.city}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Tipo de Transporte</Label>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="ground"
                        checked={currentQuote.transportType === "ground"}
                        onCheckedChange={() => setCurrentQuote({ ...currentQuote, transportType: "ground" })}
                      />
                      <label
                        htmlFor="ground"
                        className="flex cursor-pointer items-center gap-1.5 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        <Truck className="h-4 w-4" />
                        Terrestre
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="air"
                        checked={currentQuote.transportType === "air"}
                        onCheckedChange={() => setCurrentQuote({ ...currentQuote, transportType: "air" })}
                      />
                      <label
                        htmlFor="air"
                        className="flex cursor-pointer items-center gap-1.5 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        <Plane className="h-4 w-4" />
                        Aéreo
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actualizar la interfaz para incluir la opción de toma de puntos */}
              <div className="space-y-4">
                <div className="flex items-end gap-2">
                  <div className="flex-1 space-y-2">
                    <Label htmlFor="product">Producto</Label>
                    <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                      <SelectTrigger id="product">
                        <SelectValue placeholder="Seleccionar producto" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name} - ${product.price.toLocaleString("es-CL")}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="w-24 space-y-2">
                    <Label htmlFor="quantity">Cantidad</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      value={productQuantity}
                      onChange={(e) => setProductQuantity(Number.parseInt(e.target.value) || 1)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="surveyRate">Toma de Puntos</Label>
                    <Select
                      value={selectedSurveyRate || "none"}
                      onValueChange={(value) => {
                        if (value === "none") {
                          setSelectedSurveyRate(null)
                          setIncludeSurvey(false)
                        } else {
                          setSelectedSurveyRate(value)
                          setIncludeSurvey(true)
                        }
                      }}
                    >
                      <SelectTrigger id="surveyRate" className="w-full">
                        <SelectValue placeholder="Seleccionar tarifa" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Sin toma de puntos</SelectItem>
                        {serviceRates.map((rate) => (
                          <SelectItem key={rate.id} value={rate.id.toString()}>
                            {rate.name} (+${(rate.priceWithSurvey - rate.priceWithoutSurvey).toLocaleString("es-CL")})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleAddQuoteItem} disabled={!selectedProduct} className="mb-0.5">
                    <Plus className="mr-2 h-4 w-4" />
                    Agregar
                  </Button>
                </div>

                {/* Actualizar la tabla para mostrar si incluye toma de puntos */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Producto</TableHead>
                        <TableHead className="text-center">Precio Unitario</TableHead>
                        <TableHead className="text-center">Cantidad</TableHead>
                        <TableHead className="text-center">Toma de Puntos</TableHead>
                        <TableHead className="text-right">Subtotal</TableHead>
                        <TableHead className="w-[50px]"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {quoteItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="h-24 text-center">
                            No hay productos en la cotización.
                          </TableCell>
                        </TableRow>
                      ) : (
                        quoteItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{item.product.name}</TableCell>
                            <TableCell className="text-center">${item.product.price.toLocaleString("es-CL")}</TableCell>
                            <TableCell className="text-center">{item.quantity}</TableCell>

                            <TableCell className="text-center">
                              {item.includeSurvey ? (
                                <Badge
                                  variant="outline"
                                  className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                >
                                  {item.surveyRateName || "Incluida"}
                                  {item.surveyRatePrice > 0 && ` (+$${item.surveyRatePrice.toLocaleString("es-CL")})`}
                                </Badge>
                              ) : (
                                <Badge
                                  variant="outline"
                                  className="bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
                                >
                                  No incluida
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">${item.subtotal.toLocaleString("es-CL")}</TableCell>
                            <TableCell>
                              <Button variant="ghost" size="icon" onClick={() => handleRemoveQuoteItem(item.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                      {/* Actualizar la visualización del total para mostrar el costo de toma de puntos */}
                      <TableRow>
                        <TableCell colSpan={4} className="text-right font-medium">
                          Costo de Transporte ({currentQuote.city} -{" "}
                          {currentQuote.transportType === "ground" ? "Terrestre" : "Aéreo"})
                        </TableCell>
                        <TableCell className="text-right">${getTransportCost().toLocaleString("es-CL")}</TableCell>
                        <TableCell></TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell colSpan={4} className="text-right font-medium">
                          Costo adicional por Toma de Puntos
                        </TableCell>
                        <TableCell className="text-right">
                          $
                          {quoteItems
                            .reduce((sum, item) => {
                              if (item.includeSurvey) {
                                if (item.surveyRatePrice) {
                                  // Si tiene un precio específico de tarifa, usarlo
                                  return sum + item.surveyRatePrice * item.quantity
                                } else {
                                  // Si no tiene tarifa específica, usar el 15% por defecto
                                  return sum + item.subtotal * 0.15
                                }
                              }
                              return sum
                            }, 0)
                            .toLocaleString("es-CL")}
                        </TableCell>
                        <TableCell></TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell colSpan={4} className="text-right font-bold">
                          Total
                        </TableCell>
                        <TableCell className="text-right font-bold">
                          ${calculateQuoteTotal().toLocaleString("es-CL")}
                        </TableCell>
                        <TableCell></TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setCurrentQuote({
                        client: "",
                        date: new Date().toISOString().split("T")[0],
                        city: "",
                        transportType: "ground",
                      })
                      setQuoteItems([])
                    }}
                  >
                    Limpiar
                  </Button>
                  <Button onClick={exportQuote} disabled={quoteItems.length === 0}>
                    <Download className="mr-2 h-4 w-4" />
                    Exportar
                  </Button>
                  <Button onClick={handleSaveQuote} disabled={quoteItems.length === 0}>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar Cotización
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cotizaciones Recientes</CardTitle>
              <CardDescription>Historial de cotizaciones realizadas.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Ciudad</TableHead>
                      <TableHead>Transporte</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="w-[100px]">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 3 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-20 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-16 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : quotes.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="h-24 text-center">
                          No hay cotizaciones registradas.
                        </TableCell>
                      </TableRow>
                    ) : (
                      quotes.map((quote) => (
                        <TableRow key={quote.id}>
                          <TableCell className="font-medium">{quote.client}</TableCell>
                          <TableCell>{formatDate(quote.date)}</TableCell>
                          <TableCell>{quote.city}</TableCell>
                          <TableCell>
                            {quote.transportType === "ground" ? (
                              <span className="flex items-center gap-1">
                                <Truck className="h-4 w-4" />
                                Terrestre
                              </span>
                            ) : (
                              <span className="flex items-center gap-1">
                                <Plane className="h-4 w-4" />
                                Aéreo
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">${quote.total.toLocaleString("es-CL")}</TableCell>
                          <TableCell>
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon">
                                <Download className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Productos Tab */}
        <TabsContent value="productos" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Productos y Precios</CardTitle>
                <CardDescription>Gestione los productos disponibles para cotización.</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Agregar Producto
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Agregar Nuevo Producto</DialogTitle>
                    <DialogDescription>Complete los detalles del nuevo producto.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="product-name" className="text-right">
                        Nombre
                      </Label>
                      <Input
                        id="product-name"
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="product-cost" className="text-right">
                        Costo (CLP)
                      </Label>
                      <Input
                        id="product-cost"
                        type="number"
                        value={newProduct.cost}
                        onChange={(e) => setNewProduct({ ...newProduct, cost: Number.parseInt(e.target.value) || 0 })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="product-margin" className="text-right">
                        Margen (%)
                      </Label>
                      <Input
                        id="product-margin"
                        type="number"
                        value={newProduct.margin}
                        onChange={(e) => setNewProduct({ ...newProduct, margin: Number.parseInt(e.target.value) || 0 })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">Precio Final</Label>
                      <div className="col-span-3 rounded-md border border-input bg-muted px-3 py-2">
                        ${calculateProductPrice(newProduct.cost, newProduct.margin).toLocaleString("es-CL")}
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancelar</Button>
                    <Button onClick={handleAddProduct} disabled={!newProduct.name || newProduct.cost <= 0}>
                      Guardar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead className="text-right">Costo (CLP)</TableHead>
                      <TableHead className="text-center">Margen (%)</TableHead>
                      <TableHead className="text-right">Precio Final (CLP)</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="mx-auto h-4 w-12 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : products.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          No hay productos registrados.
                        </TableCell>
                      </TableRow>
                    ) : (
                      products.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell className="font-medium">{product.name}</TableCell>
                          <TableCell className="text-right">${product.cost.toLocaleString("es-CL")}</TableCell>
                          <TableCell className="text-center">{product.margin}%</TableCell>
                          <TableCell className="text-right">${product.price.toLocaleString("es-CL")}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="ghost" size="icon" onClick={() => setEditingProduct(product)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Editar Producto</DialogTitle>
                                    <DialogDescription>Modifique los detalles del producto.</DialogDescription>
                                  </DialogHeader>
                                  {editingProduct && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-product-name" className="text-right">
                                          Nombre
                                        </Label>
                                        <Input
                                          id="edit-product-name"
                                          value={editingProduct.name}
                                          onChange={(e) =>
                                            setEditingProduct({ ...editingProduct, name: e.target.value })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-product-cost" className="text-right">
                                          Costo (CLP)
                                        </Label>
                                        <Input
                                          id="edit-product-cost"
                                          type="number"
                                          value={editingProduct.cost}
                                          onChange={(e) =>
                                            setEditingProduct({
                                              ...editingProduct,
                                              cost: Number.parseInt(e.target.value) || 0,
                                            })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-product-margin" className="text-right">
                                          Margen (%)
                                        </Label>
                                        <Input
                                          id="edit-product-margin"
                                          type="number"
                                          value={editingProduct.margin}
                                          onChange={(e) =>
                                            setEditingProduct({
                                              ...editingProduct,
                                              margin: Number.parseInt(e.target.value) || 0,
                                            })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label className="text-right">Precio Final</Label>
                                        <div className="col-span-3 rounded-md border border-input bg-muted px-3 py-2">
                                          $
                                          {calculateProductPrice(
                                            editingProduct.cost,
                                            editingProduct.margin,
                                          ).toLocaleString("es-CL")}
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setEditingProduct(null)}>
                                      Cancelar
                                    </Button>
                                    <Button
                                      onClick={handleUpdateProduct}
                                      disabled={!editingProduct || !editingProduct.name || editingProduct.cost <= 0}
                                    >
                                      Guardar
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteProduct(product.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tarifas Tab */}
        <TabsContent value="tarifas" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Tarifas de Transporte</CardTitle>
                <CardDescription>Gestione las tarifas de transporte por ciudad.</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Agregar Tarifa
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Agregar Nueva Tarifa</DialogTitle>
                    <DialogDescription>Complete los detalles de la nueva tarifa de transporte.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="city-name" className="text-right">
                        Ciudad
                      </Label>
                      <Input
                        id="city-name"
                        value={newCityRate.city}
                        onChange={(e) => setNewCityRate({ ...newCityRate, city: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="ground-rate" className="text-right">
                        Tarifa Terrestre
                      </Label>
                      <div className="col-span-3 flex items-center gap-2">
                        <Truck className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="ground-rate"
                          type="number"
                          value={newCityRate.groundRate}
                          onChange={(e) =>
                            setNewCityRate({ ...newCityRate, groundRate: Number.parseInt(e.target.value) || 0 })
                          }
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="air-rate" className="text-right">
                        Tarifa Aérea
                      </Label>
                      <div className="col-span-3 flex items-center gap-2">
                        <Plane className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="air-rate"
                          type="number"
                          value={newCityRate.airRate}
                          onChange={(e) =>
                            setNewCityRate({ ...newCityRate, airRate: Number.parseInt(e.target.value) || 0 })
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancelar</Button>
                    <Button onClick={handleAddCityRate} disabled={!newCityRate.city}>
                      Guardar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ciudad</TableHead>
                      <TableHead className="text-right">Tarifa Terrestre (CLP)</TableHead>
                      <TableHead className="text-right">Tarifa Aérea (CLP)</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : cityRates.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="h-24 text-center">
                          No hay tarifas registradas.
                        </TableCell>
                      </TableRow>
                    ) : (
                      cityRates.map((cityRate) => (
                        <TableRow key={cityRate.id}>
                          <TableCell className="font-medium">{cityRate.city}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Truck className="h-4 w-4 text-muted-foreground" />$
                              {cityRate.groundRate.toLocaleString("es-CL")}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Plane className="h-4 w-4 text-muted-foreground" />$
                              {cityRate.airRate.toLocaleString("es-CL")}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="ghost" size="icon" onClick={() => setEditingCityRate(cityRate)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Editar Tarifa</DialogTitle>
                                    <DialogDescription>
                                      Modifique los detalles de la tarifa de transporte.
                                    </DialogDescription>
                                  </DialogHeader>
                                  {editingCityRate && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-city-name" className="text-right">
                                          Ciudad
                                        </Label>
                                        <Input
                                          id="edit-city-name"
                                          value={editingCityRate.city}
                                          onChange={(e) =>
                                            setEditingCityRate({ ...editingCityRate, city: e.target.value })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-ground-rate" className="text-right">
                                          Tarifa Terrestre
                                        </Label>
                                        <div className="col-span-3 flex items-center gap-2">
                                          <Truck className="h-4 w-4 text-muted-foreground" />
                                          <Input
                                            id="edit-ground-rate"
                                            type="number"
                                            value={editingCityRate.groundRate}
                                            onChange={(e) =>
                                              setEditingCityRate({
                                                ...editingCityRate,
                                                groundRate: Number.parseInt(e.target.value) || 0,
                                              })
                                            }
                                          />
                                        </div>
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-air-rate" className="text-right">
                                          Tarifa Aérea
                                        </Label>
                                        <div className="col-span-3 flex items-center gap-2">
                                          <Plane className="h-4 w-4 text-muted-foreground" />
                                          <Input
                                            id="edit-air-rate"
                                            type="number"
                                            value={editingCityRate.airRate}
                                            onChange={(e) =>
                                              setEditingCityRate({
                                                ...editingCityRate,
                                                airRate: Number.parseInt(e.target.value) || 0,
                                              })
                                            }
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setEditingCityRate(null)}>
                                      Cancelar
                                    </Button>
                                    <Button
                                      onClick={handleUpdateCityRate}
                                      disabled={!editingCityRate || !editingCityRate.city}
                                    >
                                      Guardar
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteCityRate(cityRate.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tarifas de Toma de Puntos Tab */}
        <TabsContent value="tarifasPuntos" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Tarifas de Toma de Puntos</CardTitle>
                <CardDescription>Gestione las tarifas para servicios con o sin toma de puntos.</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Agregar Tarifa
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Agregar Nueva Tarifa</DialogTitle>
                    <DialogDescription>Complete los detalles de la nueva tarifa de servicio.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="service-name" className="text-right">
                        Nombre
                      </Label>
                      <Input
                        id="service-name"
                        value={newServiceRate.name}
                        onChange={(e) => setNewServiceRate({ ...newServiceRate, name: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="service-description" className="text-right">
                        Descripción
                      </Label>
                      <Input
                        id="service-description"
                        value={newServiceRate.description}
                        onChange={(e) => setNewServiceRate({ ...newServiceRate, description: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="service-category" className="text-right">
                        Categoría
                      </Label>
                      <Select
                        value={newServiceRate.category}
                        onChange={(value) =>
                          setNewServiceRate({
                            ...newServiceRate,
                            category: value as "instalacion" | "mantenimiento" | "reparacion" | "consultoria",
                          })
                        }
                      >
                        <SelectTrigger id="service-category" className="col-span-3">
                          <SelectValue placeholder="Seleccionar categoría" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="instalacion">Instalación</SelectItem>
                          <SelectItem value="mantenimiento">Mantenimiento</SelectItem>
                          <SelectItem value="reparacion">Reparación</SelectItem>
                          <SelectItem value="consultoria">Consultoría</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="price-with-survey" className="text-right">
                        Precio con Toma de Puntos
                      </Label>
                      <Input
                        id="price-with-survey"
                        type="number"
                        value={newServiceRate.priceWithSurvey}
                        onChange={(e) =>
                          setNewServiceRate({
                            ...newServiceRate,
                            priceWithSurvey: Number.parseInt(e.target.value) || 0,
                          })
                        }
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="price-without-survey" className="text-right">
                        Precio sin Toma de Puntos
                      </Label>
                      <Input
                        id="price-without-survey"
                        type="number"
                        value={newServiceRate.priceWithoutSurvey}
                        onChange={(e) =>
                          setNewServiceRate({
                            ...newServiceRate,
                            priceWithoutSurvey: Number.parseInt(e.target.value) || 0,
                          })
                        }
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddServiceRateOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleAddServiceRate} disabled={!newServiceRate.name}>
                      Guardar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Categoría</TableHead>
                      <TableHead className="text-right">Con Toma de Puntos</TableHead>
                      <TableHead className="text-right">Sin Toma de Puntos</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell>
                            <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="ml-auto h-4 w-24 animate-pulse rounded bg-muted"></div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                              <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : serviceRates.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          No hay tarifas registradas.
                        </TableCell>
                      </TableRow>
                    ) : (
                      serviceRates.map((rate) => (
                        <TableRow key={rate.id}>
                          <TableCell className="font-medium">
                            <div>
                              <div>{rate.name}</div>
                              <div className="text-xs text-muted-foreground">{rate.description}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getCategoryColor(rate.category)}`}>
                              {getCategoryLabel(rate.category)}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">${rate.priceWithSurvey.toLocaleString("es-CL")}</TableCell>
                          <TableCell className="text-right">
                            ${rate.priceWithoutSurvey.toLocaleString("es-CL")}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="ghost" size="icon" onClick={() => setEditingServiceRate(rate)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Editar Tarifa</DialogTitle>
                                    <DialogDescription>
                                      Modifique los detalles de la tarifa de servicio.
                                    </DialogDescription>
                                  </DialogHeader>
                                  {editingServiceRate && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-service-name" className="text-right">
                                          Nombre
                                        </Label>
                                        <Input
                                          id="edit-service-name"
                                          value={editingServiceRate.name}
                                          onChange={(e) =>
                                            setEditingServiceRate({ ...editingServiceRate, name: e.target.value })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-service-description" className="text-right">
                                          Descripción
                                        </Label>
                                        <Input
                                          id="edit-service-description"
                                          value={editingServiceRate.description}
                                          onChange={(e) =>
                                            setEditingServiceRate({
                                              ...editingServiceRate,
                                              description: e.target.value,
                                            })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-service-category" className="text-right">
                                          Categoría
                                        </Label>
                                        <Select
                                          value={editingServiceRate.category}
                                          onChange={(value) =>
                                            setEditingServiceRate({
                                              ...editingServiceRate,
                                              category: value as
                                                | "instalacion"
                                                | "mantenimiento"
                                                | "reparacion"
                                                | "consultoria",
                                            })
                                          }
                                        >
                                          <SelectTrigger id="edit-service-category" className="col-span-3">
                                            <SelectValue placeholder="Seleccionar categoría" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="instalacion">Instalación</SelectItem>
                                            <SelectItem value="mantenimiento">Mantenimiento</SelectItem>
                                            <SelectItem value="reparacion">Reparación</SelectItem>
                                            <SelectItem value="consultoria">Consultoría</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-price-with-survey" className="text-right">
                                          Precio con Toma de Puntos
                                        </Label>
                                        <Input
                                          id="edit-price-with-survey"
                                          type="number"
                                          value={editingServiceRate.priceWithSurvey}
                                          onChange={(e) =>
                                            setEditingServiceRate({
                                              ...editingServiceRate,
                                              priceWithSurvey: Number.parseInt(e.target.value) || 0,
                                            })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-price-without-survey" className="text-right">
                                          Precio sin Toma de Puntos
                                        </Label>
                                        <Input
                                          id="edit-price-without-survey"
                                          type="number"
                                          value={editingServiceRate.priceWithoutSurvey}
                                          onChange={(e) =>
                                            setEditingServiceRate({
                                              ...editingServiceRate,
                                              priceWithoutSurvey: Number.parseInt(e.target.value) || 0,
                                            })
                                          }
                                          className="col-span-3"
                                        />
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setEditingServiceRate(null)}>
                                      Cancelar
                                    </Button>
                                    <Button
                                      onClick={handleUpdateServiceRate}
                                      disabled={!editingServiceRate || !editingServiceRate.name}
                                    >
                                      Guardar
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteServiceRate(rate.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function formatDate(dateString: string) {
  const date = new Date(dateString)
  return date.toLocaleDateString("es-CL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })
}
