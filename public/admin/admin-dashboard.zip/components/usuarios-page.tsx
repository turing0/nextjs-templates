"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Download, Edit, Filter, Plus, RefreshCw, Search, Trash2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"

interface User {
  id: number
  name: string
  email: string
  role: "admin" | "tecnico" | "vendedor" | "visualizador"
  active: boolean
  lastLogin: string | null
}

export function UsuariosPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState("all")
  const [newUser, setNewUser] = useState<Omit<User, "id" | "lastLogin">>({
    name: "",
    email: "",
    role: "visualizador",
    active: true,
  })
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      const mockUsers: User[] = [
        {
          id: 1,
          name: "Admin Usuario",
          email: "admin@empresa.cl",
          role: "admin",
          active: true,
          lastLogin: "2025-04-14T09:30:00",
        },
        {
          id: 2,
          name: "Juan Pérez",
          email: "juan.perez@empresa.cl",
          role: "tecnico",
          active: true,
          lastLogin: "2025-04-13T14:45:00",
        },
        {
          id: 3,
          name: "María González",
          email: "maria.gonzalez@empresa.cl",
          role: "vendedor",
          active: true,
          lastLogin: "2025-04-14T08:15:00",
        },
        {
          id: 4,
          name: "Carlos Rodríguez",
          email: "carlos.rodriguez@empresa.cl",
          role: "tecnico",
          active: true,
          lastLogin: "2025-04-12T11:20:00",
        },
        {
          id: 5,
          name: "Ana Martínez",
          email: "ana.martinez@empresa.cl",
          role: "visualizador",
          active: false,
          lastLogin: "2025-04-10T15:30:00",
        },
      ]
      setUsers(mockUsers)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleAddUser = () => {
    const id = Math.max(0, ...users.map((u) => u.id)) + 1

    const newUserComplete: User = {
      ...newUser,
      id,
      lastLogin: null,
    }

    setUsers([...users, newUserComplete])
    setNewUser({
      name: "",
      email: "",
      role: "visualizador",
      active: true,
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Usuario creado",
      description: `Se ha creado el usuario "${newUser.name}" correctamente.`,
    })
  }

  const handleUpdateUser = () => {
    if (!editingUser) return

    setUsers(users.map((user) => (user.id === editingUser.id ? editingUser : user)))
    setEditingUser(null)

    toast({
      title: "Usuario actualizado",
      description: `Se ha actualizado el usuario "${editingUser.name}" correctamente.`,
    })
  }

  const handleDeleteUser = (id: number) => {
    const userToDelete = users.find((u) => u.id === id)
    setUsers(users.filter((u) => u.id !== id))

    toast({
      title: "Usuario eliminado",
      description: `Se ha eliminado el usuario "${userToDelete?.name}" correctamente.`,
      variant: "destructive",
    })
  }

  const handleToggleUserStatus = (id: number) => {
    setUsers(
      users.map((user) => {
        if (user.id === id) {
          const updatedUser = { ...user, active: !user.active }
          toast({
            title: updatedUser.active ? "Usuario activado" : "Usuario desactivado",
            description: `Se ha ${updatedUser.active ? "activado" : "desactivado"} el usuario "${
              updatedUser.name
            }" correctamente.`,
          })
          return updatedUser
        }
        return user
      }),
    )
  }

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = roleFilter === "all" || user.role === roleFilter

    return matchesSearch && matchesRole
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando usuarios",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Usuarios actualizados",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos de usuarios se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  const getRoleLabel = (role: User["role"]) => {
    switch (role) {
      case "admin":
        return "Administrador"
      case "tecnico":
        return "Técnico"
      case "vendedor":
        return "Vendedor"
      case "visualizador":
        return "Visualizador"
      default:
        return role
    }
  }

  const getRoleBadgeColor = (role: User["role"]) => {
    switch (role) {
      case "admin":
        return "bg-purple-500"
      case "tecnico":
        return "bg-blue-500"
      case "vendedor":
        return "bg-green-500"
      case "visualizador":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatDateTime = (dateTimeString: string | null) => {
    if (!dateTimeString) return "Nunca"
    const date = new Date(dateTimeString)
    return date.toLocaleString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Gestión de Usuarios</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Crear Usuario
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Crear Nuevo Usuario</DialogTitle>
                <DialogDescription>Complete los detalles del nuevo usuario.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="name" className="text-right">
                    Nombre
                  </label>
                  <Input
                    id="name"
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="email" className="text-right">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="role" className="text-right">
                    Rol
                  </label>
                  <Select
                    value={newUser.role}
                    onValueChange={(value: User["role"]) => setNewUser({ ...newUser, role: value })}
                  >
                    <SelectTrigger id="role" className="col-span-3">
                      <SelectValue placeholder="Seleccionar rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Administrador</SelectItem>
                      <SelectItem value="tecnico">Técnico</SelectItem>
                      <SelectItem value="vendedor">Vendedor</SelectItem>
                      <SelectItem value="visualizador">Visualizador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="active" className="text-right">
                    Activo
                  </label>
                  <div className="col-span-3 flex items-center space-x-2">
                    <Switch
                      id="active"
                      checked={newUser.active}
                      onCheckedChange={(checked) => setNewUser({ ...newUser, active: checked })}
                    />
                    <Label htmlFor="active">{newUser.active ? "Activo" : "Inactivo"}</Label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddUser} disabled={!newUser.name || !newUser.email}>
                  Crear Usuario
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Usuarios del Sistema</CardTitle>
          <CardDescription>Gestione los usuarios y sus roles en el sistema.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-col gap-4 md:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre o email..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Rol
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Filtrar por rol</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setRoleFilter("all")}>Todos</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setRoleFilter("admin")}>Administrador</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setRoleFilter("tecnico")}>Técnico</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setRoleFilter("vendedor")}>Vendedor</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setRoleFilter("visualizador")}>Visualizador</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">Avatar</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Último Acceso</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="h-10 w-10 animate-pulse rounded-full bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-6 w-24 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-6 w-16 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                          <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                          <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No se encontraron usuarios.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <Avatar>
                          <AvatarImage src={`/placeholder-user.jpg`} alt={user.name} />
                          <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(user.role)}>{getRoleLabel(user.role)}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={user.active ? "default" : "outline"}
                          className={user.active ? "bg-green-500" : ""}
                        >
                          {user.active ? "Activo" : "Inactivo"}
                        </Badge>
                      </TableCell>
                      <TableCell>{formatDateTime(user.lastLogin)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" onClick={() => setEditingUser(user)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Editar Usuario</DialogTitle>
                                <DialogDescription>Modifique los detalles del usuario.</DialogDescription>
                              </DialogHeader>
                              {editingUser && (
                                <div className="grid gap-4 py-4">
                                  <div className="grid grid-cols-4 items-center gap-4">
                                    <label htmlFor="edit-name" className="text-right">
                                      Nombre
                                    </label>
                                    <Input
                                      id="edit-name"
                                      value={editingUser.name}
                                      onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                                      className="col-span-3"
                                    />
                                  </div>
                                  <div className="grid grid-cols-4 items-center gap-4">
                                    <label htmlFor="edit-email" className="text-right">
                                      Email
                                    </label>
                                    <Input
                                      id="edit-email"
                                      type="email"
                                      value={editingUser.email}
                                      onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                                      className="col-span-3"
                                    />
                                  </div>
                                  <div className="grid grid-cols-4 items-center gap-4">
                                    <label htmlFor="edit-role" className="text-right">
                                      Rol
                                    </label>
                                    <Select
                                      value={editingUser.role}
                                      onValueChange={(value: User["role"]) =>
                                        setEditingUser({ ...editingUser, role: value })
                                      }
                                    >
                                      <SelectTrigger id="edit-role" className="col-span-3">
                                        <SelectValue placeholder="Seleccionar rol" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="admin">Administrador</SelectItem>
                                        <SelectItem value="tecnico">Técnico</SelectItem>
                                        <SelectItem value="vendedor">Vendedor</SelectItem>
                                        <SelectItem value="visualizador">Visualizador</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div className="grid grid-cols-4 items-center gap-4">
                                    <label htmlFor="edit-active" className="text-right">
                                      Activo
                                    </label>
                                    <div className="col-span-3 flex items-center space-x-2">
                                      <Switch
                                        id="edit-active"
                                        checked={editingUser.active}
                                        onCheckedChange={(checked) =>
                                          setEditingUser({ ...editingUser, active: checked })
                                        }
                                      />
                                      <Label htmlFor="edit-active">{editingUser.active ? "Activo" : "Inactivo"}</Label>
                                    </div>
                                  </div>
                                </div>
                              )}
                              <DialogFooter>
                                <Button variant="outline" onClick={() => setEditingUser(null)}>
                                  Cancelar
                                </Button>
                                <Button
                                  onClick={handleUpdateUser}
                                  disabled={!editingUser || !editingUser.name || !editingUser.email}
                                >
                                  Guardar Cambios
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleToggleUserStatus(user.id)}
                            disabled={user.role === "admin" && user.id === 1}
                          >
                            <PowerIcon className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteUser(user.id)}
                            disabled={user.role === "admin" && user.id === 1}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function PowerIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 2v10" />
      <path d="M18.4 6.6a9 9 0 1 1-12.77.04" />
    </svg>
  )
}
