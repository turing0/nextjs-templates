"use client"

import type React from "react"

import { useState } from "react"
import { Calendar, Clock, Download, Plus, RefreshCw, Search, Trash2, User } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useAppContext, type MaintenanceEvent } from "@/contexts/app-context"

export function CalendarioPage() {
  const { maintenanceEvents, setMaintenanceEvents, users } = useAppContext()
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("mensual")
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newEvent, setNewEvent] = useState<Omit<MaintenanceEvent, "id">>({
    title: "",
    description: "",
    client: "",
    date: new Date().toISOString(),
    endDate: new Date().toISOString(),
    type: "preventivo",
    assignedTo: "",
    status: "pendiente",
    notes: "",
  })
  const { toast } = useToast()

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.client || !newEvent.assignedTo) {
      toast({
        title: "Error al crear evento",
        description: "Por favor complete todos los campos obligatorios.",
        variant: "destructive",
      })
      return
    }

    const id = Math.max(0, ...maintenanceEvents.map((e) => e.id)) + 1

    const newEventComplete: MaintenanceEvent = {
      ...newEvent,
      id,
    }

    setMaintenanceEvents([...maintenanceEvents, newEventComplete])
    setNewEvent({
      title: "",
      description: "",
      client: "",
      date: new Date().toISOString(),
      endDate: new Date().toISOString(),
      type: "preventivo",
      assignedTo: "",
      status: "pendiente",
      notes: "",
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Evento creado",
      description: `Se ha creado el evento "${newEvent.title}" correctamente.`,
    })
  }

  const handleDeleteEvent = (id: number) => {
    const eventToDelete = maintenanceEvents.find((e) => e.id === id)
    setMaintenanceEvents(maintenanceEvents.filter((e) => e.id !== id))

    toast({
      title: "Evento eliminado",
      description: `Se ha eliminado el evento "${eventToDelete?.title}" correctamente.`,
      variant: "destructive",
    })
  }

  const handleUpdateEventStatus = (id: number, status: MaintenanceEvent["status"]) => {
    setMaintenanceEvents(
      maintenanceEvents.map((event) => {
        if (event.id === id) {
          return {
            ...event,
            status,
          }
        }
        return event
      }),
    )

    toast({
      title: "Estado actualizado",
      description: `El estado del evento ha sido actualizado a "${getStatusLabel(status)}".`,
    })
  }

  const filteredEvents = maintenanceEvents.filter((event) => {
    const matchesSearch =
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.client.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || event.status === statusFilter

    // Filtrar por mes si estamos en vista mensual
    const eventDate = new Date(event.date)
    const matchesMonth =
      activeTab !== "mensual" ||
      (eventDate.getMonth() === selectedDate.getMonth() && eventDate.getFullYear() === selectedDate.getFullYear())

    // Filtrar por semana si estamos en vista semanal
    const startOfWeek = new Date(selectedDate)
    startOfWeek.setDate(selectedDate.getDate() - selectedDate.getDay())
    const endOfWeek = new Date(startOfWeek)
    endOfWeek.setDate(startOfWeek.getDate() + 6)

    const matchesWeek = activeTab !== "semanal" || (eventDate >= startOfWeek && eventDate <= endOfWeek)

    return matchesSearch && matchesStatus && (matchesMonth || matchesWeek)
  })

  const refreshData = () => {
    setLoading(true)
    toast({
      title: "Actualizando calendario",
      description: "Los datos se están actualizando...",
    })

    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Calendario actualizado",
        description: "Los datos han sido actualizados correctamente.",
      })
    }, 1000)
  }

  const exportData = () => {
    toast({
      title: "Exportando datos",
      description: "Los datos del calendario se están exportando a CSV...",
    })

    setTimeout(() => {
      toast({
        title: "Datos exportados",
        description: "El archivo CSV ha sido generado correctamente.",
      })
    }, 1000)
  }

  const getTypeLabel = (type: MaintenanceEvent["type"]) => {
    switch (type) {
      case "preventivo":
        return "Preventivo"
      case "correctivo":
        return "Correctivo"
      case "instalacion":
        return "Instalación"
      default:
        return type
    }
  }

  const getStatusLabel = (status: MaintenanceEvent["status"]) => {
    switch (status) {
      case "pendiente":
        return "Pendiente"
      case "completado":
        return "Completado"
      case "cancelado":
        return "Cancelado"
      default:
        return status
    }
  }

  const getStatusColor = (status: MaintenanceEvent["status"]) => {
    switch (status) {
      case "pendiente":
        return "bg-amber-500"
      case "completado":
        return "bg-green-500"
      case "cancelado":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Generar días del mes para la vista mensual
  const getDaysInMonth = (year: number, month: number) => {
    const date = new Date(year, month, 1)
    const days = []

    // Obtener el primer día del mes
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1)
    const startingDay = firstDay.getDay() // 0 = Domingo, 1 = Lunes, etc.

    // Añadir días del mes anterior para completar la primera semana
    for (let i = 0; i < startingDay; i++) {
      const prevDate = new Date(date.getFullYear(), date.getMonth(), -i)
      days.unshift({
        date: prevDate,
        isCurrentMonth: false,
        events: maintenanceEvents.filter((e) => {
          const eventDate = new Date(e.date)
          return (
            eventDate.getDate() === prevDate.getDate() &&
            eventDate.getMonth() === prevDate.getMonth() &&
            eventDate.getFullYear() === prevDate.getFullYear()
          )
        }),
      })
    }

    // Añadir días del mes actual
    const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()
    for (let i = 1; i <= daysInMonth; i++) {
      const currentDate = new Date(date.getFullYear(), date.getMonth(), i)
      days.push({
        date: currentDate,
        isCurrentMonth: true,
        events: maintenanceEvents.filter((e) => {
          const eventDate = new Date(e.date)
          return (
            eventDate.getDate() === currentDate.getDate() &&
            eventDate.getMonth() === currentDate.getMonth() &&
            eventDate.getFullYear() === currentDate.getFullYear()
          )
        }),
      })
    }

    // Añadir días del mes siguiente para completar la última semana
    const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0)
    const endingDay = lastDay.getDay() // 0 = Domingo, 1 = Lunes, etc.

    for (let i = 1; i < 7 - endingDay; i++) {
      const nextDate = new Date(date.getFullYear(), date.getMonth() + 1, i)
      days.push({
        date: nextDate,
        isCurrentMonth: false,
        events: maintenanceEvents.filter((e) => {
          const eventDate = new Date(e.date)
          return (
            eventDate.getDate() === nextDate.getDate() &&
            eventDate.getMonth() === nextDate.getMonth() &&
            eventDate.getFullYear() === nextDate.getFullYear()
          )
        }),
      })
    }

    return days
  }

  const days = getDaysInMonth(selectedDate.getFullYear(), selectedDate.getMonth())

  // Generar días de la semana para la vista semanal
  const getDaysInWeek = () => {
    const startOfWeek = new Date(selectedDate)
    startOfWeek.setDate(selectedDate.getDate() - selectedDate.getDay())

    const days = []

    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(startOfWeek)
      currentDate.setDate(startOfWeek.getDate() + i)

      days.push({
        date: currentDate,
        events: maintenanceEvents.filter((e) => {
          const eventDate = new Date(e.date)
          return (
            eventDate.getDate() === currentDate.getDate() &&
            eventDate.getMonth() === currentDate.getMonth() &&
            eventDate.getFullYear() === currentDate.getFullYear()
          )
        }),
      })
    }

    return days
  }

  const weekDays = getDaysInWeek()

  const changeMonth = (increment: number) => {
    const newDate = new Date(selectedDate)
    newDate.setMonth(newDate.getMonth() + increment)
    setSelectedDate(newDate)
  }

  const changeWeek = (increment: number) => {
    const newDate = new Date(selectedDate)
    newDate.setDate(newDate.getDate() + increment * 7)
    setSelectedDate(newDate)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <h2 className="text-3xl font-bold tracking-tight">Calendario de Mantenimiento</h2>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={refreshData} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Actualizando...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar
              </>
            )}
          </Button>
          <Button onClick={exportData} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nuevo Evento
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crear Nuevo Evento</DialogTitle>
                <DialogDescription>Complete los detalles del nuevo evento de mantenimiento.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="title" className="text-right">
                    Título
                  </label>
                  <Input
                    id="title"
                    value={newEvent.title}
                    onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <label htmlFor="description" className="text-right pt-2">
                    Descripción
                  </label>
                  <Textarea
                    id="description"
                    value={newEvent.description}
                    onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="client" className="text-right">
                    Cliente
                  </label>
                  <Input
                    id="client"
                    value={newEvent.client}
                    onChange={(e) => setNewEvent({ ...newEvent, client: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="date" className="text-right">
                    Fecha y hora
                  </label>
                  <Input
                    id="date"
                    type="datetime-local"
                    value={newEvent.date.slice(0, 16)}
                    onChange={(e) => setNewEvent({ ...newEvent, date: new Date(e.target.value).toISOString() })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="endDate" className="text-right">
                    Fecha y hora fin
                  </label>
                  <Input
                    id="endDate"
                    type="datetime-local"
                    value={newEvent.endDate?.slice(0, 16) || ""}
                    onChange={(e) => setNewEvent({ ...newEvent, endDate: new Date(e.target.value).toISOString() })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="type" className="text-right">
                    Tipo
                  </label>
                  <Select
                    value={newEvent.type}
                    onValueChange={(value: MaintenanceEvent["type"]) => setNewEvent({ ...newEvent, type: value })}
                  >
                    <SelectTrigger id="type" className="col-span-3">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="preventivo">Preventivo</SelectItem>
                      <SelectItem value="correctivo">Correctivo</SelectItem>
                      <SelectItem value="instalacion">Instalación</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="assignedTo" className="text-right">
                    Asignado a
                  </label>
                  <Select
                    value={newEvent.assignedTo}
                    onValueChange={(value) => setNewEvent({ ...newEvent, assignedTo: value })}
                  >
                    <SelectTrigger id="assignedTo" className="col-span-3">
                      <SelectValue placeholder="Seleccionar responsable" />
                    </SelectTrigger>
                    <SelectContent>
                      {users
                        .filter((u) => u.role === "tecnico" || u.role === "admin")
                        .map((user) => (
                          <SelectItem key={user.id} value={user.name}>
                            {user.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="status" className="text-right">
                    Estado
                  </label>
                  <Select
                    value={newEvent.status}
                    onValueChange={(value: MaintenanceEvent["status"]) => setNewEvent({ ...newEvent, status: value })}
                  >
                    <SelectTrigger id="status" className="col-span-3">
                      <SelectValue placeholder="Seleccionar estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pendiente">Pendiente</SelectItem>
                      <SelectItem value="completado">Completado</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <label htmlFor="notes" className="text-right pt-2">
                    Notas
                  </label>
                  <Textarea
                    id="notes"
                    value={newEvent.notes}
                    onChange={(e) => setNewEvent({ ...newEvent, notes: e.target.value })}
                    className="col-span-3"
                    rows={2}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddEvent} disabled={!newEvent.title || !newEvent.client || !newEvent.assignedTo}>
                  Crear Evento
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="mensual" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="mensual">Vista Mensual</TabsTrigger>
          <TabsTrigger value="semanal">Vista Semanal</TabsTrigger>
        </TabsList>
        <TabsContent value="mensual" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Calendario Mensual</CardTitle>
                <CardDescription>
                  {selectedDate.toLocaleDateString("es-CL", { month: "long", year: "numeric" })}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => changeMonth(-1)}>
                  <ChevronLeftIcon className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => setSelectedDate(new Date())}>
                  <Calendar className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => changeMonth(1)}>
                  <ChevronRightIcon className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1">
                {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((day, index) => (
                  <div key={index} className="p-2 text-center font-medium">
                    {day}
                  </div>
                ))}
                {days.map((day, index) => (
                  <div
                    key={index}
                    className={`min-h-24 rounded-md border p-1 ${day.isCurrentMonth ? "bg-card" : "bg-muted/50"} ${
                      day.date.getDate() === new Date().getDate() &&
                      day.date.getMonth() === new Date().getMonth() &&
                      day.date.getFullYear() === new Date().getFullYear()
                        ? "border-primary"
                        : ""
                    }`}
                  >
                    <div className="flex justify-between">
                      <span className={`text-sm ${day.isCurrentMonth ? "" : "text-muted-foreground"}`}>
                        {day.date.getDate()}
                      </span>
                      {day.events.length > 0 && (
                        <Badge className="h-5 w-5 rounded-full bg-primary p-0 text-[10px]">{day.events.length}</Badge>
                      )}
                    </div>
                    <div className="mt-1 space-y-1 overflow-y-auto max-h-20">
                      {day.events.map((event) => (
                        <div
                          key={event.id}
                          className={`text-[10px] p-1 rounded-sm ${getStatusColor(event.status)} text-white truncate`}
                          title={event.title}
                        >
                          {event.title}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="semanal" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Calendario Semanal</CardTitle>
                <CardDescription>
                  Semana del {weekDays[0].date.toLocaleDateString("es-CL")} al{" "}
                  {weekDays[6].date.toLocaleDateString("es-CL")}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => changeWeek(-1)}>
                  <ChevronLeftIcon className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => setSelectedDate(new Date())}>
                  <Calendar className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => changeWeek(1)}>
                  <ChevronRightIcon className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1">
                {weekDays.map((day, index) => (
                  <div key={index} className="text-center">
                    <div className="mb-1 font-medium">{day.date.toLocaleDateString("es-CL", { weekday: "short" })}</div>
                    <div
                      className={`rounded-md border p-1 ${
                        day.date.getDate() === new Date().getDate() &&
                        day.date.getMonth() === new Date().getMonth() &&
                        day.date.getFullYear() === new Date().getFullYear()
                          ? "border-primary"
                          : ""
                      }`}
                    >
                      <div className="text-sm">{day.date.getDate()}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 space-y-2">
                {weekDays.some((day) => day.events.length > 0) ? (
                  weekDays.map((day) =>
                    day.events.map((event) => (
                      <div
                        key={event.id}
                        className="flex items-center justify-between rounded-md border p-2 hover:bg-accent"
                      >
                        <div className="flex items-center gap-2">
                          <div className={`h-2 w-2 rounded-full ${getStatusColor(event.status)}`}></div>
                          <div>
                            <div className="font-medium">{event.title}</div>
                            <div className="text-xs text-muted-foreground">
                              {day.date.toLocaleDateString("es-CL")} - {event.client}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(event.status)}>{getStatusLabel(event.status)}</Badge>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <User className="mr-1 h-3 w-3" />
                            {event.assignedTo}
                          </div>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Clock className="mr-1 h-3 w-3" />
                            {new Date(event.date).toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                      </div>
                    )),
                  )
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No hay eventos programados para esta semana
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Eventos</CardTitle>
          <CardDescription>Gestione los eventos de mantenimiento programados.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-col gap-4 md:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por título o cliente..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="pendiente">Pendiente</SelectItem>
                  <SelectItem value="completado">Completado</SelectItem>
                  <SelectItem value="cancelado">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Título</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Asignado a</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="h-4 w-40 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-32 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-20 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-4 w-24 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell>
                        <div className="h-6 w-20 animate-pulse rounded bg-muted"></div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                          <div className="h-8 w-8 animate-pulse rounded bg-muted"></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : filteredEvents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No se encontraron eventos.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredEvents.map((event) => (
                    <TableRow key={event.id}>
                      <TableCell className="font-medium">{event.title}</TableCell>
                      <TableCell>{event.client}</TableCell>
                      <TableCell>{formatDateTime(event.date)}</TableCell>
                      <TableCell>{getTypeLabel(event.type)}</TableCell>
                      <TableCell>{event.assignedTo}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(event.status)}>{getStatusLabel(event.status)}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Select
                            value={event.status}
                            onValueChange={(value: MaintenanceEvent["status"]) =>
                              handleUpdateEventStatus(event.id, value)
                            }
                          >
                            <SelectTrigger className="h-8 w-[130px]">
                              <SelectValue placeholder="Cambiar estado" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pendiente">Pendiente</SelectItem>
                              <SelectItem value="completado">Completado</SelectItem>
                              <SelectItem value="cancelado">Cancelado</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteEvent(event.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ChevronLeftIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m15 18-6-6 6-6" />
    </svg>
  )
}

function ChevronRightIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  )
}
