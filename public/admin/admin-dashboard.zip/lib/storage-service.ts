// Servicio de almacenamiento mejorado con persistencia
const STORAGE_PREFIX = "admin-system"

// Función para obtener la clave con prefijo
const getPrefixedKey = (key: string): string => `${STORAGE_PREFIX}:${key}`

export const storage = {
  getItem<T>(key: string, defaultValue: T): T {
    try {
      const prefixedKey = getPrefixedKey(key)
      const item = localStorage.getItem(prefixedKey)

      if (item === null) {
        return defaultValue
      }

      // Intentar analizar el JSON
      const parsedItem = JSON.parse(item)

      // Si es un array, procesar las fechas en cada objeto
      if (Array.isArray(parsedItem)) {
        return parsedItem.map((obj) => processDateStrings(obj)) as T
      }

      // Si es un objeto, procesar las fechas
      return processDateStrings(parsedItem)
    } catch (error) {
      console.error(`Error al obtener ${key} de localStorage:`, error)
      return defaultValue
    }
  },

  setItem<T>(key: string, value: T): void {
    try {
      const prefixedKey = getPrefixedKey(key)
      localStorage.setItem(prefixedKey, JSON.stringify(value))

      // Sincronizar con sessionStorage para persistencia adicional
      sessionStorage.setItem(prefixedKey, JSON.stringify(value))

      console.log(`Datos guardados: ${key}`)
    } catch (error) {
      console.error(`Error al guardar ${key} en localStorage:`, error)
    }
  },

  removeItem(key: string): void {
    try {
      const prefixedKey = getPrefixedKey(key)
      localStorage.removeItem(prefixedKey)
      sessionStorage.removeItem(prefixedKey)
    } catch (error) {
      console.error(`Error al eliminar ${key} de localStorage:`, error)
    }
  },

  clear(): void {
    try {
      // Solo eliminar las claves que pertenecen a nuestra aplicación
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith(`${STORAGE_PREFIX}:`)) {
          localStorage.removeItem(key)
          sessionStorage.removeItem(key)
        }
      })
    } catch (error) {
      console.error("Error al limpiar localStorage:", error)
    }
  },

  // Método para sincronizar datos desde sessionStorage si localStorage está vacío
  syncFromSession(): void {
    try {
      Object.keys(sessionStorage).forEach((key) => {
        if (key.startsWith(`${STORAGE_PREFIX}:`) && !localStorage.getItem(key)) {
          localStorage.setItem(key, sessionStorage.getItem(key) || "")
        }
      })
    } catch (error) {
      console.error("Error al sincronizar desde sessionStorage:", error)
    }
  },
}

// Función para convertir strings de fecha a objetos Date
function processDateStrings(obj: any): any {
  if (!obj || typeof obj !== "object") {
    return obj
  }

  // Procesar cada propiedad del objeto
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      const value = obj[key]

      // Si es un string que parece una fecha ISO
      if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(value)) {
        const date = new Date(value)
        // Verificar si es una fecha válida
        if (!isNaN(date.getTime())) {
          obj[key] = date
        }
      }
      // Si es un objeto o array, procesarlo recursivamente
      else if (typeof value === "object" && value !== null) {
        obj[key] = processDateStrings(value)
      }
    }
  }

  return obj
}

// Inicializar: sincronizar desde sessionStorage al cargar
if (typeof window !== "undefined") {
  storage.syncFromSession()
}
