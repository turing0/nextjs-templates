"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { storage } from "@/lib/storage-service"

// Definir tipos para los diferentes datos
export interface User {
  id: number
  name: string
  email: string
  role: "admin" | "tecnico" | "vendedor" | "visualizador"
  active: boolean
  lastLogin: string | null
  preferences: {
    theme: "light" | "dark" | "system"
    language: string
    notifications: boolean
  }
}

export interface Product {
  id: number
  name: string
  sku: string
  category: string
  stock: number
  price: number
  status: "normal" | "low" | "critical"
  location: string
}

export interface Sale {
  id: number
  orderNumber: string
  client: string
  date: string
  status: "cotizada" | "en_curso" | "enviada" | "cerrada"
  items: SaleItem[]
  total: number
  notes: string
}

export interface SaleItem {
  id: number
  productName: string
  quantity: number
  unitPrice: number
  subtotal: number
}

export interface WorkOrder {
  id: number
  orderNumber: string
  client: string
  date: string
  status: "pendiente" | "en_curso" | "completada" | "cancelada"
  type: "instalacion" | "reparacion" | "mantenimiento"
  assignedTo: string
  description: string
  items: WorkOrderItem[]
  total: number
  notes: string[]
}

export interface WorkOrderItem {
  id: number
  description: string
  quantity: number
  unitPrice: number
  subtotal: number
}

export interface Ticket {
  id: number
  title: string
  description: string
  client: string
  category: "preventivo" | "correctivo" | "instalacion"
  status: "pendiente" | "en_progreso" | "resuelto" | "cancelado"
  assignedTo: string
  createdAt: string
  updatedAt: string
  priority: "baja" | "media" | "alta"
  notes: string[]
}

export interface MaintenanceEvent {
  id: number
  title: string
  description: string
  client: string
  productId?: number
  productName?: string
  date: string
  endDate?: string
  type: "preventivo" | "correctivo" | "instalacion"
  assignedTo: string
  status: "pendiente" | "completado" | "cancelado"
  notes: string
}

// Definir el tipo para el contexto
interface AppContextType {
  // Usuarios
  currentUser: User | null
  users: User[]
  setUsers: (users: User[]) => void
  login: (email: string, password: string) => boolean
  logout: () => void

  // Productos
  products: Product[]
  setProducts: (products: Product[]) => void

  // Ventas
  sales: Sale[]
  setSales: (sales: Sale[]) => void

  // Órdenes de trabajo
  workOrders: WorkOrder[]
  setWorkOrders: (workOrders: WorkOrder[]) => void

  // Tickets
  tickets: Ticket[]
  setTickets: (tickets: Ticket[]) => void

  // Mantenimientos
  maintenanceEvents: MaintenanceEvent[]
  setMaintenanceEvents: (events: MaintenanceEvent[]) => void

  // Notificaciones
  notifications: number
  setNotifications: (count: number) => void

  // Tema
  theme: "light" | "dark" | "system"
  setTheme: (theme: "light" | "dark" | "system") => void
}

// Crear el contexto
const AppContext = createContext<AppContextType | undefined>(undefined)

// Proveedor del contexto
export function AppProvider({ children }: { children: ReactNode }) {
  // Estado para usuarios
  const [users, setUsers] = useState<User[]>(() =>
    storage.getItem<User[]>("users", [
      {
        id: 1,
        name: "Admin Usuario",
        email: "admin@empresa.cl",
        role: "admin",
        active: true,
        lastLogin: new Date().toISOString(),
        preferences: {
          theme: "system",
          language: "es-CL",
          notifications: true,
        },
      },
      {
        id: 2,
        name: "Juan Pérez",
        email: "juan.perez@empresa.cl",
        role: "tecnico",
        active: true,
        lastLogin: "2025-04-13T14:45:00",
        preferences: {
          theme: "light",
          language: "es-CL",
          notifications: true,
        },
      },
      {
        id: 3,
        name: "María González",
        email: "maria.gonzalez@empresa.cl",
        role: "vendedor",
        active: true,
        lastLogin: "2025-04-14T08:15:00",
        preferences: {
          theme: "system",
          language: "es-CL",
          notifications: true,
        },
      },
    ]),
  )

  const [currentUser, setCurrentUser] = useState<User | null>(() => storage.getItem<User | null>("currentUser", null))

  // Estado para productos
  const [products, setProducts] = useState<Product[]>(() =>
    storage.getItem<Product[]>("products", [
      {
        id: 1,
        name: 'Monitor LG 24"',
        sku: "MON-LG-24",
        category: "accesorios",
        stock: 2,
        price: 150000,
        status: "critical",
        location: "Bodega A - Estante 3",
      },
      {
        id: 2,
        name: "Teclado Mecánico RGB",
        sku: "TEC-MEC-01",
        category: "accesorios",
        stock: 15,
        price: 45000,
        status: "normal",
        location: "Bodega A - Estante 2",
      },
    ]),
  )

  // Estado para ventas
  const [sales, setSales] = useState<Sale[]>(() =>
    storage.getItem<Sale[]>("sales", [
      {
        id: 1,
        orderNumber: "ORD-1234",
        client: "Empresa ABC Ltda.",
        date: "2025-04-14",
        status: "en_curso",
        items: [
          { id: 1, productName: 'Monitor LG 24"', quantity: 2, unitPrice: 150000, subtotal: 300000 },
          { id: 2, productName: "Teclado Mecánico RGB", quantity: 5, unitPrice: 45000, subtotal: 225000 },
        ],
        total: 525000,
        notes: "Entrega programada para el 20/04/2025",
      },
    ]),
  )

  // Estado para órdenes de trabajo
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(() =>
    storage.getItem<WorkOrder[]>("workOrders", [
      {
        id: 1,
        orderNumber: "OT-1001",
        client: "Empresa ABC Ltda.",
        date: "2025-04-15",
        status: "en_curso",
        type: "instalacion",
        assignedTo: "Juan Pérez",
        description: "Instalación de equipos de red",
        items: [
          { id: 1, description: "Instalación de router", quantity: 1, unitPrice: 45000, subtotal: 45000 },
          { id: 2, description: "Configuración de red", quantity: 1, unitPrice: 35000, subtotal: 35000 },
        ],
        total: 80000,
        notes: ["Cliente solicita configuración adicional de seguridad"],
      },
    ]),
  )

  // Estado para tickets
  const [tickets, setTickets] = useState<Ticket[]>(() =>
    storage.getItem<Ticket[]>("tickets", [
      {
        id: 1,
        title: "Falla en monitor principal",
        description: "El monitor principal de la recepción presenta intermitencia en la imagen.",
        client: "Empresa ABC Ltda.",
        category: "correctivo",
        status: "en_progreso",
        assignedTo: "Juan Pérez",
        createdAt: "2025-04-12T10:30:00",
        updatedAt: "2025-04-13T14:15:00",
        priority: "alta",
        notes: [
          "Se realizó diagnóstico inicial, posible problema en la fuente de alimentación.",
          "Se solicitaron repuestos para reparación.",
        ],
      },
    ]),
  )

  // Estado para eventos de mantenimiento
  const [maintenanceEvents, setMaintenanceEvents] = useState<MaintenanceEvent[]>(() =>
    storage.getItem<MaintenanceEvent[]>("maintenanceEvents", [
      {
        id: 1,
        title: "Mantenimiento preventivo servidores",
        description: "Mantenimiento preventivo de los servidores principales.",
        client: "Empresa ABC Ltda.",
        date: "2025-04-20T09:00:00",
        endDate: "2025-04-20T12:00:00",
        type: "preventivo",
        assignedTo: "Juan Pérez",
        status: "pendiente",
        notes: "Se debe realizar respaldo previo",
      },
    ]),
  )

  // Estado para notificaciones
  const [notifications, setNotifications] = useState<number>(() => storage.getItem<number>("notifications", 3))

  // Estado para tema
  const [theme, setTheme] = useState<"light" | "dark" | "system">(() =>
    storage.getItem<"light" | "dark" | "system">("theme", "system"),
  )

  // Función para iniciar sesión
  const login = (email: string, password: string): boolean => {
    try {
      // En un sistema real, aquí se verificaría contra una API
      // Por ahora, simplemente verificamos si el usuario existe
      const user = users.find((u) => u.email === email && u.active)

      if (user) {
        const updatedUser = {
          ...user,
          lastLogin: new Date().toISOString(),
        }

        setCurrentUser(updatedUser)
        storage.setItem("currentUser", updatedUser)

        // Actualizar el usuario en la lista
        const updatedUsers = users.map((u) => (u.id === user.id ? updatedUser : u))
        setUsers(updatedUsers)
        storage.setItem("users", updatedUsers)

        return true
      }

      return false
    } catch (error) {
      console.error("Error en el proceso de login:", error)
      return false
    }
  }

  // Función para cerrar sesión
  const logout = () => {
    try {
      setCurrentUser(null)
      storage.removeItem("currentUser")
    } catch (error) {
      console.error("Error en el proceso de logout:", error)
    }
  }

  // Persistir cambios en localStorage con mejor manejo de errores
  useEffect(() => {
    try {
      storage.setItem("users", users)
    } catch (error) {
      console.error("Error al guardar usuarios:", error)
    }
  }, [users])

  useEffect(() => {
    try {
      storage.setItem("products", products)
    } catch (error) {
      console.error("Error al guardar productos:", error)
    }
  }, [products])

  useEffect(() => {
    try {
      storage.setItem("sales", sales)
    } catch (error) {
      console.error("Error al guardar ventas:", error)
    }
  }, [sales])

  useEffect(() => {
    try {
      storage.setItem("workOrders", workOrders)
    } catch (error) {
      console.error("Error al guardar órdenes de trabajo:", error)
    }
  }, [workOrders])

  useEffect(() => {
    try {
      storage.setItem("tickets", tickets)
    } catch (error) {
      console.error("Error al guardar tickets:", error)
    }
  }, [tickets])

  useEffect(() => {
    try {
      storage.setItem("maintenanceEvents", maintenanceEvents)
    } catch (error) {
      console.error("Error al guardar eventos de mantenimiento:", error)
    }
  }, [maintenanceEvents])

  useEffect(() => {
    try {
      storage.setItem("notifications", notifications)
    } catch (error) {
      console.error("Error al guardar notificaciones:", error)
    }
  }, [notifications])

  useEffect(() => {
    try {
      storage.setItem("theme", theme)
    } catch (error) {
      console.error("Error al guardar tema:", error)
    }
  }, [theme])

  // Añadir un efecto para guardar el estado completo periódicamente
  useEffect(() => {
    // Guardar todo el estado cada 30 segundos
    const intervalId = setInterval(() => {
      try {
        const appState = {
          lastSaved: new Date().toISOString(),
          users,
          products,
          sales,
          workOrders,
          tickets,
          maintenanceEvents,
          notifications,
          theme,
        }
        storage.setItem("appState", appState)
        console.log("Estado completo guardado automáticamente")
      } catch (error) {
        console.error("Error al guardar estado completo:", error)
      }
    }, 30000)

    return () => clearInterval(intervalId)
  }, [users, products, sales, workOrders, tickets, maintenanceEvents, notifications, theme])

  // Valor del contexto
  const contextValue: AppContextType = {
    currentUser,
    users,
    setUsers,
    login,
    logout,
    products,
    setProducts,
    sales,
    setSales,
    workOrders,
    setWorkOrders,
    tickets,
    setTickets,
    maintenanceEvents,
    setMaintenanceEvents,
    notifications,
    setNotifications,
    theme,
    setTheme,
  }

  return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>
}

// Hook para usar el contexto
export function useAppContext() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppContext debe ser usado dentro de un AppProvider")
  }
  return context
}
