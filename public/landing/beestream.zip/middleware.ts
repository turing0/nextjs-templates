import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Only protect admin routes
  if (path.startsWith("/admin")) {
    const token = request.cookies.get("auth-token")?.value

    // If not authenticated, redirect to login
    if (token !== "authenticated") {
      console.log("Redirecting to login from middleware")
      return NextResponse.redirect(new URL("/login", request.url))
    }
  }

  return NextResponse.next()
}

// Only run middleware on admin routes
export const config = {
  matcher: ["/admin/:path*"],
}
