import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function generateNewsStory(prompt: string) {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Write a news article about: ${prompt}. Format it with HTML tags for paragraphs and headings.`,
    })

    return { content: text, success: true }
  } catch (error) {
    console.error("Error generating news story:", error)
    return { content: "", success: false, error }
  }
}

export async function generateStoryTitle(prompt: string) {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Create a concise, engaging title for an article about: ${prompt}`,
    })

    return { title: text, success: true }
  } catch (error) {
    console.error("Error generating title:", error)
    return { title: "", success: false, error }
  }
}

export async function formatStory(content: string) {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Format the following content into a well-structured news article with proper HTML formatting, including paragraphs, headings, and emphasis where appropriate: ${content}`,
    })

    return { formattedContent: text, success: true }
  } catch (error) {
    console.error("Error formatting story:", error)
    return { formattedContent: "", success: false, error }
  }
}

export async function suggestRelatedTopics(topic: string) {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Suggest 5 related topics for an article about: ${topic}. Return as a comma-separated list.`,
    })

    return { topics: text.split(",").map((t) => t.trim()), success: true }
  } catch (error) {
    console.error("Error suggesting related topics:", error)
    return { topics: [], success: false, error }
  }
}
