"use server"

import { cookies } from "next/headers"

// In a real app, you would store these securely in a database
// This is just for demonstration purposes
const ADMIN_USERNAME = "admin"
const ADMIN_PASSWORD = "password123"

export async function login(username: string, password: string) {
  // Simple authentication check
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    // Set a cookie to maintain the session
    cookies().set("auth-token", "authenticated", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
      path: "/",
    })

    return { success: true }
  }

  return {
    success: false,
    error: "Invalid username or password",
  }
}

export async function logout() {
  cookies().delete("auth-token")
  return { success: true }
}

export async function isAuthenticated() {
  const token = cookies().get("auth-token")
  return token?.value === "authenticated"
}
