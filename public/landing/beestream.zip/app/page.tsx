import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Newspaper, Rss } from "lucide-react"

export default function Home() {
  // Sample featured stories
  const featuredStories = [
    {
      id: 1,
      title: "The Importance of Bees in Our Ecosystem",
      excerpt: "Discover why bees are crucial for maintaining biodiversity and food production worldwide.",
      date: "April 10, 2025",
      category: "Environment",
    },
    {
      id: 2,
      title: "New Technology Trends in 2025",
      excerpt: "Explore the cutting-edge technologies that are shaping our future this year.",
      date: "April 8, 2025",
      category: "Technology",
    },
    {
      id: 3,
      title: "Global Climate Summit Results",
      excerpt: "Key takeaways from the latest international climate conference and what it means for our planet.",
      date: "April 5, 2025",
      category: "Politics",
    },
  ]

  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="bg-yellow-400 py-16 px-4 md:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-1/2">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-black mb-4">BEEstream</h1>
              <p className="text-xl md:text-2xl text-black mb-8">Your source for the latest buzz in news and stories</p>
              <div className="flex flex-wrap gap-4">
                <Button asChild className="bg-black hover:bg-gray-800 text-white">
                  <Link href="/stories">Browse Stories</Link>
                </Button>
                <Button asChild variant="outline" className="border-black text-black hover:bg-yellow-500">
                  <Link href="/about">About Us</Link>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="w-64 h-64 bg-yellow-300 rounded-full flex items-center justify-center">
                <Rss size={80} className="text-black" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Stories */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">Featured Stories</h2>
            <Button asChild variant="ghost" className="text-yellow-600 hover:text-yellow-800">
              <Link href="/stories" className="flex items-center gap-2">
                View All <ArrowRight size={16} />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredStories.map((story) => (
              <Card key={story.id} className="h-full flex flex-col">
                <CardHeader>
                  <div className="text-sm text-yellow-600 font-medium mb-1">{story.category}</div>
                  <CardTitle className="text-xl">{story.title}</CardTitle>
                  <CardDescription>{story.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p>{story.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link href={`/stories/${story.id}`}>Read More</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-gray-100">
        <div className="max-w-3xl mx-auto text-center">
          <Newspaper className="mx-auto mb-4 text-yellow-600" size={40} />
          <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
          <p className="text-lg mb-6">
            Subscribe to our newsletter to receive the latest news and stories directly in your inbox.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-grow px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
            />
            <Button className="bg-yellow-600 hover:bg-yellow-700">Subscribe</Button>
          </div>
        </div>
      </section>
    </main>
  )
}
