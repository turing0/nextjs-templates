"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { logout } from "@/lib/auth"
import { LogOut } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function AdminDashboard() {
  const router = useRouter()
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [storyTitle, setStoryTitle] = useState("")
  const [storyContent, setStoryContent] = useState("")
  const [storyCategory, setStoryCategory] = useState("")
  const [storyPrompt, setStoryPrompt] = useState("")

  // Sample stories for the dashboard
  const recentStories = [
    { id: 1, title: "The Importance of Bees in Our Ecosystem", status: "Published", date: "April 10, 2025" },
    { id: 2, title: "New Technology Trends in 2025", status: "Published", date: "April 8, 2025" },
    { id: 3, title: "Draft: Climate Change Impact", status: "Draft", date: "April 12, 2025" },
  ]

  const handleLogout = async () => {
    await logout()
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    })
    router.push("/")
    router.refresh()
  }

  const handleGenerateContent = async () => {
    if (!storyPrompt) {
      toast({
        title: "Error",
        description: "Please enter a prompt for the AI to generate content.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      // This is a mock implementation since we can't actually call the AI in this environment
      // In a real implementation, you would use the AI SDK to generate content
      setTimeout(() => {
        // Simulate AI-generated content
        const generatedTitle = storyPrompt.split(" ").slice(0, 5).join(" ") + "..."
        const generatedContent = `
          <p>This is an AI-generated article based on your prompt: "${storyPrompt}"</p>
          
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.</p>
          
          <h2>Key Points</h2>
          
          <p>Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.</p>
          
          <p>Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.</p>
          
          <h2>Conclusion</h2>
          
          <p>Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl. Nullam auctor, nisl eget ultricies tincidunt, nisl nisl aliquam nisl, eget ultricies nisl nisl eget nisl.</p>
        `

        setStoryTitle(generatedTitle)
        setStoryContent(generatedContent)
        setIsGenerating(false)

        toast({
          title: "Content Generated",
          description: "AI has successfully generated content based on your prompt.",
        })
      }, 2000)

      // In a real implementation, you would use the AI SDK like this:
      /*
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Write a news article about: ${storyPrompt}. Format it with HTML tags for paragraphs and headings.`,
      });
      
      // Extract a title from the generated content or generate a separate title
      const titleResult = await generateText({
        model: openai("gpt-4o"),
        prompt: `Create a concise, engaging title for an article about: ${storyPrompt}`,
      });
      
      setStoryTitle(titleResult.text);
      setStoryContent(text);
      setIsGenerating(false);
      
      toast({
        title: "Content Generated",
        description: "AI has successfully generated content based on your prompt.",
      });
      */
    } catch (error) {
      console.error("Error generating content:", error)
      setIsGenerating(false)
      toast({
        title: "Error",
        description: "Failed to generate content. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handlePublishStory = () => {
    if (!storyTitle || !storyContent || !storyCategory) {
      toast({
        title: "Error",
        description: "Please fill in all required fields before publishing.",
        variant: "destructive",
      })
      return
    }

    // In a real application, you would save the story to a database here
    toast({
      title: "Success",
      description: "Your story has been published successfully!",
    })

    // Reset form
    setStoryTitle("")
    setStoryContent("")
    setStoryCategory("")
    setStoryPrompt("")
  }

  return (
    <main className="container py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">Admin Dashboard</h1>
        <Button onClick={handleLogout} variant="outline" className="flex items-center gap-2">
          <LogOut size={16} />
          Logout
        </Button>
      </div>

      <Tabs defaultValue="create">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="create">Create Story</TabsTrigger>
          <TabsTrigger value="manage">Manage Stories</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Create New Story</CardTitle>
                  <CardDescription>Write a new story or use AI to help generate content.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        placeholder="Enter story title"
                        value={storyTitle}
                        onChange={(e) => setStoryTitle(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select value={storyCategory} onValueChange={setStoryCategory}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Environment">Environment</SelectItem>
                          <SelectItem value="Technology">Technology</SelectItem>
                          <SelectItem value="Politics">Politics</SelectItem>
                          <SelectItem value="Lifestyle">Lifestyle</SelectItem>
                          <SelectItem value="Science">Science</SelectItem>
                          <SelectItem value="Business">Business</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="content">Content</Label>
                      <Textarea
                        id="content"
                        placeholder="Write your story content here..."
                        className="min-h-[300px]"
                        value={storyContent}
                        onChange={(e) => setStoryContent(e.target.value)}
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <Button variant="outline">Save as Draft</Button>
                      <Button onClick={handlePublishStory} className="bg-yellow-600 hover:bg-yellow-700">
                        Publish Story
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>AI Content Generator</CardTitle>
                  <CardDescription>Let AI help you create content for your story.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="prompt">Prompt for AI</Label>
                      <Textarea
                        id="prompt"
                        placeholder="Describe what you want the AI to write about..."
                        className="min-h-[150px]"
                        value={storyPrompt}
                        onChange={(e) => setStoryPrompt(e.target.value)}
                      />
                    </div>

                    <Button
                      onClick={handleGenerateContent}
                      className="w-full bg-black hover:bg-gray-800"
                      disabled={isGenerating}
                    >
                      {isGenerating ? "Generating..." : "Generate Content"}
                    </Button>

                    <div className="text-sm text-muted-foreground">
                      <p>Tips for effective prompts:</p>
                      <ul className="list-disc pl-4 mt-2 space-y-1">
                        <li>Be specific about the topic</li>
                        <li>Mention the tone (formal, casual, etc.)</li>
                        <li>Specify the target audience</li>
                        <li>Include key points to cover</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="manage" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Manage Stories</CardTitle>
              <CardDescription>View, edit, and delete your published and draft stories.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="py-3 px-4 text-left font-medium">Title</th>
                      <th className="py-3 px-4 text-left font-medium">Status</th>
                      <th className="py-3 px-4 text-left font-medium">Date</th>
                      <th className="py-3 px-4 text-right font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentStories.map((story) => (
                      <tr key={story.id} className="border-b">
                        <td className="py-3 px-4">{story.title}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${
                              story.status === "Published"
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {story.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">{story.date}</td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700">
                                  Delete
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete the story.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction className="bg-red-500 hover:bg-red-600">Delete</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Analytics</CardTitle>
              <CardDescription>View performance metrics for your stories.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Total Views</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">12,543</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      <span className="text-green-500">↑ 12%</span> from last month
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Average Read Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">3:24</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      <span className="text-green-500">↑ 8%</span> from last month
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Engagement Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">24.8%</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      <span className="text-red-500">↓ 3%</span> from last month
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">Top Performing Stories</h3>
                <div className="rounded-md border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="py-3 px-4 text-left font-medium">Title</th>
                        <th className="py-3 px-4 text-left font-medium">Views</th>
                        <th className="py-3 px-4 text-left font-medium">Avg. Read Time</th>
                        <th className="py-3 px-4 text-left font-medium">Engagement</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 px-4">The Importance of Bees in Our Ecosystem</td>
                        <td className="py-3 px-4">4,256</td>
                        <td className="py-3 px-4">4:12</td>
                        <td className="py-3 px-4">32.5%</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4">New Technology Trends in 2025</td>
                        <td className="py-3 px-4">3,845</td>
                        <td className="py-3 px-4">3:56</td>
                        <td className="py-3 px-4">28.7%</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4">Global Climate Summit Results</td>
                        <td className="py-3 px-4">2,932</td>
                        <td className="py-3 px-4">3:21</td>
                        <td className="py-3 px-4">24.3%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  )
}
