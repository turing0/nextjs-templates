export default function TestLoginPage() {
  return (
    <div className="container py-12">
      <h1 className="text-4xl font-bold mb-6">Test Login Page</h1>
      <p className="mb-4">This is a simple test page to verify routing is working correctly.</p>
      <div className="p-4 bg-yellow-100 rounded-md">
        <p>If you can see this page, then routing to new pages is working properly.</p>
      </div>
    </div>
  )
}
