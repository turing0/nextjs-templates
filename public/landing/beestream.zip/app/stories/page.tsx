import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"

export default function StoriesPage() {
  // Sample stories data
  const stories = [
    {
      id: 1,
      title: "The Importance of Bees in Our Ecosystem",
      excerpt: "Discover why bees are crucial for maintaining biodiversity and food production worldwide.",
      date: "April 10, 2025",
      category: "Environment",
    },
    {
      id: 2,
      title: "New Technology Trends in 2025",
      excerpt: "Explore the cutting-edge technologies that are shaping our future this year.",
      date: "April 8, 2025",
      category: "Technology",
    },
    {
      id: 3,
      title: "Global Climate Summit Results",
      excerpt: "Key takeaways from the latest international climate conference and what it means for our planet.",
      date: "April 5, 2025",
      category: "Politics",
    },
    {
      id: 4,
      title: "The Rise of Sustainable Fashion",
      excerpt: "How eco-friendly practices are transforming the fashion industry and reducing environmental impact.",
      date: "April 3, 2025",
      category: "Lifestyle",
    },
    {
      id: 5,
      title: "Space Exploration Milestones of 2025",
      excerpt: "A look at the major achievements in space exploration during the first quarter of 2025.",
      date: "April 1, 2025",
      category: "Science",
    },
    {
      id: 6,
      title: "Global Economic Outlook for Q2 2025",
      excerpt: "Financial experts analyze market trends and provide predictions for the coming months.",
      date: "March 28, 2025",
      category: "Business",
    },
  ]

  const categories = ["All", "Environment", "Technology", "Politics", "Lifestyle", "Science", "Business"]

  return (
    <main className="container py-12">
      <h1 className="text-4xl font-bold mb-8">Stories</h1>

      {/* Search and Filter */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input placeholder="Search stories..." className="pl-10" />
          </div>
          <Button className="bg-yellow-600 hover:bg-yellow-700">Search</Button>
        </div>

        <Tabs defaultValue="All">
          <TabsList className="w-full overflow-auto">
            {categories.map((category) => (
              <TabsTrigger key={category} value={category} className="flex-1">
                {category}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category} value={category}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
                {stories
                  .filter((story) => category === "All" || story.category === category)
                  .map((story) => (
                    <Card key={story.id} className="h-full flex flex-col">
                      <CardHeader>
                        <div className="text-sm text-yellow-600 font-medium mb-1">{story.category}</div>
                        <CardTitle className="text-xl">{story.title}</CardTitle>
                        <CardDescription>{story.date}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-grow">
                        <p>{story.excerpt}</p>
                      </CardContent>
                      <CardFooter>
                        <Button asChild variant="outline" className="w-full">
                          <Link href={`/stories/${story.id}`}>Read More</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </main>
  )
}
