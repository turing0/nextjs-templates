import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Calendar, Tag } from "lucide-react"

// This would normally come from a database
const getStory = (id: string) => {
  const stories = {
    "1": {
      id: 1,
      title: "The Importance of Bees in Our Ecosystem",
      content: `
        <p>Bees play a crucial role in our ecosystem, serving as primary pollinators for a vast array of plants, including many of the crops that humans rely on for food. In fact, it's estimated that one-third of the food we consume each day relies on pollination, mainly by bees.</p>
        
        <p>Beyond their role in agriculture, bees contribute to the health and diversity of natural ecosystems. By pollinating wild plants, they help maintain biodiversity and support the food web that sustains wildlife.</p>
        
        <h2>The Decline of Bee Populations</h2>
        
        <p>Unfortunately, bee populations worldwide have been declining at an alarming rate in recent decades. This decline is attributed to multiple factors, including habitat loss, pesticide use, climate change, and disease.</p>
        
        <p>The loss of natural habitats due to urbanization and industrial agriculture has reduced the availability of food sources and nesting sites for bees. Additionally, the widespread use of pesticides, particularly neonicotinoids, has been linked to bee deaths and colony collapse disorder.</p>
        
        <h2>Conservation Efforts</h2>
        
        <p>Recognizing the importance of bees, various conservation efforts are underway globally. These include creating bee-friendly habitats, reducing pesticide use, and supporting research into bee health and conservation.</p>
        
        <p>Individuals can also contribute to bee conservation by planting bee-friendly gardens, avoiding the use of pesticides, and supporting local beekeepers by purchasing locally produced honey.</p>
        
        <h2>Conclusion</h2>
        
        <p>The health of bee populations is intrinsically linked to the health of our ecosystems and food systems. By understanding the importance of bees and taking steps to protect them, we can help ensure a sustainable future for both bees and humans.</p>
      `,
      date: "April 10, 2025",
      category: "Environment",
      author: "Emma Johnson",
      readTime: "5 min read",
    },
    "2": {
      id: 2,
      title: "New Technology Trends in 2025",
      content: `
        <p>As we progress through 2025, several technology trends are shaping our digital landscape and transforming how we live, work, and interact. From artificial intelligence to quantum computing, these innovations are pushing the boundaries of what's possible.</p>
        
        <h2>Artificial Intelligence and Machine Learning</h2>
        
        <p>AI and machine learning continue to advance at a rapid pace, with applications expanding across industries. In healthcare, AI is improving diagnostic accuracy and treatment planning. In finance, it's enhancing fraud detection and algorithmic trading. And in our daily lives, AI-powered virtual assistants are becoming more sophisticated and intuitive.</p>
        
        <h2>Quantum Computing</h2>
        
        <p>Quantum computing is moving from theoretical research to practical applications. With the ability to process vast amounts of data simultaneously, quantum computers are tackling complex problems that were previously unsolvable, from drug discovery to climate modeling.</p>
        
        <h2>Extended Reality (XR)</h2>
        
        <p>The boundaries between physical and digital realities are blurring with advancements in extended reality technologies, including virtual reality (VR), augmented reality (AR), and mixed reality (MR). These technologies are transforming entertainment, education, healthcare, and workplace collaboration.</p>
        
        <h2>Sustainable Technology</h2>
        
        <p>As environmental concerns grow, there's an increasing focus on sustainable technology. This includes renewable energy solutions, energy-efficient devices, and technologies that help monitor and reduce environmental impact.</p>
        
        <h2>Conclusion</h2>
        
        <p>The technology trends of 2025 are not just about innovation for innovation's sake. They're about solving real-world problems, enhancing human capabilities, and creating a more sustainable future. As these technologies continue to evolve, they will undoubtedly shape our world in ways we're only beginning to imagine.</p>
      `,
      date: "April 8, 2025",
      category: "Technology",
      author: "Michael Chen",
      readTime: "6 min read",
    },
  }

  return stories[id as keyof typeof stories] || null
}

export default function StoryPage({ params }: { params: { id: string } }) {
  const story = getStory(params.id)

  if (!story) {
    return (
      <div className="container py-12 text-center">
        <h1 className="text-4xl font-bold mb-4">Story Not Found</h1>
        <p className="mb-8">The story you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/stories">Back to Stories</Link>
        </Button>
      </div>
    )
  }

  return (
    <main className="container py-12">
      <Button asChild variant="ghost" className="mb-6">
        <Link href="/stories" className="flex items-center gap-2">
          <ArrowLeft size={16} /> Back to Stories
        </Link>
      </Button>

      <article className="max-w-3xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1">
              <Tag size={14} /> {story.category}
            </span>
            <span className="text-muted-foreground text-sm flex items-center gap-1">
              <Calendar size={14} /> {story.date}
            </span>
          </div>

          <h1 className="text-4xl font-bold mb-4">{story.title}</h1>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                {story.author.charAt(0)}
              </div>
              <div>
                <p className="font-medium">{story.author}</p>
                <p className="text-sm text-muted-foreground">{story.readTime}</p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                Share
              </Button>
              <Button variant="outline" size="sm">
                Save
              </Button>
            </div>
          </div>
        </header>

        <div className="prose prose-yellow max-w-none" dangerouslySetInnerHTML={{ __html: story.content }} />

        <div className="mt-12 pt-8 border-t">
          <h2 className="text-2xl font-bold mb-4">Join the Conversation</h2>
          <textarea
            className="w-full p-4 border rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500 min-h-32"
            placeholder="Share your thoughts on this story..."
          />
          <div className="mt-4 flex justify-end">
            <Button className="bg-yellow-600 hover:bg-yellow-700">Post Comment</Button>
          </div>
        </div>
      </article>
    </main>
  )
}
