import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Rss } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Your Name",
      role: "Owner & CEO",
      bio: "As the owner of BEEstream, leads the company's vision and strategy, bringing innovative approaches to digital news media.",
      contact: "+254 732 539 199",
    },
    {
      name: "Michael Chen",
      role: "Technology Respondent",
      bio: "Michael handles all technical aspects of BEEstream, from website development to implementing AI features for content generation.",
    },
  ]

  return (
    <main className="container py-12">
      <section className="max-w-4xl mx-auto mb-16">
        <h1 className="text-4xl font-bold mb-6">About BEEstream</h1>

        <div className="flex flex-col md:flex-row items-center gap-8 mb-12">
          <div className="md:w-1/3 flex justify-center">
            <div className="w-48 h-48 bg-yellow-400 rounded-full flex items-center justify-center">
              <Rss size={80} className="text-black" />
            </div>
          </div>

          <div className="md:w-2/3">
            <p className="text-lg mb-4">
              BEEstream is your source for the latest buzz in news and stories. We're dedicated to delivering timely,
              accurate, and engaging content across a wide range of topics.
            </p>
            <p className="text-lg mb-4">
              Established in 2025, our mission is to inform, educate, and entertain our readers with high-quality
              journalism and storytelling. We believe in the power of well-researched, thoughtfully presented
              information to help people make sense of our complex world.
            </p>
            <p className="text-lg">
              Our small but dedicated team covers everything from environmental issues and technology trends to
              politics, lifestyle, science, and business.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-3">Our Mission</h3>
              <p>
                To provide our readers with accurate, engaging, and timely information that helps them understand and
                navigate the world around them.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-3">Our Vision</h3>
              <p>
                To become a trusted source of news and stories that informs, inspires, and connects people across
                diverse interests and backgrounds.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-3">Our Values</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Accuracy and integrity in reporting</li>
                <li>Respect for diverse perspectives</li>
                <li>Commitment to ethical journalism</li>
                <li>Innovation in storytelling</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-3">Our Approach</h3>
              <p>
                We combine traditional journalistic principles with modern technology and AI to deliver content that is
                both informative and engaging, tailored to the needs and interests of our readers.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="max-w-4xl mx-auto mb-16">
        <h2 className="text-3xl font-bold mb-8">Our Team</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {teamMembers.map((member, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-yellow-200 flex items-center justify-center text-yellow-800 font-bold">
                    {member.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{member.name}</h3>
                    <p className="text-yellow-600 mb-2">{member.role}</p>
                    <p>{member.bio}</p>
                    {member.contact && <p className="mt-2 text-sm text-yellow-600">Contact: {member.contact}</p>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-8">Contact Us</h2>

        <div className="bg-yellow-50 rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Get in Touch</h3>
          <p className="mb-6">Have questions, feedback, or story ideas? We'd love to hear from you!</p>
          <Button asChild className="bg-yellow-600 hover:bg-yellow-700">
            <Link href="/contact">Contact Us</Link>
          </Button>
        </div>
      </section>
    </main>
  )
}
