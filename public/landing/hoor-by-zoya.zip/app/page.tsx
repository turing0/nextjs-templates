import HeroBanner from "@/components/hero-banner"
import FeaturedCollection from "@/components/featured-collection"
import CategoriesSection from "@/components/categories-section"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function Home() {
  return (
    <div>
      <HeroBanner />

      <FeaturedCollection />

      <CategoriesSection />

      {/* About Section */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative h-[400px]">
              <Image src="/images/about.png" alt="About Hoor by Zoya" fill className="object-cover rounded-lg" />
              <div className="absolute -bottom-5 -right-5 w-20 h-20 bow-decoration" />
            </div>

            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-foreground ribbon">About Hoor by Zoya</h2>
              <p className="text-muted-foreground">
                Hoor by Zoya is a premium Pakistani designer brand specializing in exquisite suits for women. Each piece
                is meticulously crafted with attention to detail, using the finest fabrics and traditional embroidery
                techniques.
              </p>
              <p className="text-muted-foreground">
                Our designs blend contemporary styles with traditional Pakistani craftsmanship, creating unique pieces
                that celebrate cultural heritage while embracing modern fashion trends.
              </p>
              <Button asChild variant="outline" className="rounded-full">
                <Link href="/about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Instagram Section */}
      <div className="bg-pink-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4 ribbon">Follow Us on Instagram</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">@hoorbyzoya</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <Link
                key={item}
                href="https://instagram.com/hoorbyzoya"
                target="_blank"
                rel="noopener noreferrer"
                className="aspect-square overflow-hidden rounded-lg"
              >
                <Image
                  src={`/images/insta-${item}.png`}
                  alt="Instagram Post"
                  width={200}
                  height={200}
                  className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
