"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Minus, Plus, Trash2 } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

// Mock cart data
const initialCartItems = [
  {
    id: "1",
    name: "Embroidered Chiffon Suit",
    price: 12500,
    image: "/images/product-1.png",
    size: "M",
    color: "Pink",
    quantity: 1,
  },
  {
    id: "4",
    name: "Digital Print Silk Suit",
    price: 10500,
    image: "/images/product-4.png",
    size: "S",
    color: "Blue",
    quantity: 2,
    discount: 15,
  },
]

export default function CartPage() {
  const [cartItems, setCartItems] = useState(initialCartItems)
  const [promoCode, setPromoCode] = useState("")
  const [promoApplied, setPromoApplied] = useState(false)

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) return

    setCartItems(cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== item.id))
  }

  const applyPromoCode = () => {
    if (promoCode.toLowerCase() === "welcome10") {
      setPromoApplied(true)
    } else {
      alert("Invalid promo code")
    }
  }

  // Calculate totals
  const subtotal = cartItems.reduce((total, item) => {
    const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
    return total + itemPrice * item.quantity
  }, 0)

  const shipping = subtotal > 10000 ? 0 : 500
  const discount = promoApplied ? subtotal * 0.1 : 0
  const total = subtotal + shipping - discount

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-PK", {
      style: "currency",
      currency: "PKR",
    }).format(amount)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-foreground mb-8">Shopping Cart</h1>

      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-xl font-medium text-foreground mb-4">Your cart is empty</h2>
          <p className="text-muted-foreground mb-8">Looks like you haven't added anything to your cart yet.</p>
          <Button asChild>
            <Link href="/collections">Continue Shopping</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <div className="rounded-lg border border-border overflow-hidden">
              <table className="min-w-full divide-y divide-border">
                <thead className="bg-muted">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      Product
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      Price
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      Quantity
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                    >
                      Total
                    </th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Remove</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-card divide-y divide-border">
                  {cartItems.map((item) => {
                    const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
                    const itemTotal = itemPrice * item.quantity

                    return (
                      <tr key={item.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md border border-border">
                              <Image
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                width={64}
                                height={64}
                                className="h-full w-full object-cover object-center"
                              />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-foreground">{item.name}</div>
                              <div className="text-sm text-muted-foreground">
                                Size: {item.size} | Color: {item.color}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-foreground">
                            {item.discount ? (
                              <>
                                <span>{formatCurrency(itemPrice)}</span>
                                <span className="ml-2 line-through text-muted-foreground">
                                  {formatCurrency(item.price)}
                                </span>
                              </>
                            ) : (
                              formatCurrency(item.price)
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground">
                          {formatCurrency(itemTotal)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeItem(item.id)}
                            className="text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-8 flex justify-between items-center">
              <Button variant="outline" asChild>
                <Link href="/collections">Continue Shopping</Link>
              </Button>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="coquette-card p-6">
              <h2 className="text-lg font-medium text-foreground mb-6">Order Summary</h2>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground">{formatCurrency(subtotal)}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="text-foreground">{shipping === 0 ? "Free" : formatCurrency(shipping)}</span>
                </div>

                {promoApplied && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Discount (10%)</span>
                    <span className="text-destructive">-{formatCurrency(discount)}</span>
                  </div>
                )}

                <div className="border-t border-border pt-4 flex justify-between font-medium">
                  <span className="text-foreground">Total</span>
                  <span className="text-foreground">{formatCurrency(total)}</span>
                </div>
              </div>

              <div className="mt-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="promo-code">Promo Code</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="promo-code"
                      placeholder="Enter code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      disabled={promoApplied}
                    />
                    <Button onClick={applyPromoCode} disabled={!promoCode || promoApplied} variant="outline">
                      Apply
                    </Button>
                  </div>
                  {promoApplied && <p className="text-xs text-primary">Promo code applied successfully!</p>}
                </div>

                <div className="mt-4 space-y-2">
                  <Label htmlFor="payment-method">Payment Method</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="payment-cod"
                        name="payment-method"
                        className="h-4 w-4 text-primary"
                        defaultChecked
                      />
                      <Label htmlFor="payment-cod" className="text-sm">
                        Cash on Delivery (₹2199)
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="radio" id="payment-prepaid" name="payment-method" className="h-4 w-4 text-primary" />
                      <Label htmlFor="payment-prepaid" className="text-sm">
                        Prepaid (₹2099)
                      </Label>
                    </div>
                  </div>
                </div>

                <Button className="w-full">Proceed to Checkout</Button>

                <div className="text-xs text-muted-foreground text-center">Secure checkout powered by Stripe</div>
              </div>
              <div className="mt-4 p-3 bg-pink-50 rounded-md text-xs text-muted-foreground fancy-border">
                <p className="font-medium">Order Requirements:</p>
                <p>
                  Please provide your name, address, phone number, size, pincode and colour in one paragraph during
                  checkout.
                </p>
                <p className="mt-1 font-medium text-destructive">Important:</p>
                <p>
                  No returns or exchanges unless fault from our side. Once order has been placed, no changes in address
                  or contact details can be made.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
