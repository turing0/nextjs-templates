import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Instagram } from "lucide-react"

export default function InstagramLinkPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-foreground mb-6 ribbon">Instagram Product Link</h1>

        <div className="coquette-card p-8 mb-8">
          <h2 className="text-xl font-medium text-foreground mb-4">Soft Cotton Embroidered Suit</h2>

          <div className="aspect-video bg-pink-50 rounded-lg mb-6 flex items-center justify-center fancy-border">
            <p className="text-muted-foreground">Instagram Reel Preview</p>
          </div>

          <div className="space-y-4 text-left">
            <div>
              <h3 className="font-medium">Pricing:</h3>
              <p>₹2199 COD (Cash on Delivery)</p>
              <p>₹2099 Prepaid 🩵</p>
            </div>

            <div>
              <h3 className="font-medium">Sizing for chest:</h3>
              <ul className="list-disc pl-5 text-sm">
                <li>L - 38/40 chest</li>
                <li>XL - 42</li>
                <li>XXL - 44</li>
                <li>Top length: 36</li>
                <li>Bottom length: 39</li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium">Sizing for waist:</h3>
              <ul className="list-disc pl-5 text-sm">
                <li>L - 28-32</li>
                <li>XL - 32-34</li>
                <li>XXL - 34-38</li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium">Details:</h3>
              <ul className="list-disc pl-5 text-sm">
                <li>Fabric: Soft cotton with pure embroidery</li>
                <li>Delivery time: 8-10 days</li>
                <li>For COD: ₹250 advance, remaining amount to be paid during delivery</li>
                <li>GPay: 9978624201 (Send screenshot after payment)</li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium">How to order:</h3>
              <p className="text-sm">
                Please share name, address, phone number, size, pincode and colour in one paragraph
              </p>
            </div>

            <div className="text-destructive">
              <h3 className="font-medium">Policy:</h3>
              <p className="text-sm">No returns no exchange unless fault from our side</p>
              <p className="text-sm">Once order has been placed, no changes in the address and contact can be made</p>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="flex items-center gap-2">
              <Link
                href="https://www.instagram.com/reel/DHJR4ZBT4ha/?igsh=czVpbGlnaXEwNnJk"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram className="h-4 w-4" />
                View on Instagram
              </Link>
            </Button>

            <Button asChild variant="outline">
              <Link href="/product/1">View Product Details</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
