"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Heart, Minus, Plus, Share2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import ProductCard from "@/components/product-card"

// Update the product data to include the specific information provided
// Replace the products object with this updated version

const products = {
  "1": {
    id: "1",
    name: "Soft Cotton Embroidered Suit",
    price: 2199,
    prepaidPrice: 2099,
    description: "Beautiful soft cotton suit with pure embroidery. Perfect for all occasions. INDIAN CUSTOMERS ONLY.",
    details:
      "Fabric: Soft cotton with pure embroidery\nDelivery time: 8-10 days\nFor COD: 250 advance, remaining amount to be paid during delivery",
    care: "No returns no exchange unless fault from our side. Once order has been placed, no changes in the address and contact can be made.",
    images: [
      "/images/product-1.png",
      "/images/product-1-alt-1.png",
      "/images/product-1-alt-2.png",
      "/images/product-1-alt-3.png",
    ],
    sizes: ["L", "XL", "XXL"],
    colors: ["Pink", "Blue", "Green"],
    sizeChart: {
      chest: {
        L: "38/40 chest",
        XL: "42",
        XXL: "44",
        topLength: "36",
        bottomLength: "39",
      },
      waist: {
        L: "28-32",
        XL: "32-34",
        XXL: "34-38",
      },
    },
    isNew: true,
  },
  // Keep other products if needed
}

// Related products
const relatedProducts = [
  {
    id: "3",
    name: "Embellished Formal Suit",
    price: 15000,
    image: "/images/product-3.png",
  },
  {
    id: "4",
    name: "Digital Print Silk Suit",
    price: 10500,
    image: "/images/product-4.png",
    isSale: true,
    discount: 15,
  },
  {
    id: "5",
    name: "Luxury Velvet Suit",
    price: 18000,
    image: "/images/product-5.png",
  },
  {
    id: "6",
    name: "Casual Cotton Suit",
    price: 7500,
    image: "/images/product-6.png",
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = products[params.id]

  const [selectedSize, setSelectedSize] = useState<string | null>(null)
  const [selectedColor, setSelectedColor] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)

  if (!product) {
    return <div className="container mx-auto px-4 py-16">Product not found</div>
  }

  const formattedPrice = new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
  }).format(product.price)

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert("Please select a size")
      return
    }
    if (!selectedColor) {
      alert("Please select a color")
      return
    }

    // In a real app, this would add the product to the cart
    alert(`Added ${quantity} ${product.name} to cart (Size: ${selectedSize}, Color: ${selectedColor})`)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-h-4 aspect-w-3 overflow-hidden rounded-lg bg-gray-100 fancy-border">
            <Image
              src={product.images[activeImage] || "/placeholder.svg"}
              alt={product.name}
              width={600}
              height={800}
              className="h-full w-full object-cover object-center"
            />
          </div>

          <div className="grid grid-cols-4 gap-4">
            {product.images.map((image, index) => (
              <button
                key={index}
                onClick={() => setActiveImage(index)}
                className={`aspect-h-1 aspect-w-1 overflow-hidden rounded-md ${
                  activeImage === index ? "ring-2 ring-primary" : ""
                }`}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} - View ${index + 1}`}
                  width={150}
                  height={150}
                  className="h-full w-full object-cover object-center"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          {product.isNew && (
            <div className="inline-block bg-primary text-white px-3 py-1 text-xs font-medium rounded-full">
              New Arrival
            </div>
          )}

          <h1 className="text-3xl font-bold text-foreground">{product.name}</h1>

          {/* Update the price display to show both COD and prepaid prices
          Replace the price paragraph with: */}
          <div className="space-y-1">
            <p className="text-2xl font-medium text-foreground">₹{product.price} (COD)</p>
            <p className="text-lg text-primary">₹{product.prepaidPrice} (Prepaid) 🩵</p>
          </div>

          <p className="text-muted-foreground">{product.description}</p>

          {/* Add this after the product description */}
          <div className="mt-4 p-4 bg-pink-50 rounded-md fancy-border">
            <h3 className="font-medium text-foreground">Size Chart:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div>
                <h4 className="text-sm font-medium">Chest Sizing:</h4>
                <ul className="text-sm text-muted-foreground">
                  <li>L - 38/40 chest</li>
                  <li>XL - 42</li>
                  <li>XXL - 44</li>
                  <li>Top length: 36</li>
                  <li>Bottom length: 39</li>
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-medium">Waist Sizing:</h4>
                <ul className="text-sm text-muted-foreground">
                  <li>L - 28-32</li>
                  <li>XL - 32-34</li>
                  <li>XXL - 34-38</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-foreground mb-2">Size</h3>
              <RadioGroup value={selectedSize || ""} onValueChange={setSelectedSize} className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <div key={size} className="flex items-center space-x-2">
                    <RadioGroupItem value={size} id={`size-${size}`} className="peer sr-only" />
                    <Label
                      htmlFor={`size-${size}`}
                      className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full border border-input bg-background text-sm font-medium ring-offset-background peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary"
                    >
                      {size}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div>
              <h3 className="text-sm font-medium text-foreground mb-2">Color</h3>
              <RadioGroup value={selectedColor || ""} onValueChange={setSelectedColor} className="flex flex-wrap gap-2">
                {product.colors.map((color) => (
                  <div key={color} className="flex items-center space-x-2">
                    <RadioGroupItem value={color} id={`color-${color}`} className="peer sr-only" />
                    <Label
                      htmlFor={`color-${color}`}
                      className="flex h-10 px-3 cursor-pointer items-center justify-center rounded-full border border-input bg-background text-sm font-medium ring-offset-background peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary"
                    >
                      {color}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div>
              <h3 className="text-sm font-medium text-foreground mb-2">Quantity</h3>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-8 text-center">{quantity}</span>
                <Button variant="outline" size="icon" onClick={() => setQuantity(quantity + 1)}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button onClick={handleAddToCart} className="flex-1">
              Add to Cart
            </Button>
            <Button variant="outline" size="icon">
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="outline" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>

          {/* Add payment information after the Add to Cart button
          After the buttons div, add: */}
          <div className="mt-4 p-4 bg-pink-50 rounded-md fancy-border">
            <h3 className="font-medium text-foreground">Payment & Delivery:</h3>
            <ul className="text-sm text-muted-foreground mt-2 space-y-1">
              <li>INDIAN CUSTOMERS ONLY</li>
              <li>Delivery time: 8-10 days</li>
              <li>For COD: ₹250 advance, remaining amount to be paid during delivery</li>
              <li>GPay: 9978624201 (Send screenshot after payment)</li>
              <li>Please share name, address, phone number, size, pincode and colour in one paragraph</li>
            </ul>
          </div>

          <Tabs defaultValue="details">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="care">Care</TabsTrigger>
              <TabsTrigger value="shipping">Shipping</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="space-y-4 mt-4">
              <div className="whitespace-pre-line text-muted-foreground">{product.details}</div>
            </TabsContent>
            <TabsContent value="care" className="space-y-4 mt-4">
              <div className="whitespace-pre-line text-muted-foreground">{product.care}</div>
            </TabsContent>
            {/* In the Tabs section, update the shipping tab content: */}
            <TabsContent value="shipping" className="space-y-4 mt-4">
              <div className="text-muted-foreground">
                <p>Delivery time: 8-10 days</p>
                <p>INDIAN CUSTOMERS ONLY</p>
                <p className="font-medium text-destructive mt-2">Important Policy:</p>
                <p>No returns no exchange unless fault from our side</p>
                <p>Once order has been placed, no changes in the address and contact can be made</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Related Products */}
      <div className="mt-24">
        <h2 className="text-2xl font-bold text-foreground mb-8 ribbon">You May Also Like</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {relatedProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>
      </div>
    </div>
  )
}
