import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface ProductCardProps {
  id: string
  name: string
  price: number
  image: string
  isNew?: boolean
  isSale?: boolean
  discount?: number
}

export default function ProductCard({
  id,
  name,
  price,
  image,
  isNew = false,
  isSale = false,
  discount = 0,
}: ProductCardProps) {
  const formattedPrice = new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
  }).format(price)

  const discountedPrice = discount > 0 ? price - (price * discount) / 100 : price
  const formattedDiscountedPrice = new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
  }).format(discountedPrice)

  return (
    <div className="group relative">
      <div className="aspect-h-4 aspect-w-3 overflow-hidden rounded-md bg-gray-100">
        <Link href={`/product/${id}`}>
          <Image
            src={image || "/placeholder.svg"}
            alt={name}
            width={300}
            height={400}
            className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
          />
        </Link>
        <div className="absolute top-2 right-2">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full bg-white/80 backdrop-blur-sm">
            <Heart className="h-4 w-4" />
          </Button>
        </div>
        {isNew && (
          <div className="absolute top-2 left-2">
            <Badge className="bg-primary text-white">New</Badge>
          </div>
        )}
        {isSale && (
          <div className="absolute top-2 left-2">
            <Badge className="bg-destructive text-white">{discount}% Off</Badge>
          </div>
        )}
      </div>
      <div className="mt-4 flex flex-col">
        <Link href={`/product/${id}`}>
          <h3 className="text-sm font-medium text-foreground">{name}</h3>
        </Link>
        <div className="mt-1 flex items-center">
          {discount > 0 ? (
            <>
              <p className="text-sm font-medium text-foreground">{formattedDiscountedPrice}</p>
              <p className="ml-2 text-sm text-muted-foreground line-through">{formattedPrice}</p>
            </>
          ) : (
            <div className="space-y-0.5">
              <p className="text-sm font-medium text-foreground">₹{price} (COD)</p>
              {price > 2000 && <p className="text-xs text-primary">₹{price - 100} (Prepaid) 🩵</p>}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
