import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-white border-t border-pink-200">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="text-2xl font-bold text-primary">
              Hoor by Zoya
              <span className="bow-decoration ml-1"></span>
            </div>
            <p className="text-muted-foreground text-sm">
              Exclusive Pakistani designer suits for every occasion. Handcrafted with love and attention to detail.
            </p>
            <div className="flex space-x-4">
              <Link href="https://instagram.com/hoorbyzoya" target="_blank" rel="noopener noreferrer">
                <Instagram className="h-5 w-5 text-muted-foreground hover:text-primary" />
              </Link>
              <Link href="#" target="_blank" rel="noopener noreferrer">
                <Facebook className="h-5 w-5 text-muted-foreground hover:text-primary" />
              </Link>
              <Link href="#" target="_blank" rel="noopener noreferrer">
                <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" />
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4 ribbon">Shop</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/new-arrivals" className="text-muted-foreground hover:text-primary text-sm">
                  New Arrivals
                </Link>
              </li>
              <li>
                <Link href="/collections" className="text-muted-foreground hover:text-primary text-sm">
                  Collections
                </Link>
              </li>
              <li>
                <Link href="/ready-to-wear" className="text-muted-foreground hover:text-primary text-sm">
                  Ready to Wear
                </Link>
              </li>
              <li>
                <Link href="/unstitched" className="text-muted-foreground hover:text-primary text-sm">
                  Unstitched
                </Link>
              </li>
              <li>
                <Link href="/sale" className="text-muted-foreground hover:text-primary text-sm">
                  Sale
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4 ribbon">Help</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-primary text-sm">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-muted-foreground hover:text-primary text-sm">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link href="/size-guide" className="text-muted-foreground hover:text-primary text-sm">
                  Size Guide
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary text-sm">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/track-order" className="text-muted-foreground hover:text-primary text-sm">
                  Track Order
                </Link>
              </li>
              <li>
                <Link href="/instagram-link" className="text-muted-foreground hover:text-primary text-sm">
                  Instagram Link
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4 ribbon">Newsletter</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Subscribe to receive updates, access to exclusive deals, and more.
            </p>
            <div className="flex flex-col space-y-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="px-3 py-2 border border-pink-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-pink-200 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm">
            &copy; {new Date().getFullYear()} Hoor by Zoya. All rights reserved. No returns or exchanges unless fault
            from our side.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link href="/privacy-policy" className="text-muted-foreground hover:text-primary text-sm">
              Privacy Policy
            </Link>
            <Link href="/terms-of-service" className="text-muted-foreground hover:text-primary text-sm">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
