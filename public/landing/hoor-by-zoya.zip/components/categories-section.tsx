import Link from "next/link"
import Image from "next/image"

export default function CategoriesSection() {
  const categories = [
    {
      name: "Ready to Wear",
      image: "/images/category-1.png",
      href: "/ready-to-wear",
    },
    {
      name: "Unstitched",
      image: "/images/category-2.png",
      href: "/unstitched",
    },
    {
      name: "Formal Wear",
      image: "/images/category-3.png",
      href: "/formal-wear",
    },
  ]

  return (
    <div className="bg-pink-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4 ribbon">Shop by Category</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore our diverse range of Pakistani designer suits for every style and occasion.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {categories.map((category) => (
            <Link key={category.name} href={category.href} className="group relative overflow-hidden fancy-border">
              <div className="aspect-h-3 aspect-w-2">
                <Image
                  src={category.image || "/placeholder.svg"}
                  alt={category.name}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-xl font-medium text-white">{category.name}</h3>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
