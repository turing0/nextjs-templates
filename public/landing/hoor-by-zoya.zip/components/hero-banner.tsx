import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function HeroBanner() {
  return (
    <div className="relative overflow-hidden bg-pink-50">
      <div className="absolute top-5 right-5 bow-decoration" />
      <div className="absolute bottom-5 left-5 bow-decoration" />

      <div className="container mx-auto px-4 py-12 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
              <span className="ribbon">Elegant Pakistani</span>
              <br />
              Designer Suits
            </h1>
            <p className="text-lg text-muted-foreground max-w-md mx-auto md:mx-0">
              Discover our exquisite collection of handcrafted designer suits for every occasion.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Button asChild size="lg" className="rounded-full">
                <Link href="/collections">Shop Collection</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="rounded-full">
                <Link href="/new-arrivals">New Arrivals</Link>
              </Button>
            </div>
          </div>

          <div className="relative h-[400px] md:h-[500px] w-full">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative h-full w-full max-w-md mx-auto fancy-border p-4">
                <Image
                  src="/images/hero-model.png"
                  alt="Pakistani Designer Suit"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
            </div>
            <div className="absolute -bottom-10 -right-10 bow-decoration" />
          </div>
        </div>
      </div>
    </div>
  )
}
