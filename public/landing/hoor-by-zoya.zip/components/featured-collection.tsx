import ProductCard from "@/components/product-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function FeaturedCollection() {
  const products = [
    {
      id: "1",
      name: "Embroidered Chiffon Suit",
      price: 12500,
      image: "/images/product-1.png",
      isNew: true,
    },
    {
      id: "2",
      name: "Printed Lawn Suit",
      price: 8500,
      image: "/images/product-2.png",
    },
    {
      id: "3",
      name: "Embellished Formal Suit",
      price: 15000,
      image: "/images/product-3.png",
    },
    {
      id: "4",
      name: "Digital Print Silk Suit",
      price: 10500,
      image: "/images/product-4.png",
      isSale: true,
      discount: 15,
    },
  ]

  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4 ribbon">Featured Collection</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover our most popular designer suits, handcrafted with premium fabrics and intricate embroidery.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div key={product.id} className="coquette-card p-4">
              <ProductCard {...product} />
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button asChild variant="outline" className="rounded-full">
            <Link href="/collections">View All Collections</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
